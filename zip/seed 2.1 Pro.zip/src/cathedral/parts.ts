import * as THREE from 'three';
import {
  getDarkStoneMat,
  getDarkMetalMat,
  getGoldMetalMat,
  getWoodMat,
  getEmissiveMat,
  getBlackStoneMat,
  getLightStoneMat,
} from './materials';

/**
 * A gothic arch-shaped profile as a Shape.  Creates a pointed arch.
 * span: total width, rise: height from spring to apex.
 */
export function gothicArchShape(span: number, rise: number): THREE.Shape {
  const s = new THREE.Shape();
  const half = span / 2;
  // Pointed arch: two arcs meeting at apex. Use cubic beziers for approximation.
  s.moveTo(-half, 0);
  // left arc curving up to apex
  s.bezierCurveTo(-half, rise * 0.55, -half * 0.15, rise * 0.9, 0, rise);
  // right arc curving down
  s.bezierCurveTo(half * 0.15, rise * 0.9, half, rise * 0.55, half, 0);
  s.closePath();
  return s;
}

/**
 * Create a lancet (tall pointed) arch frame (a thickened outline) as an extrusion with hole.
 * Returns a Group containing stone frame.
 */
export function createArchFrame(
  span: number,
  rise: number,
  depth: number,
  thickness: number,
  mat?: THREE.Material
): THREE.Group {
  const g = new THREE.Group();
  const material = mat ?? getDarkStoneMat();
  // left and right piers of the arch
  const leftPier = new THREE.Mesh(
    new THREE.BoxGeometry(thickness, rise * 0.5, depth),
    material
  );
  leftPier.position.set(-span / 2 + thickness / 2, rise * 0.25, 0);
  g.add(leftPier);
  const rightPier = leftPier.clone();
  rightPier.position.x = span / 2 - thickness / 2;
  g.add(rightPier);

  // Arch head - voussoirs along a pointed arch curve
  const segments = 14;
  const half = span / 2;
  for (let i = 0; i <= segments; i++) {
    const t = i / segments;
    // build left and right voussoirs
    for (const side of [-1, 1]) {
      const p0 = bezPoint2(-half * side, 0, -half * side * 0.15, rise * 0.9, 0, rise, t);
      const p1 = bezPoint2(-half * side, 0, -half * side * 0.15, rise * 0.9, 0, rise, Math.min(1, t + 1 / segments));
      const mx = (p0.x + p1.x) / 2;
      const my = (p0.y + p1.y) / 2;
      const dx = p1.x - p0.x;
      const dy = p1.y - p0.y;
      const segLen = Math.sqrt(dx * dx + dy * dy);
      const angle = Math.atan2(dy, dx);
      const block = new THREE.Mesh(
        new THREE.BoxGeometry(segLen + 0.02, thickness * 0.9, depth),
        material
      );
      block.position.set(mx * side, my, 0);
      // offset outward (perpendicular)
      const outAngle = angle + Math.PI / 2;
      block.position.x += Math.cos(outAngle) * (thickness / 2) * side;
      block.position.y += Math.sin(outAngle) * (thickness / 2);
      block.rotation.z = angle;
      g.add(block);
    }
  }
  return g;
}

function bezPoint2(
  x0: number, y0: number,
  x1: number, y1: number,
  x2: number, y2: number,
  t: number
) {
  const u = 1 - t;
  return {
    x: u * u * x0 + 2 * u * t * x1 + t * t * x2,
    y: u * u * y0 + 2 * u * t * y1 + t * t * y2,
  };
}

/**
 * Large clustered pier (compound pier) with multiple shafts and capital/base.
 * Returns a Group that can be added; origin is at floor center, extends up to `height`.
 */
export function createCompoundPier(
  height: number,
  radius: number,
  mat?: THREE.Material
): THREE.Group {
  const g = new THREE.Group();
  const material = mat ?? getDarkStoneMat();
  const darkMat = getBlackStoneMat();

  // Base plinth
  const base = new THREE.Mesh(
    new THREE.BoxGeometry(radius * 2.8, 0.8, radius * 2.8),
    darkMat
  );
  base.position.y = 0.4;
  g.add(base);
  const base2 = new THREE.Mesh(
    new THREE.BoxGeometry(radius * 2.3, 0.6, radius * 2.3),
    darkMat
  );
  base2.position.y = 0.8 + 0.3;
  g.add(base2);

  // Main central shaft
  const mainShaft = new THREE.Mesh(
    new THREE.CylinderGeometry(radius, radius * 0.95, height, 20),
    material
  );
  mainShaft.position.y = height / 2 + 1.4;
  g.add(mainShaft);

  // Four subordinate engaged shafts
  const shaftR = radius * 0.38;
  for (let i = 0; i < 4; i++) {
    const angle = (i / 4) * Math.PI * 2 + Math.PI / 4;
    const off = radius * 0.72;
    const shaft = new THREE.Mesh(
      new THREE.CylinderGeometry(shaftR, shaftR, height, 10),
      material
    );
    shaft.position.set(
      Math.cos(angle) * off,
      height / 2 + 1.4,
      Math.sin(angle) * off
    );
    g.add(shaft);
    // tiny base for each shaft
    const sb = new THREE.Mesh(
      new THREE.BoxGeometry(shaftR * 2.2, 0.5, shaftR * 2.2),
      darkMat
    );
    sb.position.set(Math.cos(angle) * off, 1.65, Math.sin(angle) * off);
    g.add(sb);
  }

  // Capital (impost block)
  const cap = new THREE.Mesh(
    new THREE.BoxGeometry(radius * 2.8, 0.6, radius * 2.8),
    darkMat
  );
  cap.position.y = height + 1.4 + 0.3;
  g.add(cap);
  const cap2 = new THREE.Mesh(
    new THREE.BoxGeometry(radius * 3.1, 0.5, radius * 3.1),
    darkMat
  );
  cap2.position.y = height + 1.4 + 0.6 + 0.25;
  g.add(cap2);

  return g;
}

/** Create a straight run of stone stairs. */
export function createStairs(
  width: number,
  stepCount: number,
  stepW: number,
  stepH: number,
  mat?: THREE.Material
): THREE.Mesh {
  const material = mat ?? getDarkStoneMat();
  const totalD = stepCount * stepW;
  const group = new THREE.Group();
  for (let i = 0; i < stepCount; i++) {
    const step = new THREE.Mesh(
      new THREE.BoxGeometry(width, stepH, stepW),
      material
    );
    step.position.set(0, stepH * (i + 0.5), stepW * (i + 0.5) - totalD / 2);
    group.add(step);
  }
  // return as group (we'll merge later, but for clarity group is fine)
  return group as unknown as THREE.Mesh;
}

/** Create a ribbed pointed vault segment between four piers.
 *  The rectangle is w x d (x axis span, z axis depth), with height to apex above spring level given by `rise`.
 *  Returns group with ribs and vault panels.
 */
export function createRibbedVault(
  spanX: number,
  spanZ: number,
  springY: number,
  rise: number,
  mat?: THREE.Material
): THREE.Group {
  const g = new THREE.Group();
  const material = mat ?? getDarkStoneMat();
  const darkMat = getBlackStoneMat();

  // Four diagonal ribs (groin vault simplified to a quadripartite pattern), plus transverse and wall ribs.
  // The apex is at center (0, springY + rise, 0).
  // Build ribs as tapered cylinders / boxes along curves.
  const addCurvedRib = (
    x0: number, z0: number,
    x1: number, z1: number,
    color?: THREE.Material
  ) => {
    const segs = 18;
    const dx = x1 - x0;
    const dz = z1 - z0;
    for (let i = 0; i < segs; i++) {
      const t0 = i / segs;
      const t1 = (i + 1) / segs;
      // simple arch: height proportional to sin(pi * t), scaled so that at t=0.5 h=rise
      const h0 = Math.sin(t0 * Math.PI) * rise;
      const h1 = Math.sin(t1 * Math.PI) * rise;
      const tm = (t0 + t1) / 2;
      const segLen =
        Math.sqrt(
          (dx / segs) ** 2 + (dz / segs) ** 2 + (h1 - h0) ** 2
        );
      const seg = new THREE.Mesh(
        new THREE.BoxGeometry(0.7, 0.9, segLen + 0.05),
        color ?? material
      );
      const mx = x0 + dx * tm;
      const mz = z0 + dz * tm;
      const my = springY + (h0 + h1) / 2;
      seg.position.set(mx, my, mz);
      // orient along segment
      seg.lookAt(x0 + dx * t1, springY + h1, z0 + dz * t1);
      seg.rotateX(Math.PI / 2);
      g.add(seg);
    }
  };

  const halfX = spanX / 2;
  const halfZ = spanZ / 2;
  // wall/transverse ribs
  addCurvedRib(-halfX, -halfZ, halfX, -halfZ);
  addCurvedRib(-halfX, halfZ, halfX, halfZ);
  addCurvedRib(-halfX, -halfZ, -halfX, halfZ);
  addCurvedRib(halfX, -halfZ, halfX, halfZ);
  // diagonal ribs (X)
  addCurvedRib(-halfX, -halfZ, halfX, halfZ, darkMat);
  addCurvedRib(halfX, -halfZ, -halfX, halfZ, darkMat);

  // Boss at apex
  const boss = new THREE.Mesh(
    new THREE.IcosahedronGeometry(1.8, 0),
    getDarkMetalMat()
  );
  boss.position.set(0, springY + rise + 0.2, 0);
  g.add(boss);
  const bossRing = new THREE.Mesh(
    new THREE.TorusGeometry(2.2, 0.25, 6, 24),
    getGoldMetalMat()
  );
  bossRing.position.copy(boss.position);
  bossRing.rotation.x = Math.PI / 2;
  g.add(bossRing);

  // Infill panels (we use thin curved planes between ribs, simplified as a few quads per bay)
  // To save poly, we create two large trapezoids for four cells, each a slightly arched panel
  const panelMat = material.clone() as THREE.MeshStandardMaterial;
  panelMat.side = THREE.DoubleSide;
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      const geo = new THREE.BufferGeometry();
      const verts: number[] = [];
      const cells = 5;
      for (let i = 0; i <= cells; i++) {
        for (let j = 0; j <= cells; j++) {
          const u = i / cells;
          const v = j / cells;
          // quarter panel: from corner to apex
          const cornerX = sx * halfX;
          const cornerZ = sz * halfZ;
          const px = cornerX * (1 - u);
          const pz = cornerZ * (1 - v);
          // Height along arch - based on distance from corner normalized
          const t = Math.max(u, v);
          const h = Math.sin(t * Math.PI) * rise;
          verts.push(px, springY + h - 0.1, pz);
        }
      }
      const idx: number[] = [];
      for (let i = 0; i < cells; i++) {
        for (let j = 0; j < cells; j++) {
          const a = i * (cells + 1) + j;
          const b = a + 1;
          const c = a + (cells + 1);
          const d = c + 1;
          idx.push(a, c, b);
          idx.push(b, c, d);
        }
      }
      geo.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
      geo.setIndex(idx);
      geo.computeVertexNormals();
      const panel = new THREE.Mesh(geo, panelMat);
      g.add(panel);
    }
  }

  return g;
}

/** Build a human-sized wooden bench. */
export function createBench(): THREE.Group {
  const g = new THREE.Group();
  const wood = getWoodMat();
  const darkStone = getDarkStoneMat();
  // Seat
  const seat = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.12, 0.5), wood);
  seat.position.y = 0.5;
  g.add(seat);
  // Back
  const back = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.9, 0.08), wood);
  back.position.set(0, 0.95, -0.2);
  g.add(back);
  // Legs (stone)
  for (const x of [-1.0, 1.0]) {
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.5, 0.45), darkStone);
    leg.position.set(x, 0.25, 0);
    g.add(leg);
  }
  // Kneeler
  const knee = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.08, 0.2), wood);
  knee.position.set(0, 0.2, 0.35);
  g.add(knee);
  return g;
}

/** Simple wrought-iron railing section. */
export function createRailing(length: number): THREE.Group {
  const g = new THREE.Group();
  const metal = getDarkMetalMat();
  const top = new THREE.Mesh(new THREE.BoxGeometry(length, 0.08, 0.08), metal);
  top.position.y = 1.0;
  g.add(top);
  const bot = new THREE.Mesh(new THREE.BoxGeometry(length, 0.04, 0.04), metal);
  bot.position.y = 0.25;
  g.add(bot);
  const posts = Math.max(3, Math.floor(length / 0.8));
  for (let i = 0; i <= posts; i++) {
    const t = i / posts;
    const x = -length / 2 + t * length;
    const p = new THREE.Mesh(new THREE.BoxGeometry(0.05, 1.0, 0.05), metal);
    p.position.set(x, 0.5, 0);
    g.add(p);
  }
  return g;
}

/** A stylized human-scale standing statue figure (schematic, to give scale cue). */
export function createStatue(): THREE.Group {
  const g = new THREE.Group();
  const mat = getLightStoneMat();
  const gold = getGoldMetalMat();
  // Body (robe) - tapered box
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.45, 2.0, 10), mat);
  body.position.y = 1.0;
  g.add(body);
  // Head
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.45, 0.38), mat);
  head.position.y = 2.25;
  g.add(head);
  // Halo / crown ring
  const halo = new THREE.Mesh(new THREE.TorusGeometry(0.35, 0.05, 6, 16), gold);
  halo.position.set(0, 2.55, 0);
  halo.rotation.x = Math.PI / 2;
  g.add(halo);
  // Arms raised in geometric gesture
  for (const side of [-1, 1]) {
    const arm = new THREE.Mesh(new THREE.BoxGeometry(0.15, 1.1, 0.15), mat);
    arm.position.set(side * 0.45, 1.7, 0);
    arm.rotation.z = side * 0.4;
    g.add(arm);
  }
  // Pedestal
  const ped = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.6, 1.2), getBlackStoneMat());
  ped.position.y = 0.3;
  g.add(ped);
  // Scale: ~2.6m tall including pedestal => clearly human-height
  g.scale.setScalar(1.0);
  return g;
}

/** A single candle with a point light (light not added - caller handles if desired). */
export function createCandle(emissive = true): THREE.Group {
  const g = new THREE.Group();
  const waxMat = new THREE.MeshStandardMaterial({
    color: 0xefe0c2,
    roughness: 0.8,
  });
  const wax = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 0.8, 8), waxMat);
  wax.position.y = 0.4;
  g.add(wax);
  if (emissive) {
    const flameMat = getEmissiveMat(0xffb060, 2.0);
    const flame = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.18, 8), flameMat);
    flame.position.y = 0.9;
    g.add(flame);
  }
  // Stick holder
  const holder = new THREE.Mesh(
    new THREE.CylinderGeometry(0.08, 0.1, 0.1, 8),
    getDarkMetalMat()
  );
  holder.position.y = 0.05;
  g.add(holder);
  return g;
}

/** Create a massive suspension chain made of linked torus segments. Chain hangs along vertical from yTop to yBottom centered at origin. */
export function createChain(yTop: number, yBottom: number, linkSize = 1.2): THREE.Group {
  const g = new THREE.Group();
  const metal = getDarkMetalMat();
  const length = yTop - yBottom;
  const linkCount = Math.max(4, Math.floor(length / (linkSize * 1.6)));
  const step = length / linkCount;
  for (let i = 0; i < linkCount; i++) {
    const link = new THREE.Mesh(
      new THREE.TorusGeometry(linkSize, linkSize * 0.22, 8, 18),
      metal
    );
    link.position.y = yTop - i * step - step / 2;
    link.rotation.x = i % 2 === 0 ? Math.PI / 2 : Math.PI / 2;
    link.rotation.y = i % 2 === 0 ? 0 : Math.PI / 2;
    g.add(link);
  }
  return g;
}

/** Build a lancet window (tall pointed) with stone tracery and stained glass. */
export function createLancetWindow(
  span: number,
  rise: number,
  glassColor: THREE.ColorRepresentation = 0x5588cc
): THREE.Group {
  const g = new THREE.Group();
  const stone = getDarkStoneMat();
  const metal = getDarkMetalMat();
  // Outer stone frame (thin)
  const frame = createArchFrame(span, rise, 0.4, 0.25, stone);
  g.add(frame);
  // Glass (as shape extruded a little)
  const s = gothicArchShape(span - 0.5, rise - 0.4);
  const glassGeom = new THREE.ExtrudeGeometry(s, {
    depth: 0.08,
    bevelEnabled: false,
    steps: 1,
  });
  const glassMat = new THREE.MeshStandardMaterial({
    color: glassColor,
    emissive: glassColor,
    emissiveIntensity: 0.7,
    roughness: 0.1,
    metalness: 0.0,
    transparent: true,
    opacity: 0.6,
    side: THREE.DoubleSide,
  });
  const glass = new THREE.Mesh(glassGeom, glassMat);
  glass.position.z = -0.04;
  g.add(glass);
  // Center mullion (vertical stone bar)
  const mullion = new THREE.Mesh(new THREE.BoxGeometry(0.18, rise, 0.3), stone);
  mullion.position.y = rise / 2;
  g.add(mullion);
  // Simple tracery circle at top
  const rose = new THREE.Mesh(new THREE.TorusGeometry(span * 0.22, 0.12, 6, 18), metal);
  rose.position.set(0, rise * 0.78, 0);
  g.add(rose);
  return g;
}
