import * as THREE from 'three';

// Procedural textures drawn to canvases so GLTFExporter can always serialize them.

function makeNoiseCanvas(
  size: number,
  base: [number, number, number],
  variation: number,
  scale: number
): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const imgData = ctx.createImageData(size, size);
  const data = imgData.data;

  const rand = (x: number, y: number) => {
    const n = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
    return n - Math.floor(n);
  };
  const smooth = (x: number, y: number) => {
    const xi = Math.floor(x);
    const yi = Math.floor(y);
    const xf = x - xi;
    const yf = y - yi;
    const tl = rand(xi, yi);
    const tr = rand(xi + 1, yi);
    const bl = rand(xi, yi + 1);
    const br = rand(xi + 1, yi + 1);
    const u = xf * xf * (3 - 2 * xf);
    const v = yf * yf * (3 - 2 * yf);
    return tl * (1 - u) * (1 - v) + tr * u * (1 - v) + bl * (1 - u) * v + br * u * v;
  };

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = (y * size + x) * 4;
      let n = 0;
      let amp = 1;
      let freq = scale;
      let norm = 0;
      for (let o = 0; o < 4; o++) {
        n += smooth((x / size) * freq, (y / size) * freq) * amp;
        norm += amp;
        amp *= 0.5;
        freq *= 2;
      }
      n /= norm;
      const v = (n - 0.5) * variation * 2;
      data[i] = Math.max(0, Math.min(255, base[0] + v));
      data[i + 1] = Math.max(0, Math.min(255, base[1] + v));
      data[i + 2] = Math.max(0, Math.min(255, base[2] + v));
      data[i + 3] = 255;
    }
  }
  ctx.putImageData(imgData, 0, 0);
  return canvas;
}

function makeStoneNormalCanvas(size: number, strength: number, scale: number): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const imgData = ctx.createImageData(size, size);
  const data = imgData.data;

  const rand = (x: number, y: number) => {
    const n = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453;
    return n - Math.floor(n);
  };
  const smooth = (x: number, y: number) => {
    const xi = Math.floor(x);
    const yi = Math.floor(y);
    const xf = x - xi;
    const yf = y - yi;
    const tl = rand(xi, yi);
    const tr = rand(xi + 1, yi);
    const bl = rand(xi, yi + 1);
    const br = rand(xi + 1, yi + 1);
    const u = xf * xf * (3 - 2 * xf);
    const v = yf * yf * (3 - 2 * yf);
    return tl * (1 - u) * (1 - v) + tr * u * (1 - v) + bl * (1 - u) * v + br * u * v;
  };
  const sample = (x: number, y: number) => {
    let n = 0, amp = 1, freq = scale, norm = 0;
    for (let o = 0; o < 5; o++) {
      n += smooth((x / size) * freq, (y / size) * freq) * amp;
      norm += amp;
      amp *= 0.5;
      freq *= 2;
    }
    return n / norm;
  };

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = (y * size + x) * 4;
      const hL = sample(x - 1, y);
      const hR = sample(x + 1, y);
      const hD = sample(x, y - 1);
      const hU = sample(x, y + 1);
      let nx = (hL - hR) * strength;
      let ny = (hD - hU) * strength;
      let nz = 1;
      const len = Math.sqrt(nx * nx + ny * ny + nz * nz);
      nx /= len; ny /= len; nz /= len;
      data[i] = Math.floor((nx * 0.5 + 0.5) * 255);
      data[i + 1] = Math.floor((ny * 0.5 + 0.5) * 255);
      data[i + 2] = Math.floor((nz * 0.5 + 0.5) * 255);
      data[i + 3] = 255;
    }
  }
  ctx.putImageData(imgData, 0, 0);
  return canvas;
}

function makeFloorInlayCanvas(size: number): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const imgData = ctx.createImageData(size, size);
  const data = imgData.data;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = (y * size + x) * 4;
      const u = x / size;
      const v = y / size;
      let r = 28, g = 26, b = 30;
      const slabX = (u * 8) % 1;
      const slabY = (v * 20) % 1;
      const slabW = 0.02;
      const seamX = slabX < slabW || slabX > 1 - slabW;
      const seamY = slabY < slabW || slabY > 1 - slabW;
      if (seamX || seamY) {
        r = 14; g = 12; b = 16;
      }
      const cx = Math.abs(u - 0.5);
      if (cx < 0.08) {
        const tileU = (u * 40) % 1;
        const tileV = (v * 40) % 1;
        const d = Math.abs(tileU - 0.5) + Math.abs(tileV - 0.5);
        if (d < 0.1) {
          r = 180; g = 150; b = 90;
        } else if (d < 0.15) {
          r = 60; g = 52; b = 44;
        } else {
          r = 40; g = 36; b = 40;
        }
      } else if (cx < 0.1) {
        r = 50; g = 44; b = 38;
      }
      const n = (Math.random() - 0.5) * 10;
      data[i] = Math.max(0, Math.min(255, r + n));
      data[i + 1] = Math.max(0, Math.min(255, g + n));
      data[i + 2] = Math.max(0, Math.min(255, b + n));
      data[i + 3] = 255;
    }
  }
  ctx.putImageData(imgData, 0, 0);
  return canvas;
}

function makeTex(canvas: HTMLCanvasElement, repeat = true): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = repeat ? THREE.RepeatWrapping : THREE.ClampToEdgeWrapping;
  tex.wrapT = repeat ? THREE.RepeatWrapping : THREE.ClampToEdgeWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

// Cached textures
let _darkStone: THREE.CanvasTexture | null = null;
let _darkStoneNormal: THREE.CanvasTexture | null = null;
let _lightStone: THREE.CanvasTexture | null = null;
let _metalDark: THREE.CanvasTexture | null = null;
let _metalNormal: THREE.CanvasTexture | null = null;
let _floorTex: THREE.CanvasTexture | null = null;
let _goldMetal: THREE.CanvasTexture | null = null;
let _stainedGlass: THREE.CanvasTexture | null = null;
let _woodTex: THREE.CanvasTexture | null = null;

export function getDarkStoneMat(): THREE.MeshStandardMaterial {
  if (!_darkStone) _darkStone = makeTex(makeNoiseCanvas(256, [34, 32, 38], 14, 6));
  if (!_darkStoneNormal) _darkStoneNormal = makeTex(makeStoneNormalCanvas(256, 18, 8));
  return new THREE.MeshStandardMaterial({
    map: _darkStone,
    normalMap: _darkStoneNormal,
    normalScale: new THREE.Vector2(0.7, 0.7),
    roughness: 0.92,
    metalness: 0.02,
    color: 0x8a8488,
  });
}

export function getLightStoneMat(): THREE.MeshStandardMaterial {
  if (!_lightStone) _lightStone = makeTex(makeNoiseCanvas(256, [90, 84, 78], 18, 5));
  return new THREE.MeshStandardMaterial({
    map: _lightStone,
    roughness: 0.85,
    metalness: 0.0,
    color: 0xbfb3a4,
  });
}

export function getDarkMetalMat(): THREE.MeshStandardMaterial {
  if (!_metalDark) _metalDark = makeTex(makeNoiseCanvas(256, [18, 18, 22], 12, 12));
  if (!_metalNormal) _metalNormal = makeTex(makeStoneNormalCanvas(256, 8, 20));
  return new THREE.MeshStandardMaterial({
    map: _metalDark,
    normalMap: _metalNormal,
    normalScale: new THREE.Vector2(0.4, 0.4),
    roughness: 0.55,
    metalness: 0.75,
    color: 0x2a2a30,
  });
}

export function getGoldMetalMat(): THREE.MeshStandardMaterial {
  if (!_goldMetal) _goldMetal = makeTex(makeNoiseCanvas(256, [120, 90, 40], 20, 14));
  return new THREE.MeshStandardMaterial({
    map: _goldMetal,
    roughness: 0.35,
    metalness: 0.85,
    color: 0xd4a84b,
    emissive: 0x1a0f00,
  });
}

export function getFloorMat(): THREE.MeshStandardMaterial {
  if (!_floorTex) _floorTex = makeTex(makeFloorInlayCanvas(512));
  return new THREE.MeshStandardMaterial({
    map: _floorTex,
    roughness: 0.75,
    metalness: 0.05,
    color: 0xffffff,
  });
}

export function getStainedGlassMat(color: THREE.ColorRepresentation): THREE.MeshStandardMaterial {
  if (!_stainedGlass) _stainedGlass = makeTex(makeNoiseCanvas(128, [80, 80, 90], 40, 8));
  return new THREE.MeshStandardMaterial({
    map: _stainedGlass,
    roughness: 0.1,
    metalness: 0.0,
    transparent: true,
    opacity: 0.75,
    color: color,
    emissive: color,
    emissiveIntensity: 0.25,
    side: THREE.DoubleSide,
  });
}

export function getEmissiveMat(
  color: THREE.ColorRepresentation,
  intensity: number = 1.5
): THREE.MeshStandardMaterial {
  return new THREE.MeshStandardMaterial({
    color: color,
    emissive: color,
    emissiveIntensity: intensity,
    roughness: 0.4,
    metalness: 0.0,
  });
}

export function getWoodMat(): THREE.MeshStandardMaterial {
  if (!_woodTex) _woodTex = makeTex(makeNoiseCanvas(256, [52, 32, 18], 14, 18));
  return new THREE.MeshStandardMaterial({
    map: _woodTex,
    roughness: 0.8,
    metalness: 0.0,
    color: 0x6a4528,
  });
}

export function getBlackStoneMat(): THREE.MeshStandardMaterial {
  const tex = makeTex(makeNoiseCanvas(256, [14, 13, 18], 8, 6));
  const nrm = makeTex(makeStoneNormalCanvas(256, 22, 10));
  return new THREE.MeshStandardMaterial({
    map: tex,
    normalMap: nrm,
    normalScale: new THREE.Vector2(1.0, 1.0),
    roughness: 0.7,
    metalness: 0.1,
    color: 0x2a2a34,
  });
}
