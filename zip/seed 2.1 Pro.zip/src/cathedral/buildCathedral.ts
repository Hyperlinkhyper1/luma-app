import * as THREE from 'three';
import {
  createCompoundPier,
  createRibbedVault,
  createBench,
  createRailing,
  createStatue,
  createCandle,
  createChain,
  createLancetWindow,
  gothicArchShape,
} from './parts';
import {
  getDarkStoneMat,
  getDarkMetalMat,
  getGoldMetalMat,
  getFloorMat,
  getEmissiveMat,
  getBlackStoneMat,
  getLightStoneMat,
  getWoodMat,
  getStainedGlassMat,
} from './materials';

/**
 * Build the entire cathedral scene and return a THREE.Group.
 * Units: meters. The cathedral is large enough to evoke megalophobia.
 * The viewer is intended to stand near the entrance (z ~ -110) looking east toward the crossing and suspended monument.
 */
export function buildCathedral(): THREE.Group {
  const root = new THREE.Group();
  root.name = 'CathedralOfTheHangingWitness';

  // ----- Key dimensions (meters) -----
  const NAVE_LENGTH = 240; // along +Z (we place entrance at -NAVE_LENGTH/2, apse at +NAVE_LENGTH/2)
  const NAVE_SPAN = 26; // between arcade piers
  const AISLE_SPAN = 11;
  const TOTAL_WIDTH = NAVE_SPAN + AISLE_SPAN * 2;
  const PIER_RADIUS = 1.9;
  const PIER_HEIGHT_ARCADE = 28; // height of main pier capitals
  const TRIFORIUM_HEIGHT = 14; // middle level height
  const CLERESTORY_HEIGHT = 22; // upper window level height
  const VAULT_RISE_NAVE = 20;
  const BAY_DEPTH = 18;
  const BAY_COUNT_NAVE = 12; // 6 bays on each side of crossing
  const TRANSEPT_HALF_LENGTH = 60;
  const TRANSEPT_SPAN = 24;
  const APSE_RADIUS = 26;

  // We'll build with a coordinate system where X is width, Z is length, Y is up.
  // The crossing (where transept crosses nave) is at z=0. Entrance at z=-NAVE_LENGTH/2.
  // Centerline X=0.

  // ----- Materials -----
  const darkStone = getDarkStoneMat();
  const blackStone = getBlackStoneMat();
  const lightStone = getLightStoneMat();
  const darkMetal = getDarkMetalMat();
  const goldMetal = getGoldMetalMat();
  const floorMat = getFloorMat();
  const candleMat = getEmissiveMat(0xffc070, 2.0);
  void candleMat;

  // =============================================
  // FLOOR
  // =============================================
  const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(300, 420, 1, 1),
    floorMat
  );
  floor.rotation.x = -Math.PI / 2;
  floor.position.y = 0;
  // Repeat the texture across the floor
  (floorMat.map as THREE.Texture).repeat.set(12, 22);
  floor.receiveShadow = true;
  root.add(floor);

  // Slight elevation: steps up to crossing platform
  const platform = new THREE.Mesh(
    new THREE.BoxGeometry(NAVE_SPAN + 4, 0.6, 22),
    darkStone
  );
  platform.position.set(0, 0.3, 0);
  root.add(platform);
  const step1 = new THREE.Mesh(
    new THREE.BoxGeometry(NAVE_SPAN + 6, 0.25, 2),
    darkStone
  );
  step1.position.set(0, 0.125, -12);
  root.add(step1);
  const step2 = step1.clone();
  step2.position.z = 12;
  root.add(step2);

  // Giant inlaid rose/labyrinth under the crossing, directly below the hanging crown
  const roseGroup = new THREE.Group();
  roseGroup.name = 'FloorRose';
  const outerRose = new THREE.Mesh(
    new THREE.RingGeometry(8.0, 8.5, 64),
    goldMetal
  );
  outerRose.rotation.x = -Math.PI / 2;
  outerRose.position.y = 0.61;
  roseGroup.add(outerRose);
  const innerRing = new THREE.Mesh(
    new THREE.RingGeometry(3.5, 3.8, 48),
    goldMetal
  );
  innerRing.rotation.x = -Math.PI / 2;
  innerRing.position.y = 0.61;
  roseGroup.add(innerRing);
  const centerDisc = new THREE.Mesh(
    new THREE.CircleGeometry(1.4, 32),
    blackStone
  );
  centerDisc.rotation.x = -Math.PI / 2;
  centerDisc.position.y = 0.62;
  roseGroup.add(centerDisc);
  // Radiating lines (gold)
  for (let i = 0; i < 16; i++) {
    const a = (i / 16) * Math.PI * 2;
    const spoke = new THREE.Mesh(
      new THREE.BoxGeometry(8.5, 0.05, 0.2),
      goldMetal
    );
    spoke.rotation.y = a;
    spoke.position.set(0, 0.615, 0);
    roseGroup.add(spoke);
  }
  root.add(roseGroup);

  // Floor edge channels (dark grooves leading toward center)
  for (const side of [-1, 1]) {
    const channel = new THREE.Mesh(
      new THREE.BoxGeometry(0.3, 0.05, 400),
      blackStone
    );
    channel.position.set(side * (NAVE_SPAN / 2 - 1.2), 0.03, 0);
    root.add(channel);
  }

  // =============================================
  // NAVE PIERS (arcade)
  // =============================================
  // We create a single pier and clone it for efficiency.
  const pierTemplate = createCompoundPier(PIER_HEIGHT_ARCADE, PIER_RADIUS);

  type PierPos = { x: number; z: number; h?: number };
  const pierPositions: PierPos[] = [];

  // Nave arcade piers
  const naveHalf = (BAY_COUNT_NAVE * BAY_DEPTH) / 2;
  for (let b = -BAY_COUNT_NAVE / 2; b <= BAY_COUNT_NAVE / 2; b++) {
    const z = b * BAY_DEPTH;
    // don't put piers exactly at crossing center (x = +/- NAVE_SPAN/2, but at crossing these are part of the crossing piers)
    pierPositions.push({ x: -NAVE_SPAN / 2, z });
    pierPositions.push({ x: NAVE_SPAN / 2, z });
  }
  // Outer aisle piers
  for (let b = -BAY_COUNT_NAVE / 2; b <= BAY_COUNT_NAVE / 2; b++) {
    const z = b * BAY_DEPTH;
    pierPositions.push({ x: -NAVE_SPAN / 2 - AISLE_SPAN, z });
    pierPositions.push({ x: NAVE_SPAN / 2 + AISLE_SPAN, z });
  }
  // Transept piers (going out from crossing)
  const transeptBays = 3;
  for (let b = 1; b <= transeptBays; b++) {
    const z = b * BAY_DEPTH * 0.9;
    pierPositions.push({ x: -TRANSEPT_SPAN / 2 - AISLE_SPAN, z });
    pierPositions.push({ x: TRANSEPT_SPAN / 2 + AISLE_SPAN, z });
    pierPositions.push({ x: -TRANSEPT_SPAN / 2 - AISLE_SPAN, z: -z });
    pierPositions.push({ x: TRANSEPT_SPAN / 2 + AISLE_SPAN, z: -z });
  }
  // Apse columns (semi-circle at east end)
  const apseCount = 10;
  for (let i = 0; i <= apseCount; i++) {
    const t = i / apseCount;
    const angle = t * Math.PI; // 0..PI: sweeps from +X through +Z to -X (east apse)
    const x = Math.cos(angle) * APSE_RADIUS;
    const z = naveHalf + 6 + Math.sin(angle) * APSE_RADIUS * 0.9;
    pierPositions.push({ x, z, h: PIER_HEIGHT_ARCADE * 0.85 });
  }

  const pierGroup = new THREE.Group();
  pierGroup.name = 'Piers';
  for (const p of pierPositions) {
    const pier = pierTemplate.clone();
    // Make the four crossing piers (at z=0, inner nave piers) noticeably larger
    const isCrossingPier = Math.abs(p.z) < 0.5 && Math.abs(Math.abs(p.x) - NAVE_SPAN / 2) < 0.5;
    if (isCrossingPier) {
      pier.scale.setScalar(1.45);
    }
    if (p.h && p.h !== PIER_HEIGHT_ARCADE) {
      pier.scale.y = p.h / PIER_HEIGHT_ARCADE;
    }
    pier.position.set(p.x, 0, p.z);
    pierGroup.add(pier);
  }
  root.add(pierGroup);

  // =============================================
  // NAVE ARCADE (ground-level arches running along the nave between adjacent nave piers)
  // These create the rhythm of open arches on either side of the nave.
  // =============================================
  const naveArcadeGroup = new THREE.Group();
  naveArcadeGroup.name = 'NaveArcade';
  for (let b = -BAY_COUNT_NAVE / 2; b < BAY_COUNT_NAVE / 2; b++) {
    const z0 = b * BAY_DEPTH;
    const z1 = (b + 1) * BAY_DEPTH;
    const zMid = (z0 + z1) / 2;
    for (const side of [-1, 1]) {
      // Arch runs along Z between two adjacent piers on same side of nave.
      // Arch lies in Y/Z plane => build it with span = BAY_DEPTH, then rotate around X to align vertically? 
      // buildPointedArchBoxes builds arch in X/Y plane, so we rotate Y by 90 deg so its span runs along Z.
      const arch = buildPointedArchBoxes(
        BAY_DEPTH - 2.5,
        PIER_HEIGHT_ARCADE * 0.78,
        2.2,
        1.3,
        darkStone
      );
      arch.rotation.y = Math.PI / 2; // now arch spans Z
      arch.position.set(
        side * (NAVE_SPAN / 2),
        1.4,
        zMid
      );
      naveArcadeGroup.add(arch);
    }
  }
  root.add(naveArcadeGroup);

  // =============================================
  // AISLE TRANSVERSE ARCHES (cross the aisle between nave pier and outer pier, at each bay line)
  // =============================================
  const aisleTransGroup = new THREE.Group();
  aisleTransGroup.name = 'AisleTransverseArches';
  for (let b = -BAY_COUNT_NAVE / 2; b <= BAY_COUNT_NAVE / 2; b++) {
    const z = b * BAY_DEPTH;
    for (const side of [-1, 1]) {
      const arch = buildPointedArchBoxes(
        AISLE_SPAN + 0.5,
        AISLE_SPAN * 1.25,
        1.8,
        1.0,
        darkStone
      );
      arch.position.set(
        side * (NAVE_SPAN / 2 + AISLE_SPAN / 2),
        1.4,
        z
      );
      aisleTransGroup.add(arch);
    }
  }
  root.add(aisleTransGroup);

  // Longitudinal arches along the outer aisle wall (between adjacent outer piers)
  const outerArcadeGroup = new THREE.Group();
  outerArcadeGroup.name = 'OuterAisleArches';
  for (let b = -BAY_COUNT_NAVE / 2; b < BAY_COUNT_NAVE / 2; b++) {
    const zMid = b * BAY_DEPTH + BAY_DEPTH / 2;
    for (const side of [-1, 1]) {
      const arch = buildPointedArchBoxes(
        BAY_DEPTH - 2.5,
        AISLE_SPAN * 0.9,
        2.0,
        1.0,
        darkStone
      );
      arch.rotation.y = Math.PI / 2;
      arch.position.set(
        side * (NAVE_SPAN / 2 + AISLE_SPAN),
        1.4,
        zMid
      );
      outerArcadeGroup.add(arch);
    }
  }
  root.add(outerArcadeGroup);

  // =============================================
  // TRIFORIUM GALLERY (middle level)
  // =============================================
  const triforiumGroup = new THREE.Group();
  triforiumGroup.name = 'Triforium';
  const triforiumFloorY = PIER_HEIGHT_ARCADE + 1.4 + TRIFORIUM_HEIGHT * 0 + 0.4;
  // Gallery floor slab (only on sides, not over nave)
  for (const side of [-1, 1]) {
    const floor = new THREE.Mesh(
      new THREE.BoxGeometry(AISLE_SPAN + 2, 0.6, NAVE_LENGTH + 20),
      darkStone
    );
    floor.position.set(side * (NAVE_SPAN / 2 + AISLE_SPAN / 2), triforiumFloorY, 0);
    triforiumGroup.add(floor);
    // Parapet wall on gallery (facing nave)
    const parapet = new THREE.Mesh(
      new THREE.BoxGeometry(0.6, 2.2, NAVE_LENGTH + 20),
      blackStone
    );
    parapet.position.set(
      side * (NAVE_SPAN / 2 - 0.3),
      triforiumFloorY + 1.4,
      0
    );
    triforiumGroup.add(parapet);
    // Railing in front of parapet? Add small scale human-sized railing
  }
  // Triforium has an open arcade with small arches facing the nave
  const trifArchTemplate = buildPointedArchBoxes(4, 5.5, 0.6, 0.4, blackStone);
  const trifArchCount = BAY_COUNT_NAVE * 2;
  for (let i = 0; i < trifArchCount; i++) {
    const z = -NAVE_LENGTH / 2 + (i + 0.5) * ((NAVE_LENGTH) / trifArchCount);
    for (const side of [-1, 1]) {
      const a = trifArchTemplate.clone();
      a.position.set(
        side * (NAVE_SPAN / 2 - 0.05),
        triforiumFloorY + 0.2,
        z
      );
      triforiumGroup.add(a);
    }
  }
  root.add(triforiumGroup);

  // =============================================
  // CLERESTORY (upper wall with windows)
  // =============================================
  const clerestoryGroup = new THREE.Group();
  clerestoryGroup.name = 'Clerestory';
  const clerestoryY = triforiumFloorY + 2.2 + 0.3;
  for (const side of [-1, 1]) {
    const wall = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, CLERESTORY_HEIGHT, NAVE_LENGTH + 20),
      darkStone
    );
    wall.position.set(side * (NAVE_SPAN / 2 - 0.6), clerestoryY + CLERESTORY_HEIGHT / 2, 0);
    clerestoryGroup.add(wall);
  }
  // Clerestory lancet windows - one per bay
  for (let b = -BAY_COUNT_NAVE / 2; b < BAY_COUNT_NAVE / 2; b++) {
    const z = b * BAY_DEPTH + BAY_DEPTH / 2;
    for (const side of [-1, 1]) {
      const winSpan = 5;
      const winRise = 18;
      const win = createLancetWindow(
        winSpan, winRise,
        (b + side + 100) % 3 === 0 ? 0x923020 : ((b + side) % 2 === 0 ? 0x335890 : 0x2e6648)
      );
      win.position.set(
        side * (NAVE_SPAN / 2 - 0.3),
        clerestoryY + 0.5,
        z
      );
      win.rotation.y = side === -1 ? Math.PI / 2 : -Math.PI / 2;
      clerestoryGroup.add(win);
    }
  }
  root.add(clerestoryGroup);

  // =============================================
  // SIDE AISLE OUTER WALLS
  // =============================================
  for (const side of [-1, 1]) {
    // Wall
    const wall = new THREE.Mesh(
      new THREE.BoxGeometry(1.5, PIER_HEIGHT_ARCADE + 1, NAVE_LENGTH + 40),
      darkStone
    );
    wall.position.set(
      side * (NAVE_SPAN / 2 + AISLE_SPAN + 0.7),
      (PIER_HEIGHT_ARCADE + 1) / 2 + 0.5,
      0
    );
    root.add(wall);
    // Small side windows
    for (let b = -BAY_COUNT_NAVE / 2; b < BAY_COUNT_NAVE / 2; b++) {
      const z = b * BAY_DEPTH + BAY_DEPTH / 2;
      const winSpan = 3;
      const winRise = 8;
      const win = createLancetWindow(winSpan, winRise, 0x5577aa);
      win.position.set(
        side * (NAVE_SPAN / 2 + AISLE_SPAN + 0.3),
        6,
        z
      );
      win.rotation.y = side === -1 ? Math.PI / 2 : -Math.PI / 2;
      root.add(win);
    }
  }

  // =============================================
  // VAULTING (nave bays)
  // =============================================
  const vaultGroup = new THREE.Group();
  vaultGroup.name = 'Vaults';
  for (let b = -BAY_COUNT_NAVE / 2; b < BAY_COUNT_NAVE / 2; b++) {
    const zCenter = b * BAY_DEPTH + BAY_DEPTH / 2;
    const vault = createRibbedVault(
      NAVE_SPAN - 2,
      BAY_DEPTH - 2,
      clerestoryY + CLERESTORY_HEIGHT,
      VAULT_RISE_NAVE,
      darkStone
    );
    vault.position.set(0, 0, zCenter);
    vaultGroup.add(vault);
  }
  // Transept vaults
  for (const dir of [-1, 1]) {
    for (let b = 0; b < transeptBays; b++) {
      const zCenter = dir * (b * BAY_DEPTH * 0.9 + BAY_DEPTH * 0.9 / 2);
      const v = createRibbedVault(
        TRANSEPT_SPAN - 2,
        BAY_DEPTH * 0.9 - 2,
        clerestoryY + CLERESTORY_HEIGHT,
        VAULT_RISE_NAVE,
        darkStone
      );
      v.position.set(0, 0, zCenter);
      vaultGroup.add(v);
    }
  }
  // Crossing vault (slightly larger span)
  const crossingVault = createRibbedVault(
    NAVE_SPAN + 2,
    NAVE_SPAN + 2,
    clerestoryY + CLERESTORY_HEIGHT,
    VAULT_RISE_NAVE + 6,
    darkStone
  );
  crossingVault.position.set(0, 0, 0);
  vaultGroup.add(crossingVault);
  root.add(vaultGroup);

  // Aisle vaults (lower, over each side-aisle bay)
  const aisleVaultGroup = new THREE.Group();
  aisleVaultGroup.name = 'AisleVaults';
  for (let b = -BAY_COUNT_NAVE / 2; b < BAY_COUNT_NAVE / 2; b++) {
    const zCenter = b * BAY_DEPTH + BAY_DEPTH / 2;
    for (const side of [-1, 1]) {
      const v = createRibbedVault(
        AISLE_SPAN - 1,                          // span across the aisle (X)
        BAY_DEPTH - 2,                           // span along the aisle (Z)
        PIER_HEIGHT_ARCADE + 1.4,
        AISLE_SPAN * 0.55,
        darkStone
      );
      v.position.set(
        side * (NAVE_SPAN / 2 + AISLE_SPAN / 2),
        0,
        zCenter
      );
      aisleVaultGroup.add(v);
    }
  }
  root.add(aisleVaultGroup);

  // =============================================
  // TRIFORIUM UPPER GALLERY ABOVE AISLES (extra layer of depth)
  // =============================================
  const upperGalleryGroup = new THREE.Group();
  upperGalleryGroup.name = 'UpperGalleries';
  for (const side of [-1, 1]) {
    // small flying-arch buttress-like projections on the outside for visual depth? we'll add external buttresses later.
    // For now, add a second gallery above the aisles at clerestory level.
    const gFloor = new THREE.Mesh(
      new THREE.BoxGeometry(AISLE_SPAN, 0.6, NAVE_LENGTH + 20),
      darkStone
    );
    gFloor.position.set(
      side * (NAVE_SPAN / 2 + AISLE_SPAN / 2),
      clerestoryY,
      0
    );
    upperGalleryGroup.add(gFloor);
  }
  root.add(upperGalleryGroup);

  // =============================================
  // CENTRAL DOME / CROSSING TOWER (lantern) rising higher
  // =============================================
  const lanternGroup = new THREE.Group();
  lanternGroup.name = 'CrossingLantern';
  const lanternBaseY = clerestoryY + CLERESTORY_HEIGHT + VAULT_RISE_NAVE + 6;
  const lanternSize = 30;
  const lanternHeight = 55;
  // Octagonal drum
  const drumGeom = new THREE.CylinderGeometry(lanternSize * 0.7, lanternSize * 0.8, 10, 8, 1, false);
  const drum = new THREE.Mesh(drumGeom, blackStone);
  drum.position.y = lanternBaseY + 5;
  lanternGroup.add(drum);
  // Tall arched windows in drum (one per face)
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2;
    const win = createLancetWindow(8, 10, i % 3 === 0 ? 0xffaa44 : 0x88aadd);
    win.position.set(
      Math.cos(a) * lanternSize * 0.72,
      lanternBaseY + 5,
      Math.sin(a) * lanternSize * 0.72
    );
    win.rotation.y = -a - Math.PI / 2;
    lanternGroup.add(win);
  }
  // Second tier (taller)
  const drum2 = new THREE.Mesh(
    new THREE.CylinderGeometry(lanternSize * 0.55, lanternSize * 0.65, 30, 8),
    darkStone
  );
  drum2.position.y = lanternBaseY + 5 + 20;
  lanternGroup.add(drum2);
  // Spire-like cone at top
  const spire = new THREE.Mesh(
    new THREE.ConeGeometry(lanternSize * 0.6, lanternHeight, 8),
    blackStone
  );
  spire.position.y = lanternBaseY + 5 + 30 + lanternHeight / 2;
  lanternGroup.add(spire);
  // Finial
  const finial = new THREE.Mesh(new THREE.ConeGeometry(0.6, 6, 8), goldMetal);
  finial.position.y = lanternBaseY + 5 + 30 + lanternHeight + 2;
  lanternGroup.add(finial);
  root.add(lanternGroup);

  // =============================================
  // EXTERIOR FLYING BUTTRESSES (visible through side windows, add silhouette)
  // =============================================
  const buttressGroup = new THREE.Group();
  for (let b = -BAY_COUNT_NAVE / 2; b <= BAY_COUNT_NAVE / 2; b++) {
    const z = b * BAY_DEPTH;
    for (const side of [-1, 1]) {
      const base = new THREE.Mesh(
        new THREE.BoxGeometry(3.5, 38, 4),
        blackStone
      );
      base.position.set(
        side * (NAVE_SPAN / 2 + AISLE_SPAN + 5),
        19,
        z
      );
      buttressGroup.add(base);
      // Top pinnacle
      const pin = new THREE.Mesh(
        new THREE.ConeGeometry(2.2, 8, 4),
        blackStone
      );
      pin.position.set(
        side * (NAVE_SPAN / 2 + AISLE_SPAN + 5),
        38 + 4,
        z
      );
      buttressGroup.add(pin);
      // Flying arch across to the clerestory wall
      const flier = buildPointedArchBoxes(
        10, 6, 1.6, 0.8, blackStone
      );
      flier.rotation.y = Math.PI / 2;
      flier.position.set(
        side * (NAVE_SPAN / 2 + AISLE_SPAN / 2 + 3),
        clerestoryY + 10,
        z
      );
      buttressGroup.add(flier);
    }
  }
  root.add(buttressGroup);

  // =============================================
  // THE CENTRAL MONUMENT: THE HANGING CROWN
  // A colossal fragmented crown/mask/keyhole form suspended by four titanic chains from the lantern vault.
  // It hangs directly above the crossing at the platform.
  // =============================================
  const monumentGroup = new THREE.Group();
  monumentGroup.name = 'TheHangingCrown';

  // Master dimensions: the monument is ~52 meters tall.
  const M_HALF_W = 14;
  const M_HEIGHT = 52;
  const M_Y_TOP = lanternBaseY - 4;
  const M_Y_BOTTOM = M_Y_TOP - M_HEIGHT;

  // Four titanic suspension chains (anchor up at the lantern drum, down to the crown ring)
  const chainR = M_HALF_W;
  const anchorY = lanternBaseY + 2;
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      const cx = sx * chainR;
      const cz = sz * chainR;
      // Vertical chain from anchor to ring
      const chain = createChain(anchorY, M_Y_TOP - 8, 1.8);
      chain.position.set(cx, 0, cz);
      monumentGroup.add(chain);
      // Massive anchor block where chain meets the lantern
      const anchor = new THREE.Mesh(
        new THREE.BoxGeometry(3, 2.2, 3),
        darkMetal
      );
      anchor.position.set(cx, anchorY + 1, cz);
      monumentGroup.add(anchor);
      // Secondary stabilizer chains angled out to the crossing vaults
      const stabChain = createChain(M_Y_TOP - 6, M_Y_TOP - 16, 0.9);
      stabChain.position.set(cx * 1.3, 0, cz * 1.3);
      monumentGroup.add(stabChain);
    }
  }

  // Main body: a colossal stylized keyhole/crown shape - wide upper ring, tapering lower body.
  // Upper crown ring (massive band of dark metal with pointed spires)
  const upperRing = new THREE.Mesh(
    new THREE.TorusGeometry(M_HALF_W, 3.5, 10, 48),
    darkMetal
  );
  upperRing.rotation.x = Math.PI / 2;
  upperRing.position.y = M_Y_TOP - 8;
  monumentGroup.add(upperRing);
  // Gold inlay band
  const goldBand = new THREE.Mesh(
    new THREE.TorusGeometry(M_HALF_W + 0.1, 0.5, 8, 48),
    goldMetal
  );
  goldBand.rotation.x = Math.PI / 2;
  goldBand.position.y = M_Y_TOP - 8;
  monumentGroup.add(goldBand);

  // Crown spikes pointing upward
  const spikeCount = 24;
  for (let i = 0; i < spikeCount; i++) {
    const a = (i / spikeCount) * Math.PI * 2;
    const h = 6 + Math.sin(i * 2.3) * 2;
    const spike = new THREE.Mesh(
      new THREE.ConeGeometry(1.2, h, 4),
      darkMetal
    );
    spike.position.set(
      Math.cos(a) * M_HALF_W,
      M_Y_TOP - 8 + 3.5 + h / 2,
      Math.sin(a) * M_HALF_W
    );
    monumentGroup.add(spike);
    // Gold tip
    const tip = new THREE.Mesh(
      new THREE.ConeGeometry(0.4, 1.4, 4),
      goldMetal
    );
    tip.position.set(
      Math.cos(a) * M_HALF_W,
      M_Y_TOP - 8 + 3.5 + h - 0.2,
      Math.sin(a) * M_HALF_W
    );
    monumentGroup.add(tip);
  }

  // Inner "mask" - a tapered angular face formed by trapezoidal panels.
  // Build a truncated pyramid (wider at top, narrower at bottom) representing an abstracted, massive face/body.
  const innerBodyGeom = new THREE.CylinderGeometry(M_HALF_W * 0.35, M_HALF_W * 0.9, M_HEIGHT - 18, 8, 1, false);
  const innerBody = new THREE.Mesh(innerBodyGeom, blackStone);
  innerBody.position.y = M_Y_TOP - 8 - (M_HEIGHT - 18) / 2;
  monumentGroup.add(innerBody);

  // "Eyes" - two giant angular windows that glow
  for (const side of [-1, 1]) {
    const eye = new THREE.Mesh(
      new THREE.BoxGeometry(5, 2.2, 0.6),
      new THREE.MeshStandardMaterial({
        color: 0xffc060,
        emissive: 0xffa040,
        emissiveIntensity: 3.5,
        roughness: 0.2,
        metalness: 0.1,
      })
    );
    eye.position.set(side * 3.5, M_Y_TOP - 20, M_HALF_W * 0.8);
    monumentGroup.add(eye);
  }

  // Horizontal rib rings around body
  for (let i = 0; i < 6; i++) {
    const t = i / 5;
    const r = M_HALF_W * (0.9 - t * 0.55);
    const y = M_Y_TOP - 12 - t * (M_HEIGHT - 22);
    const ring = new THREE.Mesh(
      new THREE.TorusGeometry(r, 0.6, 6, 32),
      goldMetal
    );
    ring.rotation.x = Math.PI / 2;
    ring.position.y = y;
    monumentGroup.add(ring);
  }

  // Lower hanging chains dangling from main body
  const shortChainCount = 12;
  for (let i = 0; i < shortChainCount; i++) {
    const a = (i / shortChainCount) * Math.PI * 2;
    const r = M_HALF_W * 0.7;
    const cx = Math.cos(a) * r;
    const cz = Math.sin(a) * r;
    const ch = createChain(M_Y_TOP - 22, M_Y_BOTTOM + 4, 0.8);
    ch.position.set(cx, 0, cz);
    monumentGroup.add(ch);
  }

  // Central lower pendant - a massive pointed keystone, like a giant inverted gem
  const pendant = new THREE.Mesh(
    new THREE.ConeGeometry(3.5, 9, 6),
    darkMetal
  );
  pendant.position.y = M_Y_BOTTOM + 4.5;
  pendant.rotation.x = Math.PI;
  monumentGroup.add(pendant);
  const pendantCap = new THREE.Mesh(
    new THREE.SphereGeometry(2.0, 10, 8),
    goldMetal
  );
  pendantCap.position.y = M_Y_BOTTOM + 9;
  monumentGroup.add(pendantCap);
  // Glowing core inside pendant (visible through gap? make it emissive)
  const core = new THREE.Mesh(
    new THREE.IcosahedronGeometry(1.3, 0),
    new THREE.MeshStandardMaterial({
      color: 0xffdd88,
      emissive: 0xffaa33,
      emissiveIntensity: 4.0,
      roughness: 0.2,
    })
  );
  core.position.y = M_Y_BOTTOM + 7;
  monumentGroup.add(core);

  // Radiating gothic tracery spokes connecting the upper ring to the body
  for (let i = 0; i < 24; i++) {
    const a = (i / 24) * Math.PI * 2;
    const x1 = Math.cos(a) * M_HALF_W;
    const z1 = Math.sin(a) * M_HALF_W;
    const y1 = M_Y_TOP - 8;
    const x2 = Math.cos(a) * M_HALF_W * 0.6;
    const z2 = Math.sin(a) * M_HALF_W * 0.6;
    const y2 = M_Y_TOP - 22;
    const dx = x2 - x1;
    const dy = y2 - y1;
    const dz = z2 - z1;
    const len = Math.sqrt(dx * dx + dy * dy + dz * dz);
    const spoke = new THREE.Mesh(
      new THREE.BoxGeometry(0.5, 0.7, len),
      darkMetal
    );
    spoke.position.set((x1 + x2) / 2, (y1 + y2) / 2, (z1 + z2) / 2);
    spoke.lookAt(x2, y2, z2);
    spoke.rotateX(Math.PI / 2);
    monumentGroup.add(spoke);
  }

  root.add(monumentGroup);

  // =============================================
  // APSE (east end) with high altar
  // =============================================
  const apseGroup = new THREE.Group();
  apseGroup.name = 'Apse';
  const eastZ = naveHalf + 8;
  // Apse wall (a cylindrical half-drum bulging east: theta 0 -> PI sweeps +X through +Z to -X)
  const apseWallGeom = new THREE.CylinderGeometry(
    APSE_RADIUS + 0.5, APSE_RADIUS + 0.5, PIER_HEIGHT_ARCADE + 1,
    24, 1, true,
    0, Math.PI
  );
  const apseWall = new THREE.Mesh(apseWallGeom, darkStone);
  apseWall.position.set(0, (PIER_HEIGHT_ARCADE + 1) / 2 + 0.5, eastZ);
  apseGroup.add(apseWall);

  // Half-dome apse vault (half-hemisphere bulging east)
  const apseVault = new THREE.Mesh(
    new THREE.SphereGeometry(APSE_RADIUS, 24, 14, 0, Math.PI, 0, Math.PI / 2),
    blackStone
  );
  apseVault.position.set(0, PIER_HEIGHT_ARCADE + 0.5, eastZ);
  apseGroup.add(apseVault);

  // High altar
  const altar = new THREE.Mesh(
    new THREE.BoxGeometry(8, 2.0, 3),
    blackStone
  );
  altar.position.set(0, 1.0, eastZ - 6);
  apseGroup.add(altar);
  const altarTop = new THREE.Mesh(
    new THREE.BoxGeometry(8.4, 0.3, 3.4),
    goldMetal
  );
  altarTop.position.set(0, 2.15, eastZ - 6);
  apseGroup.add(altarTop);
  // Altar retable (tall reredos)
  const reredos = new THREE.Mesh(
    new THREE.BoxGeometry(12, 18, 0.8),
    blackStone
  );
  reredos.position.set(0, 9 + 2.3, eastZ - 8);
  apseGroup.add(reredos);
  // Gilded cross on top
  const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.5, 4, 0.5), goldMetal);
  crossV.position.set(0, 20 + 2.3, eastZ - 8);
  apseGroup.add(crossV);
  const crossH = new THREE.Mesh(new THREE.BoxGeometry(2.5, 0.5, 0.5), goldMetal);
  crossH.position.set(0, 21 + 2.3, eastZ - 8);
  apseGroup.add(crossH);
  root.add(apseGroup);

  // =============================================
  // ENTRANCE (west end) with giant portal + narthex wall
  // =============================================
  const entranceGroup = new THREE.Group();
  entranceGroup.name = 'Entrance';
  const westZ = -NAVE_LENGTH / 2;
  const westWall = new THREE.Mesh(
    new THREE.BoxGeometry(TOTAL_WIDTH + 20, PIER_HEIGHT_ARCADE + 40, 2.5),
    blackStone
  );
  westWall.position.set(0, (PIER_HEIGHT_ARCADE + 40) / 2, westZ - 1);
  entranceGroup.add(westWall);
  // Three giant portals
  for (let p = -1; p <= 1; p++) {
    const span = 9;
    const rise = 20;
    const px = p * 12;
    const arch = buildPointedArchBoxes(span, rise, 2.8, 1.5, blackStone);
    arch.position.set(px, 0, westZ);
    entranceGroup.add(arch);
    // Doors: human-scale inside giant arch
    const door = new THREE.Mesh(
      new THREE.BoxGeometry(span - 2, rise - 1.5, 0.3),
      getWoodMat()
    );
    door.position.set(px, (rise - 1.5) / 2, westZ - 0.6);
    entranceGroup.add(door);
    // HUMAN-SIZED door cutout in middle: actually, the giant door itself establishes scale; to emphasize it, add a small human-scale door inset at the bottom center.
    const humanDoor = new THREE.Mesh(
      new THREE.BoxGeometry(1.6, 3.2, 0.15),
      darkMetal
    );
    humanDoor.position.set(px, 1.6, westZ - 0.5);
    entranceGroup.add(humanDoor);
  }
  // Great west rose window (giant circular)
  const roseRadius = 10;
  const roseOuter = new THREE.Mesh(
    new THREE.TorusGeometry(roseRadius, 1.0, 8, 48),
    blackStone
  );
  roseOuter.position.set(0, PIER_HEIGHT_ARCADE + 30, westZ - 1.2);
  entranceGroup.add(roseOuter);
  const roseGlass = new THREE.Mesh(
    new THREE.CircleGeometry(roseRadius - 0.4, 48),
    getStainedGlassMat(0x5577bb)
  );
  roseGlass.position.set(0, PIER_HEIGHT_ARCADE + 30, westZ - 1.0);
  entranceGroup.add(roseGlass);
  // Rose spokes
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2;
    const spoke = new THREE.Mesh(new THREE.BoxGeometry(roseRadius * 2, 0.3, 0.2), blackStone);
    spoke.position.set(0, PIER_HEIGHT_ARCADE + 30, westZ - 1.1);
    spoke.rotation.z = a;
    entranceGroup.add(spoke);
  }
  root.add(entranceGroup);

  // =============================================
  // TRANSEPT END WALLS
  // =============================================
  for (const side of [-1, 1]) {
    const tWall = new THREE.Mesh(
      new THREE.BoxGeometry(2.5, PIER_HEIGHT_ARCADE + CLERESTORY_HEIGHT + VAULT_RISE_NAVE + 4, TRANSEPT_HALF_LENGTH + 10),
      darkStone
    );
    tWall.position.set(
      side * (TRANSEPT_SPAN / 2 + AISLE_SPAN + 2),
      (PIER_HEIGHT_ARCADE + CLERESTORY_HEIGHT + VAULT_RISE_NAVE + 4) / 2,
      0
    );
    root.add(tWall);
    // Great transept window
    const winSpan = 14;
    const winRise = 30;
    const win = createLancetWindow(winSpan, winRise, side === -1 ? 0x774422 : 0x446677);
    win.position.set(
      side * (TRANSEPT_SPAN / 2 + AISLE_SPAN + 0.6),
      PIER_HEIGHT_ARCADE + 10,
      0
    );
    win.rotation.y = side === -1 ? Math.PI / 2 : -Math.PI / 2;
    root.add(win);
  }

  // =============================================
  // NEAR / HUMAN-SCALE ELEMENTS FOR SCALE REFERENCE
  // =============================================
  // Benches (pews) along nave, human-sized
  const pewsGroup = new THREE.Group();
  const pewTemplate = createBench();
  const pewRows = 18;
  for (let i = 0; i < pewRows; i++) {
    const z = -NAVE_LENGTH / 2 + 20 + i * 6;
    for (const side of [-1, 1]) {
      // central aisle gap of ~5m, pews on each side
      for (let row = 0; row < 4; row++) {
        const pew = pewTemplate.clone();
        pew.position.set(side * (4 + row * 2.5), 0, z);
        pew.rotation.y = side === -1 ? 0 : Math.PI;
        pewsGroup.add(pew);
      }
    }
  }
  root.add(pewsGroup);

  // Votive candles in clusters near entrance and in side chapels
  for (let i = 0; i < 40; i++) {
    const candle = createCandle(true);
    // cluster near piers
    const side = i % 2 === 0 ? -1 : 1;
    const along = Math.floor(i / 2);
    const z = -NAVE_LENGTH / 2 + 20 + along * 10;
    const jitter = (Math.random() - 0.5) * 2;
    candle.position.set(
      side * (NAVE_SPAN / 2 + AISLE_SPAN - 2) + jitter,
      0,
      z + jitter
    );
    candle.scale.setScalar(1.0);
    root.add(candle);
  }
  // Large candelabra (human-height) near crossing
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      const stand = new THREE.Mesh(
        new THREE.CylinderGeometry(0.3, 0.5, 2.4, 8),
        darkMetal
      );
      stand.position.set(sx * 8, 1.2, sz * 8);
      root.add(stand);
      const top = new THREE.Mesh(
        new THREE.ConeGeometry(1.0, 0.8, 8),
        goldMetal
      );
      top.position.set(sx * 8, 2.8, sz * 8);
      root.add(top);
      // A big candle on top
      const bigCandle = new THREE.Mesh(
        new THREE.CylinderGeometry(0.15, 0.18, 1.2, 8),
        new THREE.MeshStandardMaterial({ color: 0xefe0c2, roughness: 0.8 })
      );
      bigCandle.position.set(sx * 8, 3.5, sz * 8);
      root.add(bigCandle);
      const flame = new THREE.Mesh(
        new THREE.ConeGeometry(0.2, 0.6, 8),
        getEmissiveMat(0xffbb66, 3)
      );
      flame.position.set(sx * 8, 4.4, sz * 8);
      root.add(flame);
    }
  }

  // Statues (life-sized) in niches along outer aisle walls
  for (let b = -BAY_COUNT_NAVE / 2 + 1; b < BAY_COUNT_NAVE / 2; b++) {
    const z = b * BAY_DEPTH;
    for (const side of [-1, 1]) {
      const st = createStatue();
      st.position.set(
        side * (NAVE_SPAN / 2 + AISLE_SPAN - 1.2),
        0,
        z
      );
      root.add(st);
    }
  }

  // Two prominent human-height candelabra in the immediate foreground (near the viewer start at z ≈ -105)
  for (const side of [-1, 1]) {
    const cx = side * 4.5;
    const cz = -100;
    const base = new THREE.Mesh(
      new THREE.CylinderGeometry(0.35, 0.5, 0.6, 8),
      blackStone
    );
    base.position.set(cx, 0.3, cz);
    root.add(base);
    const stand = new THREE.Mesh(
      new THREE.CylinderGeometry(0.18, 0.22, 2.0, 10),
      darkMetal
    );
    stand.position.set(cx, 1.6, cz);
    root.add(stand);
    const top = new THREE.Mesh(
      new THREE.CylinderGeometry(0.5, 0.3, 0.3, 8),
      goldMetal
    );
    top.position.set(cx, 2.75, cz);
    root.add(top);
    const wax = new THREE.Mesh(
      new THREE.CylinderGeometry(0.12, 0.14, 0.6, 8),
      new THREE.MeshStandardMaterial({ color: 0xefe0c2, roughness: 0.8 })
    );
    wax.position.set(cx, 3.2, cz);
    root.add(wax);
    const flame = new THREE.Mesh(
      new THREE.ConeGeometry(0.18, 0.5, 8),
      getEmissiveMat(0xffbb66, 3)
    );
    flame.position.set(cx, 3.75, cz);
    root.add(flame);
    const light = new THREE.PointLight(0xffbb77, 1.2, 18, 2);
    light.position.set(cx, 3.5, cz);
    root.add(light);
  }

  // Railings around the crossing platform (human-height, obvious scale reference)
  for (let i = 0; i < 4; i++) {
    const isX = i % 2 === 0;
    const sign = i < 2 ? 1 : -1;
    const rail = createRailing(isX ? NAVE_SPAN - 2 : 20);
    if (isX) {
      rail.position.set(0, 0.6, sign * 10.5);
    } else {
      rail.rotation.y = Math.PI / 2;
      rail.position.set(sign * (NAVE_SPAN / 2 - 1), 0.6, 0);
    }
    root.add(rail);
  }

  // Spiral staircases in two corners at crossing (human-scale steps winding up)
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      const stairGroup = new THREE.Group();
      const stairBaseX = sx * (NAVE_SPAN / 2 + AISLE_SPAN - 3);
      const stairBaseZ = sz * (TRANSEPT_HALF_LENGTH - 8);
      // Central newel
      const newel = new THREE.Mesh(
        new THREE.CylinderGeometry(0.3, 0.3, 18, 10),
        darkStone
      );
      newel.position.set(stairBaseX, 9, stairBaseZ);
      stairGroup.add(newel);
      // Steps as small boxes spiraling
      const steps = 48;
      for (let i = 0; i < steps; i++) {
        const a = i * 0.3;
        const y = i * (18 / steps);
        const step = new THREE.Mesh(
          new THREE.BoxGeometry(1.3, 0.28, 0.4),
          lightStone
        );
        step.position.set(
          stairBaseX + Math.cos(a) * 1.0,
          y + 0.14,
          stairBaseZ + Math.sin(a) * 1.0
        );
        step.rotation.y = -a;
        stairGroup.add(step);
      }
      root.add(stairGroup);
    }
  }

  // =============================================
  // HANGING CHANDELIERS (some big, some small, hanging from vaults at various heights)
  // =============================================
  const chandelierGroup = new THREE.Group();
  chandelierGroup.name = 'Chandeliers';
  for (let b = -BAY_COUNT_NAVE / 2 + 1; b < BAY_COUNT_NAVE / 2; b += 2) {
    const z = b * BAY_DEPTH;
    const ch = buildChandelier(4.0, clerestoryY + CLERESTORY_HEIGHT + 2, clerestoryY + CLERESTORY_HEIGHT - 18);
    ch.position.set(0, 0, z);
    chandelierGroup.add(ch);
  }
  root.add(chandelierGroup);

  // =============================================
  // FOG VOLUME / BACK WALL far away (just atmospheric haze + distant silhouette geometry)
  // Add a dark distant wall/fog ring so the upper reaches fade into nothing.
  // =============================================
  // Upper shadowed ring way up high to suggest architecture fading into darkness
  const upperShadow = new THREE.Mesh(
    new THREE.CylinderGeometry(200, 200, 220, 24, 1, true),
    new THREE.MeshBasicMaterial({ color: 0x030305, side: THREE.BackSide, transparent: true, opacity: 0.9, depthWrite: false })
  );
  upperShadow.position.y = 170;
  upperShadow.userData.skipExport = true;
  root.add(upperShadow);

  // Distant tiny "windows" or lights high up to suggest impossible scale above
  for (let i = 0; i < 40; i++) {
    const a = Math.random() * Math.PI * 2;
    const r = 90 + Math.random() * 60;
    const y = 120 + Math.random() * 120;
    const pin = new THREE.Mesh(
      new THREE.PlaneGeometry(1.6, 5),
      new THREE.MeshBasicMaterial({ color: 0x5566aa, transparent: true, opacity: 0.6, side: THREE.DoubleSide })
    );
    pin.position.set(Math.cos(a) * r, y, Math.sin(a) * r);
    pin.lookAt(0, y, 0);
    root.add(pin);
  }

  return root;
}

/** Helper: build a pointed arch as a group of box voussoirs. Arch lies in X/Y plane, rises from y=0 to y=rise, spans from x=-span/2 to x=span/2. Depth is along Z. */
function buildPointedArchBoxes(
  span: number,
  rise: number,
  depth: number,
  thickness: number,
  mat: THREE.Material
): THREE.Group {
  const g = new THREE.Group();
  const half = span / 2;
  const segments = 14;
  for (let i = 0; i < segments; i++) {
    const t0 = i / segments;
    const t1 = (i + 1) / segments;
    for (const side of [-1, 1]) {
      // Quadratic bezier: P0=(side*half, 0), P1=(side*half*0.15, rise*0.9), P2=(0, rise)
      const bez = (t: number) => {
        const u = 1 - t;
        return {
          x: u * u * side * half + 2 * u * t * side * half * 0.15 + t * t * 0,
          y: u * u * 0 + 2 * u * t * rise * 0.9 + t * t * rise,
        };
      };
      const p0 = bez(t0);
      const p1 = bez(t1);
      const mx = (p0.x + p1.x) / 2;
      const my = (p0.y + p1.y) / 2;
      const dx = p1.x - p0.x;
      const dy = p1.y - p0.y;
      const segLen = Math.sqrt(dx * dx + dy * dy);
      const angle = Math.atan2(dy, dx);
      const block = new THREE.Mesh(
        new THREE.BoxGeometry(segLen + 0.05, thickness, depth),
        mat
      );
      block.position.set(mx, my, 0);
      const outAngle = angle + Math.PI / 2;
      block.position.x += Math.cos(outAngle) * (thickness / 2);
      block.position.y += Math.sin(outAngle) * (thickness / 2);
      block.rotation.z = angle;
      g.add(block);
    }
  }
  // springers / imposts at the bottom
  for (const side of [-1, 1]) {
    const impost = new THREE.Mesh(
      new THREE.BoxGeometry(thickness * 1.4, thickness * 0.8, depth + 0.2),
      mat
    );
    impost.position.set(side * half - side * thickness * 0.3, 0, 0);
    g.add(impost);
  }
  // Keystone at top center
  const key = new THREE.Mesh(
    new THREE.BoxGeometry(thickness * 1.6, thickness * 1.2, depth + 0.3),
    mat
  );
  key.position.set(0, rise, 0);
  g.add(key);
  return g;
}

function buildChandelier(ringR: number, yTop: number, yBot: number): THREE.Group {
  const g = new THREE.Group();
  const darkMetal = getDarkMetalMat();
  const gold = getGoldMetalMat();
  // Suspension rod
  const rod = new THREE.Mesh(
    new THREE.CylinderGeometry(0.15, 0.15, yTop - yBot, 6),
    darkMetal
  );
  rod.position.y = (yTop + yBot) / 2;
  g.add(rod);
  // Upper ceiling mount (rose)
  const rose = new THREE.Mesh(new THREE.ConeGeometry(1.2, 1.0, 8), darkMetal);
  rose.position.y = yTop;
  rose.rotation.x = Math.PI;
  g.add(rose);
  // Main ring
  const ring = new THREE.Mesh(
    new THREE.TorusGeometry(ringR, 0.25, 8, 32),
    gold
  );
  ring.rotation.x = Math.PI / 2;
  ring.position.y = yBot;
  g.add(ring);
  // Candles on ring
  const candleCount = 12;
  for (let i = 0; i < candleCount; i++) {
    const a = (i / candleCount) * Math.PI * 2;
    const cx = Math.cos(a) * ringR;
    const cz = Math.sin(a) * ringR;
    const cup = new THREE.Mesh(
      new THREE.CylinderGeometry(0.15, 0.1, 0.3, 6),
      darkMetal
    );
    cup.position.set(cx, yBot - 0.1, cz);
    g.add(cup);
    const c = new THREE.Mesh(
      new THREE.CylinderGeometry(0.08, 0.09, 0.6, 6),
      new THREE.MeshStandardMaterial({ color: 0xefe0c2, roughness: 0.8 })
    );
    c.position.set(cx, yBot + 0.35, cz);
    g.add(c);
    const f = new THREE.Mesh(
      new THREE.ConeGeometry(0.1, 0.25, 6),
      getEmissiveMat(0xffbb66, 3.0)
    );
    f.position.set(cx, yBot + 0.8, cz);
    g.add(f);
  }
  // Central pendant
  const pend = new THREE.Mesh(
    new THREE.SphereGeometry(0.6, 10, 8),
    gold
  );
  pend.position.y = yBot - 0.8;
  g.add(pend);
  return g;
}

// re-export the arch shape for convenience if needed elsewhere
export { gothicArchShape };
