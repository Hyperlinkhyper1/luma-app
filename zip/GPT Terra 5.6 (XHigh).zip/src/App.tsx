import { useState } from "react";

export default function App() {
  const [copied, setCopied] = useState(false);

  const copyPath = async () => {
    await navigator.clipboard.writeText("cathedral.glb");
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  return (
    <main className="relative flex min-h-screen overflow-hidden bg-[#05070b] px-7 py-10 text-stone-200">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_80%,rgba(15,43,95,0.42),transparent_50%),linear-gradient(180deg,#020306_0%,#0b1118_55%,#030407_100%)]" />
      <div className="relative z-10 my-auto max-w-xl">
        <p className="mb-7 text-[10px] font-semibold uppercase tracking-[0.36em] text-[#81a9ff]">Scene Artifact</p>
        <h1 className="font-serif text-5xl leading-[0.94] tracking-tight text-stone-100 sm:text-7xl">Cathedral of the Inverted Reliquary</h1>
        <p className="mt-7 max-w-md text-base leading-7 text-stone-400">
          A self-contained GLB scene built around a human-eye threshold, monumental nave, suspended reliquary, vast arches, and distant illuminated apse.
        </p>
        <button
          type="button"
          onClick={copyPath}
          className="mt-10 border-b border-[#7599ed] pb-1 text-xs font-semibold uppercase tracking-[0.2em] text-[#a9c2ff] transition hover:border-stone-100 hover:text-stone-100"
        >
          {copied ? "Path copied" : "Copy cathedral.glb path"}
        </button>
      </div>
      <div className="absolute bottom-10 right-7 h-28 w-px bg-gradient-to-b from-transparent via-[#6f94f1] to-transparent" />
    </main>
  );
}
