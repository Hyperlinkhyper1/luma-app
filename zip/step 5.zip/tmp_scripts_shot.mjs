// Screenshot helper: loads the built app and captures several viewpoints.
import puppeteer from "puppeteer";
import fs from "fs";

const OUT = process.env.OUT || "/tmp/shots";
const PORT = process.env.PORT || 8899;
fs.mkdirSync(OUT, { recursive: true });

const browser = await puppeteer.launch({
  headless: true,
  args: [
    "--no-sandbox",
    "--disable-setuid-sandbox",
    "--use-gl=angle",
    "--use-angle=swiftshader",
    "--enable-unsafe-swiftshader",
    "--window-size=1600,900",
  ],
});
const page = await browser.newPage();
await page.setViewport({ width: 1600, height: 900 });
page.on("console", (m) => console.log("[console]", m.text()));
page.on("pageerror", (e) => console.log("[pageerror]", e.message));
await page.goto(`http://127.0.0.1:${PORT}/index.html`, { waitUntil: "networkidle2", timeout: 120000 });

await page.waitForFunction(
  () => !!document.querySelector("canvas") && document.body.innerText.includes("DOWNLOAD"),
  { timeout: 240000 }
);
await new Promise((r) => setTimeout(r, 5000));

const labels = ["Narthex", "The Crossing", "Under the Eye", "Triforium gallery", "Choir & rose", "South aisle", "Monument base"];
for (let i = 0; i < labels.length; i++) {
  const clicked = await page.evaluate((label) => {
    const btns = Array.from(document.querySelectorAll("button"));
    const b = btns.find((x) => x.textContent?.includes(label));
    if (b) { b.click(); return true; }
    return false;
  }, labels[i]);
  if (!clicked) { console.log("no button for", labels[i]); continue; }
  await new Promise((r) => setTimeout(r, 6000));
  const file = `${OUT}/view_${i}_${labels[i].replace(/[^a-z]/gi, "")}.png`;
  await page.screenshot({ path: file });
  console.log("saved", file);
}
await browser.close();
