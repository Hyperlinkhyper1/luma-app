// ---------------------------------------------------------------------------
// Cathedral viewer: loads cathedral.glb, adds lighting, atmosphere and
// post-processing, and provides a set of inspection viewpoints.
// ---------------------------------------------------------------------------
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer.js";
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/examples/jsm/postprocessing/UnrealBloomPass.js";
import { OutputPass } from "three/examples/jsm/postprocessing/OutputPass.js";
import { VIEWS, type ViewDef } from "./views";

export type ViewerHandle = {
  dispose: () => void;
  goTo: (v: ViewDef) => void;
  setAutoRotate: (on: boolean) => void;
  stats: () => { fps: number; tris: number; height: number };
};

const SHAFT_VERT = /* glsl */ `
varying vec2 vUv;
varying vec3 vN;
varying vec3 vV;
void main() {
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  vN = normalize(normalMatrix * normal);
  vV = normalize(-mv.xyz);
  vUv = uv;
  gl_Position = projectionMatrix * mv;
}
`;

const SHAFT_FRAG = /* glsl */ `
uniform vec3 uColor;
uniform float uIntensity;
uniform float uPower;
varying vec2 vUv;
varying vec3 vN;
varying vec3 vV;
void main() {
  float along = pow(clamp(vUv.y, 0.0, 1.0), uPower);
  float fres = pow(1.0 - abs(dot(normalize(vN), normalize(vV))), 2.0);
  float a = (0.18 + 0.95 * fres) * along * uIntensity;
  gl_FragColor = vec4(uColor * a, 1.0);
}
`;

export async function createViewer(
  canvas: HTMLCanvasElement,
  opts: { fps?: number; fx?: boolean; dust?: number } = {}
): Promise<ViewerHandle> {
  const q = new URLSearchParams(window.location.search);
  const maxFps = opts.fps ?? Number(q.get("fps") || 0);
  const useFx = opts.fx ?? q.get("nofx") === null;
  const useLights = q.get("nolights") === null;
  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    powerPreference: "high-performance",
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.06;
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  const scene = new THREE.Scene();
  const FOG = new THREE.Color(0x070910);
  scene.background = FOG;
  scene.fog = new THREE.FogExp2(0x070910, 0.0042);

  const camera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.5, 3000);
  camera.position.set(0, 1.7, 88);

  const controls = new OrbitControls(camera, canvas);
  controls.enableDamping = true;
  controls.dampingFactor = 0.06;
  controls.minDistance = 2;
  controls.maxDistance = 900;
  controls.maxPolarAngle = Math.PI * 0.495;
  controls.target.set(0, 46, -60);

  // ---------------------------------------------------------------- lighting
  // Ambient / hemisphere fill so nothing is pure black, then the punctual
  // lights that came embedded in the GLB do the real work.
  scene.add(new THREE.HemisphereLight(0x2a3550, 0x05060a, 0.55));
  const fill = new THREE.DirectionalLight(0x8fb4ff, 0.35);
  fill.position.set(30, 260, 60);
  scene.add(fill);

  // ---------------------------------------------------------------- post
  const composer = new EffectComposer(renderer);
  composer.addPass(new RenderPass(scene, camera));
  let bloom: UnrealBloomPass | null = null;
  if (useFx) {
    bloom = new UnrealBloomPass(
      new THREE.Vector2(window.innerWidth, window.innerHeight),
      0.85,
      0.62,
      0.72
    );
    composer.addPass(bloom);
    composer.addPass(new OutputPass());
  }

  // ---------------------------------------------------------------- shafts
  function makeShaft(
    x: number,
    y: number,
    z: number,
    dir: THREE.Vector3,
    rTop: number,
    rBot: number,
    len: number,
    color: number,
    intensity: number,
    power = 1.15
  ) {
    const geo = new THREE.CylinderGeometry(rTop, rBot, len, 22, 1, true);
    geo.translate(0, -len / 2, 0);
    const mat = new THREE.ShaderMaterial({
      vertexShader: SHAFT_VERT,
      fragmentShader: SHAFT_FRAG,
      uniforms: {
        uColor: { value: new THREE.Color(color) },
        uIntensity: { value: intensity },
        uPower: { value: power },
      },
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z);
    const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, -1, 0), dir.clone().normalize());
    m.quaternion.copy(q);
    m.renderOrder = 5;
    scene.add(m);
    return m;
  }

  const shafts: THREE.Mesh[] = [];
  const BAYS = [75.5, 50.5, 25.5, 0, -25.5, -50.5, -75.5, -100.5];
  for (const sx of [-1, 1]) {
    for (const bz of BAYS) {
      for (const dx of [-5.6, 5.6]) {
        const dir = new THREE.Vector3(-sx * 0.72, -0.68, 0.12);
        shafts.push(
          makeShaft(sx * 29.2, 93, bz + dx, dir, 4.6, 15, 62, 0x9fc4ff, 0.5, 1.25)
        );
      }
    }
  }
  // great rose window at the far end
  shafts.push(makeShaft(0, 52, -128, new THREE.Vector3(0, -0.25, 0.96), 14, 22, 70, 0xff6a4a, 0.42, 1.5));
  // entrance portals
  shafts.push(makeShaft(0, 16, 98, new THREE.Vector3(0, -0.12, -0.99), 10, 16, 60, 0xfff0d8, 0.5, 1.5));
  for (const sx of [-1, 1])
    shafts.push(makeShaft(sx * 30, 11, 98, new THREE.Vector3(sx * 0.15, -0.2, -0.97), 6, 10, 48, 0xffe9c8, 0.3, 1.5));
  // tower shafts coming down through the eye
  shafts.push(makeShaft(0, 250, 40, new THREE.Vector3(0.1, -1, 0), 8, 20, 150, 0x9fc4ff, 0.16, 1.6));

  // ---------------------------------------------------------------- dust
  const dustCount = opts.dust ?? (q.get("dust") ? Number(q.get("dust")) : 5000);
  function dustTexture() {
    const c = document.createElement("canvas");
    c.width = c.height = 64;
    const g = c.getContext("2d")!;
    const grad = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    grad.addColorStop(0, "rgba(255,255,255,1)");
    grad.addColorStop(0.35, "rgba(255,255,255,0.35)");
    grad.addColorStop(1, "rgba(255,255,255,0)");
    g.fillStyle = grad;
    g.fillRect(0, 0, 64, 64);
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }
  const dustPos = new Float32Array(dustCount * 3);
  const dustSeed = new Float32Array(dustCount);
  for (let i = 0; i < dustCount; i++) {
    dustPos[i * 3] = (Math.random() - 0.5) * 150;
    dustPos[i * 3 + 1] = Math.random() * 150;
    dustPos[i * 3 + 2] = -140 + Math.random() * 250;
    dustSeed[i] = Math.random() * 100;
  }
  const dustGeo = new THREE.BufferGeometry();
  dustGeo.setAttribute("position", new THREE.BufferAttribute(dustPos, 3));
  const dustMat = new THREE.PointsMaterial({
    size: 0.55,
    map: dustTexture(),
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    opacity: 0.5,
    sizeAttenuation: true,
    color: 0xbfd4ff,
  });
  const dust = new THREE.Points(dustGeo, dustMat);
  dust.visible = dustCount > 0;
  scene.add(dust);

  // ---------------------------------------------------------------- load
  let tris = 0;
  const loader = new GLTFLoader();
  await new Promise<void>((resolve, reject) => {
    loader.load(
      "cathedral.glb",
      (gltf: any) => {
        const model = gltf.scene;
        model.traverse((o: any) => {
          const mesh = o as THREE.Mesh;
          if (mesh.isMesh) {
            mesh.castShadow = false;
            mesh.receiveShadow = false;
            mesh.frustumCulled = true;
            const idx = mesh.geometry.getIndex();
            tris += (idx ? idx.count : mesh.geometry.getAttribute("position").count) / 3;
          }
        });
        if (!useLights) {
          model.traverse((o: any) => {
            if (o.isLight) o.parent?.remove(o);
          });
        }
        scene.add(model);
        resolve();
      },
      (e: any) => {
        if (e.total) console.log(`loading ${((e.loaded / e.total) * 100).toFixed(0)}%`);
      },
      (err: any) => reject(err)
    );
  });

  // ---------------------------------------------------------------- loop
  let raf = 0;
  let fps = 60;
  let frames = 0;
  let acc = 0;
  const clock = new THREE.Clock();

  function resize() {
    const w = window.innerWidth;
    const h = window.innerHeight;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
    composer.setSize(w, h);
    bloom?.setSize(w, h);
  }
  window.addEventListener("resize", resize);

  let lastDraw = 0;
  function animate(now = 0) {
    raf = requestAnimationFrame(animate);
    if (maxFps && now - lastDraw < 1000 / maxFps - 1) return;
    lastDraw = now;
    const dt = Math.min(clock.getDelta(), 0.1);
    const t = clock.elapsedTime;

    controls.update();

    // dust drift
    if (dust.visible) {
    const p = dustGeo.getAttribute("position") as THREE.BufferAttribute;
    for (let i = 0; i < dustCount; i++) {
      const s = dustSeed[i];
      let y = p.getY(i) + dt * (0.35 + (s % 1) * 0.5);
      if (y > 150) y = 0;
      p.setY(i, y);
      p.setX(i, p.getX(i) + Math.sin(t * 0.12 + s) * dt * 0.35);
    }
    p.needsUpdate = true;
    }

    // gentle breathing of the light shafts
    for (let i = 0; i < shafts.length; i++) {
      const m = shafts[i].material as THREE.ShaderMaterial;
      m.uniforms.uIntensity.value = 0.42 + Math.sin(t * 0.25 + i) * 0.08;
    }

    composer.render();

    frames++;
    acc += dt;
    if (acc > 0.5) {
      fps = frames / acc;
      frames = 0;
      acc = 0;
    }
  }
  animate();

  // camera transition
  let transitioning = false;
  let tFrom = new THREE.Vector3();
  let tTo = new THREE.Vector3();
  let tgtFrom = new THREE.Vector3();
  let tgtTo = new THREE.Vector3();
  let tStart = 0;
  const T_DUR = 2.2;

  function goTo(v: ViewDef) {
    tFrom.copy(camera.position);
    tgtFrom.copy(controls.target);
    tTo.set(...v.pos);
    tgtTo.set(...v.target);
    tStart = performance.now();
    transitioning = true;
    if (v.fov) {
      camera.fov = v.fov;
      camera.updateProjectionMatrix();
    }
  }
  function stepTransition() {
    if (!transitioning) return;
    const k = Math.min(1, (performance.now() - tStart) / (T_DUR * 1000));
    const e = k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
    camera.position.lerpVectors(tFrom, tTo, e);
    controls.target.lerpVectors(tgtFrom, tgtTo, e);
    if (k >= 1) transitioning = false;
  }
  const transitionTimer = window.setInterval(stepTransition, 16);

  return {
    dispose: () => {
      cancelAnimationFrame(raf);
      window.clearInterval(transitionTimer);
      window.removeEventListener("resize", resize);
      controls.dispose();
      renderer.dispose();
    },
    goTo,
    setAutoRotate: (on: boolean) => {
      controls.autoRotate = on;
      controls.autoRotateSpeed = 0.35;
    },
    stats: () => ({ fps, tris, height: camera.position.y }),
  };
}

export { VIEWS };
