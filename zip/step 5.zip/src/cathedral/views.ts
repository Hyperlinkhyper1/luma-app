// Camera viewpoints used to inspect the cathedral from several positions.
export type ViewDef = {
  id: string;
  label: string;
  hint: string;
  pos: [number, number, number];
  target: [number, number, number];
  fov?: number;
};

export const VIEWS: ViewDef[] = [
  {
    id: "narthex",
    label: "Narthex",
    hint: "Human eye level (1.7 m) at the entrance, looking down the nave",
    pos: [0, 1.7, 88],
    target: [0, 46, -60],
    fov: 62,
  },
  {
    id: "crossing",
    label: "The Crossing",
    hint: "Beneath the monument, looking up into the Sundered Eye",
    pos: [0, 1.7, 26],
    target: [0, 96, 0],
    fov: 70,
  },
  {
    id: "eye",
    label: "Under the Eye",
    hint: "Directly below the breach in the vault, 146 m overhead",
    pos: [0, 1.7, 0],
    target: [0, 150, 0],
    fov: 75,
  },
  {
    id: "triforium",
    label: "Triforium gallery",
    hint: "38 m up, on the gallery balcony beside the clerestory",
    pos: [26, 40, 62],
    target: [-6, 60, -70],
    fov: 68,
  },
  {
    id: "choir",
    label: "Choir & rose",
    hint: "Before the great rose window at the far end",
    pos: [0, 1.7, -104],
    target: [0, 52, -131],
    fov: 60,
  },
  {
    id: "aisle",
    label: "South aisle",
    hint: "Looking up the flank of the nave from the aisle floor",
    pos: [52, 1.7, 30],
    target: [10, 80, -20],
    fov: 70,
  },
  {
    id: "monument",
    label: "Monument base",
    hint: "At the foot of the central monument, human scale",
    pos: [12, 1.7, 14],
    target: [0, 60, 0],
    fov: 66,
  },
];
