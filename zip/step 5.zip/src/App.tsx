import { useEffect, useRef, useState } from "react";
import { createViewer, type ViewerHandle } from "./cathedral/viewer";
import { VIEWS } from "./cathedral/views";

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const viewerRef = useRef<ViewerHandle | null>(null);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [active, setActive] = useState("narthex");
  const [hud, setHud] = useState({ fps: 0, tris: 0, height: 0 });
  const [panel, setPanel] = useState(true);

  useEffect(() => {
    let disposed = false;
    let handle: ViewerHandle | null = null;
    createViewer(canvasRef.current!)
      .then((h) => {
        if (disposed) {
          h.dispose();
          return;
        }
        handle = h;
        viewerRef.current = h;
        h.goTo(VIEWS[0]);
        setReady(true);
        const id = window.setInterval(() => setHud(h.stats()), 500);
        (window as unknown as { __hudTimer: number }).__hudTimer = id;
      })
      .catch((e) => setError(String(e)));
    return () => {
      disposed = true;
      handle?.dispose();
      const id = (window as unknown as { __hudTimer?: number }).__hudTimer;
      if (id) window.clearInterval(id);
    };
  }, []);

  const view = VIEWS.find((v) => v.id === active) ?? VIEWS[0];

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-black text-zinc-200">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />

      {/* vignette + grain overlay */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 45%, rgba(0,0,0,0.55) 100%)",
        }}
      />

      {/* loading */}
      {!ready && !error && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-black">
          <div className="h-[2px] w-56 overflow-hidden bg-zinc-800">
            <div className="h-full w-1/3 animate-[slide_1.4s_ease-in-out_infinite] bg-amber-200/80" />
          </div>
          <p className="font-serif text-sm tracking-[0.4em] text-zinc-400">RAISING THE CATHEDRAL</p>
        </div>
      )}

      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black p-10">
          <div className="max-w-md text-center">
            <p className="mb-2 font-serif text-lg text-amber-200">cathedral.glb could not be loaded</p>
            <p className="text-sm text-zinc-500">{error}</p>
          </div>
        </div>
      )}

      {/* title */}
      <div className="pointer-events-none absolute left-0 top-0 p-6 md:p-8">
        <h1 className="font-serif text-2xl font-semibold tracking-[0.25em] text-amber-100/90 drop-shadow-[0_2px_12px_rgba(0,0,0,0.9)] md:text-3xl">
          THE SUNDERED CHOIR
        </h1>
        <p className="mt-1 max-w-sm text-[11px] leading-relaxed tracking-widest text-zinc-400/80">
          A PROCEDURAL CATHEDRAL INTERIOR · 272 m OF VAULT ABOVE A 1.7 m EYE
        </p>
      </div>

      {/* viewpoint list */}
      <div className="absolute right-0 top-0 flex max-h-screen w-full flex-col items-end gap-1 p-4 md:w-auto md:p-6">
        <button
          onClick={() => setPanel((p) => !p)}
          className="mb-2 rounded-sm border border-zinc-700/70 bg-black/60 px-3 py-1 text-[10px] tracking-[0.3em] text-zinc-400 backdrop-blur hover:border-amber-200/50 hover:text-amber-100"
        >
          {panel ? "HIDE PANEL" : "SHOW PANEL"}
        </button>
        {panel &&
          VIEWS.map((v) => (
            <button
              key={v.id}
              onClick={() => {
                setActive(v.id);
                viewerRef.current?.goTo(v);
              }}
              className={`w-full max-w-[15rem] rounded-sm border px-3 py-2 text-right backdrop-blur transition ${
                active === v.id
                  ? "border-amber-200/60 bg-amber-950/40 text-amber-100"
                  : "border-zinc-800/70 bg-black/50 text-zinc-400 hover:border-zinc-600 hover:text-zinc-200"
              }`}
            >
              <span className="block text-[11px] tracking-[0.2em]">{v.label}</span>
              <span className="mt-0.5 block text-[9px] leading-snug tracking-wide opacity-60">
                {v.hint}
              </span>
            </button>
          ))}
      </div>

      {/* bottom bar */}
      <div className="pointer-events-none absolute bottom-0 left-0 flex w-full flex-wrap items-end justify-between gap-4 p-4 md:p-6">
        <div className="rounded-sm border border-zinc-800/70 bg-black/55 px-4 py-3 font-mono text-[10px] leading-relaxed tracking-wider text-zinc-400 backdrop-blur">
          <div>
            VIEWPOINT <span className="text-amber-200/90">{view.label}</span>
          </div>
          <div>
            EYE HEIGHT <span className="text-amber-200/90">{hud.height.toFixed(1)} m</span>{" "}
            <span className="text-zinc-600">/ human 1.7 m</span>
          </div>
          <div>
            GEOMETRY <span className="text-amber-200/90">{hud.tris.toLocaleString()}</span> TRIS ·{" "}
            <span className="text-amber-200/90">{hud.fps.toFixed(0)}</span> FPS
          </div>
        </div>

        <div className="pointer-events-auto flex flex-col items-end gap-2">
          <a
            href="cathedral.glb"
            download="cathedral.glb"
            className="rounded-sm border border-amber-200/50 bg-amber-950/50 px-4 py-2 text-[10px] tracking-[0.3em] text-amber-100 backdrop-blur transition hover:bg-amber-900/60"
          >
            DOWNLOAD cathedral.glb
          </a>
          <p className="max-w-[16rem] text-right text-[9px] leading-relaxed tracking-wide text-zinc-600">
            Drag to orbit · scroll to zoom · right-drag to pan. Everything you see is inside the
            single GLB file.
          </p>
        </div>
      </div>
    </div>
  );
}
