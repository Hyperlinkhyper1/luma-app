// ---------------------------------------------------------------------------
// Builds the cathedral and writes it out as a single self contained GLB.
// ---------------------------------------------------------------------------
import * as THREE from "three";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";
import { GLBWriter } from "./cathedral/glb.js";
import { buildCathedral } from "./cathedral/build.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const writer = new GLBWriter();
const t0 = Date.now();
const { root, lights, stats } = buildCathedral(writer);
root.updateMatrixWorld(true);

// ---- merge everything per material ---------------------------------------
const buckets = new Map();
let totalTris = 0;
root.traverse((o) => {
  if (!o.isMesh) return;
  const mat = o.material;
  const key = mat.userData.gltfMaterial ?? 0;
  const g = o.geometry.clone();
  g.applyMatrix4(o.matrixWorld);
  if (!g.getAttribute("uv")) {
    const n = g.getAttribute("position").count;
    g.setAttribute("uv", new THREE.BufferAttribute(new Float32Array(n * 2), 2));
  }
  if (!g.getAttribute("normal")) g.computeVertexNormals();
  if (!buckets.has(key)) buckets.set(key, { mat, name: o.name, geos: [] });
  buckets.get(key).geos.push(g);
  const idx = g.getIndex();
  totalTris += (idx ? idx.count : g.getAttribute("position").count) / 3;
});

const nodes = [];
for (const [key, b] of buckets) {
  const merged = mergeGeometries(b.geos, false);
  if (!merged) {
    console.error("merge failed for material", key, b.mat.name);
    continue;
  }
  merged.computeBoundingSphere();
  const verts = merged.getAttribute("position").count;
  const tris = (merged.getIndex()?.count ?? verts) / 3;
  const meshIdx = writer.addMesh(`${b.mat.name}`, merged, key);
  nodes.push(writer.addNode({ name: `${b.mat.name}`, mesh: meshIdx }));
  console.log(
    `  mesh ${b.mat.name.padEnd(18)} verts ${String(verts).padStart(8)} tris ${String(tris).padStart(8)}`
  );
}

// ---- lights ---------------------------------------------------------------
for (const l of lights) {
  const li = writer.addLight(l.def);
  const n = l.node;
  nodes.push(
    writer.addNode({
      name: l.def.name,
      light: li,
      translation: [n.position.x, n.position.y, n.position.z],
      rotation: [n.quaternion.x, n.quaternion.y, n.quaternion.z, n.quaternion.w],
    })
  );
}

const rootNode = writer.addNode({ name: "SunderedChoir", children: nodes });
const buf = writer.finish([rootNode]);

const out = path.join(__dirname, "..", "public", "cathedral.glb");
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, buf);

console.log(`\nbuilt in ${((Date.now() - t0) / 1000).toFixed(1)}s`);
console.log(`source meshes: ${stats.meshes}   source tris: ${Math.round(stats.tris)}`);
console.log(`output tris:   ${Math.round(totalTris)}`);
console.log(`nodes: ${nodes.length}  materials: ${writer.materials.length}  images: ${writer.images.length}`);
console.log(`GLB size: ${(buf.length / 1048576).toFixed(2)} MB -> ${out}`);
