// ---------------------------------------------------------------------------
// Minimal, dependency free GLB (glTF 2.0 binary) writer.
// Supports: meshes, PBR materials, embedded PNG textures, node hierarchy,
// KHR_lights_punctual.
// ---------------------------------------------------------------------------
import zlib from "zlib";

// --------------------------- PNG encoder -----------------------------------
const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function pngChunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, "ascii");
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
  return Buffer.concat([len, typeBuf, data, crcBuf]);
}

/** Encode an RGBA Uint8Array as a PNG buffer. */
export function encodePNG(width, height, rgba) {
  const sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // colour type RGBA
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;
  const stride = width * 4;
  const raw = Buffer.alloc((stride + 1) * height);
  for (let y = 0; y < height; y++) {
    raw[y * (stride + 1)] = 0; // filter: none
    rgba.copy
      ? rgba.copy(raw, y * (stride + 1) + 1, y * stride, y * stride + stride)
      : Buffer.from(rgba.buffer, rgba.byteOffset + y * stride, stride).copy(raw, y * (stride + 1) + 1);
  }
  const idat = zlib.deflateSync(raw, { level: 9, memLevel: 9 });
  return Buffer.concat([sig, pngChunk("IHDR", ihdr), pngChunk("IDAT", idat), pngChunk("IEND", Buffer.alloc(0))]);
}

// --------------------------- GLB builder -----------------------------------
const COMP = {
  BYTE: 5120,
  UNSIGNED_BYTE: 5121,
  SHORT: 5122,
  UNSIGNED_SHORT: 5123,
  UNSIGNED_INT: 5125,
  FLOAT: 5126,
};
const TYPE_SIZE = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT4: 16 };

export class GLBWriter {
  constructor() {
    this.binParts = [];
    this.binLength = 0;
    this.bufferViews = [];
    this.accessors = [];
    this.images = [];
    this.samplers = [];
    this.textures = [];
    this.materials = [];
    this.meshes = [];
    this.nodes = [];
    this.lights = [];
    this._texCache = new Map();
    this._samplerCache = new Map();
  }

  _pad() {
    const pad = (4 - (this.binLength % 4)) % 4;
    if (pad) {
      this.binParts.push(Buffer.alloc(pad));
      this.binLength += pad;
    }
  }

  /** Add a raw buffer view. `typed` may be a Buffer/Uint8Array/TypedArray. */
  addBufferView(typed, target) {
    this._pad();
    const byteOffset = this.binLength;
    const buf = Buffer.isBuffer(typed)
      ? typed
      : Buffer.from(typed.buffer, typed.byteOffset, typed.byteLength);
    this.binParts.push(buf);
    this.binLength += buf.length;
    const view = { buffer: 0, byteOffset, byteLength: buf.length };
    if (target) view.target = target;
    this.bufferViews.push(view);
    return this.bufferViews.length - 1;
  }

  addAccessor(view, componentType, type, count, extra = {}) {
    const a = { bufferView: view, componentType, count, type, ...extra };
    this.accessors.push(a);
    return this.accessors.length - 1;
  }

  addImagePNG(width, height, rgba, name) {
    const png = encodePNG(width, height, rgba);
    const view = this.addBufferView(png);
    const img = { bufferView: view, mimeType: "image/png" };
    if (name) img.name = name;
    this.images.push(img);
    return this.images.length - 1;
  }

  addSampler(magFilter, minFilter, wrapS, wrapT) {
    const key = `${magFilter}|${minFilter}|${wrapS}|${wrapT}`;
    if (this._samplerCache.has(key)) return this._samplerCache.get(key);
    const s = {};
    if (magFilter) s.magFilter = magFilter;
    if (minFilter) s.minFilter = minFilter;
    s.wrapS = wrapS;
    s.wrapT = wrapT;
    this.samplers.push(s);
    const i = this.samplers.length - 1;
    this._samplerCache.set(key, i);
    return i;
  }

  addTexture(imageIndex, sampler) {
    const key = `${imageIndex}|${sampler}`;
    if (this._texCache.has(key)) return this._texCache.get(key);
    const t = { source: imageIndex, sampler };
    this.textures.push(t);
    const i = this.textures.length - 1;
    this._texCache.set(key, i);
    return i;
  }

  addMaterial(def) {
    this.materials.push(def);
    return this.materials.length - 1;
  }

  /** geometry: BufferGeometry-like with position/normal/uv/index attributes */
  addMesh(name, geometry, materialIndex) {
    const attrs = {};
    const pos = geometry.getAttribute("position");
    const nor = geometry.getAttribute("normal");
    const uv = geometry.getAttribute("uv");
    const idx = geometry.getIndex();

    const posArr = Float32Array.from(pos.array);
    let min = [Infinity, Infinity, Infinity];
    let max = [-Infinity, -Infinity, -Infinity];
    for (let i = 0; i < posArr.length; i += 3) {
      for (let k = 0; k < 3; k++) {
        const v = posArr[i + k];
        if (v < min[k]) min[k] = v;
        if (v > max[k]) max[k] = v;
      }
    }
    const posView = this.addBufferView(posArr, 34962);
    attrs.POSITION = this.addAccessor(posView, COMP.FLOAT, "VEC3", pos.count, { min, max });

    if (nor) {
      const v = this.addBufferView(Float32Array.from(nor.array), 34962);
      attrs.NORMAL = this.addAccessor(v, COMP.FLOAT, "VEC3", nor.count);
    }
    if (uv) {
      const v = this.addBufferView(Float32Array.from(uv.array), 34962);
      attrs.TEXCOORD_0 = this.addAccessor(v, COMP.FLOAT, "VEC2", uv.count);
    }
    let indices = null;
    if (idx) {
      const arr = idx.array;
      const typed = arr.length > 65535 ? new Uint32Array(arr) : new Uint16Array(arr);
      const v = this.addBufferView(typed, 34963);
      indices = this.addAccessor(v, typed === arr ? COMP.UNSIGNED_INT : COMP.UNSIGNED_SHORT, "SCALAR", idx.count);
    }
    const mesh = { name, primitives: [{ attributes: attrs, material: materialIndex, indices }] };
    this.meshes.push(mesh);
    return this.meshes.length - 1;
  }

  addNode({ name, mesh, translation, rotation, scale, children, light, matrix }) {
    const n = {};
    if (name) n.name = name;
    if (mesh !== undefined) n.mesh = mesh;
    if (light !== undefined) {
      n.extensions = { ...(n.extensions || {}), KHR_lights_punctual: { light } };
    }
    if (children && children.length) n.children = children;
    if (matrix) n.matrix = matrix;
    if (translation) n.translation = translation;
    if (rotation) n.rotation = rotation;
    if (scale) n.scale = scale;
    this.nodes.push(n);
    return this.nodes.length - 1;
  }

  addLight(def) {
    this.lights.push(def);
    return this.lights.length - 1;
  }

  finish(rootNodes) {
    const buffer = Buffer.concat(this.binParts);
    const gltf = {
      asset: { version: "2.0", generator: "Megalophobic Cathedral procedural builder" },
      scene: 0,
      scenes: [{ nodes: rootNodes, name: "Sundered Choir" }],
      nodes: this.nodes,
      meshes: this.meshes,
      materials: this.materials,
    };
    if (this.accessors.length) gltf.accessors = this.accessors;
    if (this.bufferViews.length) gltf.bufferViews = this.bufferViews;
    if (this.images.length) gltf.images = this.images;
    if (this.samplers.length) gltf.samplers = this.samplers;
    if (this.textures.length) gltf.textures = this.textures;
    if (this.lights.length) {
      gltf.extensionsUsed = ["KHR_lights_punctual"];
      gltf.extensions = { KHR_lights_punctual: { lights: this.lights } };
    }
    gltf.buffers = [{ byteLength: buffer.length }];

    let json = Buffer.from(JSON.stringify(gltf), "utf8");
    const jsonPad = (4 - (json.length % 4)) % 4;
    if (jsonPad) json = Buffer.concat([json, Buffer.alloc(jsonPad, 0x20)]);

    let binChunk = buffer;
    const binPad = (4 - (binChunk.length % 4)) % 4;
    if (binPad) binChunk = Buffer.concat([binChunk, Buffer.alloc(binPad)]);

    const total = 12 + 8 + json.length + 8 + binChunk.length;
    const out = Buffer.alloc(total);
    let o = 0;
    out.writeUInt32LE(0x46546c67, o); o += 4;
    out.writeUInt32LE(2, o); o += 4;
    out.writeUInt32LE(total, o); o += 4;
    out.writeUInt32LE(json.length, o); o += 4;
    out.write("JSON", o, "ascii"); o += 4;
    json.copy(out, o); o += json.length;
    out.writeUInt32LE(binChunk.length, o); o += 4;
    out.write("BIN\0", o, "ascii"); o += 4;
    binChunk.copy(out, o);
    return out;
  }
}
