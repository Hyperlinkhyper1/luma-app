// ---------------------------------------------------------------------------
// Procedural texture generation for the cathedral.
// Pure JS (no canvas / no DOM) so it can run inside Node for the GLB export.
// Every texture is fully tileable and returns plain RGBA Uint8Arrays.
// ---------------------------------------------------------------------------

const TAU = Math.PI * 2;

function hash2(ix, iy, seed) {
  let h = Math.imul(ix | 0, 374761393) ^ Math.imul(iy | 0, 668265263) ^ Math.imul(seed | 0, 1274126177);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

function smooth(t) {
  return t * t * (3 - 2 * t);
}

/** Tileable value noise. u,v in [0,1). period = lattice cells across the texture. */
function vnoise(u, v, period, seed) {
  const x = u * period;
  const y = v * period;
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = smooth(x - ix);
  const fy = smooth(y - iy);
  const x0 = ((ix % period) + period) % period;
  const y0 = ((iy % period) + period) % period;
  const x1 = (x0 + 1) % period;
  const y1 = (y0 + 1) % period;
  const a = hash2(x0, y0, seed);
  const b = hash2(x1, y0, seed);
  const c = hash2(x0, y1, seed);
  const d = hash2(x1, y1, seed);
  return (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy;
}

/** Tileable fbm. */
function fbm(u, v, basePeriod, octaves, seed, gain = 0.5, lac = 2) {
  let amp = 1;
  let sum = 0;
  let norm = 0;
  let p = basePeriod;
  for (let i = 0; i < octaves; i++) {
    sum += amp * vnoise(u, v, p, seed + i * 131);
    norm += amp;
    amp *= gain;
    p *= lac;
  }
  return sum / norm;
}

/** Ridged / vein style noise */
function ridged(u, v, basePeriod, octaves, seed) {
  let amp = 1;
  let sum = 0;
  let norm = 0;
  let p = basePeriod;
  for (let i = 0; i < octaves; i++) {
    const n = 1 - Math.abs(vnoise(u, v, p, seed + i * 71) * 2 - 1);
    sum += amp * n * n;
    norm += amp;
    amp *= 0.55;
    p *= 2;
  }
  return sum / norm;
}

function clamp01(x) {
  return x < 0 ? 0 : x > 1 ? 1 : x;
}
function mix(a, b, t) {
  return a + (b - a) * t;
}
function mixc(c1, c2, t) {
  return [mix(c1[0], c2[0], t), mix(c1[1], c2[1], t), mix(c1[2], c2[2], t)];
}

/** Build a normal map (RGB) from a height field. */
function normalMap(size, heightAt, strength) {
  const out = new Uint8Array(size * size * 4);
  const e = 1 / size;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = (x + 0.5) / size;
      const v = (y + 0.5) / size;
      const hl = heightAt((u - e + 1) % 1, v);
      const hr = heightAt((u + e) % 1, v);
      const hd = heightAt(u, (v - e + 1) % 1);
      const hu = heightAt(u, (v + e) % 1);
      let nx = (hl - hr) * strength;
      let ny = (hd - hu) * strength;
      const nz = 1.0;
      const len = Math.hypot(nx, ny, nz);
      nx /= len;
      ny /= len;
      const i = (y * size + x) * 4;
      out[i] = (nx * 0.5 + 0.5) * 255;
      out[i + 1] = (ny * 0.5 + 0.5) * 255;
      out[i + 2] = (nz / len) * 0.5 * 255 + 127;
      out[i + 3] = 255;
    }
  }
  return out;
}

// ---------------------------------------------------------------------------
// STONE : dark, aged, blue-grey cathedral masonry with slab joints + grime
// ---------------------------------------------------------------------------
export function stoneTextures(size = 512) {
  const color = new Uint8Array(size * size * 4);
  const orm = new Uint8Array(size * size * 4);

  const P = 8; // slab grid: 8x8 slabs
  const dark = [0.086, 0.09, 0.104];
  const mid = [0.168, 0.174, 0.196];
  const light = [0.235, 0.238, 0.255];
  const grime = [0.045, 0.043, 0.05];

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = (x + 0.5) / size;
      const v = (y + 0.5) / size;

      // ---- large scale mottling / weathering
      const mottle = fbm(u, v, 4, 5, 11);
      const fine = fbm(u, v, 48, 3, 29);
      const grain = fbm(u, v, 160, 2, 71);

      // ---- slab joints (bevelled grooves)
      const gx = Math.abs(((u * P) % 1) - 0.5) * 2; // 0 at joint .. 1 mid slab
      const gy = Math.abs(((v * P) % 1) - 0.5) * 2;
      const jointX = 1 - smooth(clamp01((gx - 0.86) / 0.14));
      const jointY = 1 - smooth(clamp01((gy - 0.86) / 0.14));
      const joint = Math.max(jointX, jointY);
      // per slab tone variation
      const slabId = Math.floor(u * P) * 31 + Math.floor(v * P) * 17;
      const slabTone = hash2(Math.floor(u * P), Math.floor(v * P), 5);

      // ---- cracks: short random walk segments
      let crack = 0;
      for (let c = 0; c < 5; c++) {
        const a = hash2(c, 3, 91) * TAU;
        const px = hash2(c, 7, 13);
        const py = hash2(c, 11, 17);
        const len = 0.05 + hash2(c, 13, 23) * 0.22;
        let cx = px;
        let cy = py;
        let ang = a;
        let d = 1e9;
        for (let s = 0; s < 14; s++) {
          const dx = u - cx;
          const dy = v - cy;
          // wrap into [-0.5,0.5]
          const wx = dx - Math.round(dx);
          const wy = dy - Math.round(dy);
          d = Math.min(d, Math.hypot(wx, wy));
          ang += (hash2(c, s, 31) - 0.5) * 1.6;
          cx += Math.cos(ang) * (len / 14);
          cy += Math.sin(ang) * (len / 14);
        }
        crack = Math.max(crack, 1 - smooth(clamp01((d - 0.0016) / 0.004)));
      }

      // ---- vertical grime streaks (water running down the stone)
      const streak = fbm(u * 0.35 + 0.5, v * 4.0, 6, 4, 53);
      const grimeAmt = clamp01((streak - 0.42) * 2.2) * 0.75;

      let tone = mix(0, 1, clamp01(mottle * 1.25 - 0.1));
      tone = tone * 0.75 + slabTone * 0.25;
      let c = tone < 0.5 ? mixc(dark, mid, tone * 2) : mixc(mid, light, (tone - 0.5) * 2);
      c = mixc(c, [c[0] * 1.04, c[1] * 1.04, c[2] * 1.06], fine * 0.6);
      c = [c[0] * (0.94 + grain * 0.12), c[1] * (0.94 + grain * 0.12), c[2] * (0.94 + grain * 0.12)];
      // joints darken + recess
      c = mixc(c, [c[0] * 0.42, c[1] * 0.42, c[2] * 0.45], joint * 0.9);
      // cracks
      c = mixc(c, [0.02, 0.02, 0.024], crack * 0.85);
      // grime
      c = mixc(c, grime, grimeAmt);

      const i = (y * size + x) * 4;
      color[i] = clamp01(c[0]) * 255;
      color[i + 1] = clamp01(c[1]) * 255;
      color[i + 2] = clamp01(c[2]) * 255;
      color[i + 3] = 255;

      // ---- ORM (R=AO, G=roughness, B=metallic)
      const ao = mix(1.0, 0.55, joint) * mix(1.0, 0.9, grimeAmt) * (0.92 + mottle * 0.08);
      const rough = clamp01(0.99 - mottle * 0.16 - fine * 0.12 + grain * 0.05);
      orm[i] = clamp01(ao) * 255;
      orm[i + 1] = clamp01(rough) * 255;
      orm[i + 2] = 0;
      orm[i + 3] = 255;
    }
  }

  const height = (u, v) => {
    const gx = Math.abs(((u * P) % 1) - 0.5) * 2;
    const gy = Math.abs(((v * P) % 1) - 0.5) * 2;
    const jointX = 1 - smooth(clamp01((gx - 0.86) / 0.14));
    const jointY = 1 - smooth(clamp01((gy - 0.86) / 0.14));
    const joint = Math.max(jointX, jointY);
    const mottle = fbm(u, v, 4, 4, 11);
    const fine = fbm(u, v, 40, 3, 29);
    return (1 - joint * 0.85) * 0.6 + mottle * 0.25 + fine * 0.15;
  };

  return {
    color,
    orm,
    normal: normalMap(256, height, 26),
    normalSize: 256,
  };
}

// ---------------------------------------------------------------------------
// MARBLE : pale bone-white veined stone for trim, statues and inlay
// ---------------------------------------------------------------------------
export function marbleTextures(size = 512) {
  const color = new Uint8Array(size * size * 4);
  const orm = new Uint8Array(size * size * 4);
  const pale = [0.68, 0.655, 0.6];
  const warm = [0.79, 0.755, 0.67];
  const vein = [0.36, 0.34, 0.32];

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = (x + 0.5) / size;
      const v = (y + 0.5) / size;
      const warp = fbm(u, v, 5, 4, 3) * 0.35;
      const veins = ridged(u + warp, v - warp * 0.6, 7, 5, 41);
      const fine = fbm(u, v, 60, 3, 5);
      const vv = clamp01((veins - 0.62) * 3.4);
      let c = mixc(pale, warm, fbm(u, v, 3, 4, 9) * 0.8 + fine * 0.2);
      c = mixc(c, vein, vv * 0.75);
      c = [c[0] * (0.97 + fine * 0.06), c[1] * (0.97 + fine * 0.06), c[2] * (0.97 + fine * 0.06)];

      const i = (y * size + x) * 4;
      color[i] = clamp01(c[0]) * 255;
      color[i + 1] = clamp01(c[1]) * 255;
      color[i + 2] = clamp01(c[2]) * 255;
      color[i + 3] = 255;
      orm[i] = clamp01(0.95 + fine * 0.05) * 255;
      orm[i + 1] = clamp01(0.34 + veins * 0.3 + fine * 0.12) * 255;
      orm[i + 2] = 0;
      orm[i + 3] = 255;
    }
  }
  const height = (u, v) => {
    const warp = fbm(u, v, 5, 3, 3) * 0.3;
    const veins = ridged(u + warp, v - warp * 0.6, 7, 4, 41);
    return 0.6 + veins * 0.4;
  };
  return { color, orm, normal: normalMap(256, height, 14), normalSize: 256 };
}

// ---------------------------------------------------------------------------
// METAL : oxidised bronze / blackened iron with patina
// ---------------------------------------------------------------------------
export function metalTextures(size = 512) {
  const color = new Uint8Array(size * size * 4);
  const orm = new Uint8Array(size * size * 4);
  const iron = [0.055, 0.05, 0.048];
  const ironLit = [0.12, 0.11, 0.105];
  const patina = [0.16, 0.29, 0.26];
  const patinaLit = [0.3, 0.46, 0.4];

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = (x + 0.5) / size;
      const v = (y + 0.5) / size;
      const pat = fbm(u, v, 6, 5, 21);
      const brush = fbm(u * 6, v * 0.4, 24, 3, 61); // anisotropic brushed streaks
      const pits = fbm(u, v, 90, 2, 7);
      const patMask = clamp01((pat - 0.44) * 2.6);
      let c = mixc(iron, ironLit, brush * 0.8 + pits * 0.2);
      c = mixc(c, mixc(patina, patinaLit, brush), patMask * 0.85);
      c = [c[0] * (0.9 + pits * 0.2), c[1] * (0.9 + pits * 0.2), c[2] * (0.9 + pits * 0.2)];

      const i = (y * size + x) * 4;
      color[i] = clamp01(c[0]) * 255;
      color[i + 1] = clamp01(c[1]) * 255;
      color[i + 2] = clamp01(c[2]) * 255;
      color[i + 3] = 255;
      const rough = clamp01(0.34 + patMask * 0.4 + pits * 0.2 - brush * 0.08);
      const metal = mix(0.95, 0.72, patMask);
      orm[i] = 255;
      orm[i + 1] = rough * 255;
      orm[i + 2] = metal * 255;
      orm[i + 3] = 255;
    }
  }
  const height = (u, v) => {
    const pat = fbm(u, v, 6, 4, 21);
    const pits = fbm(u, v, 80, 3, 7);
    const brush = fbm(u * 6, v * 0.4, 24, 3, 61);
    return 0.45 + pat * 0.3 + pits * 0.15 + brush * 0.1;
  };
  return { color, orm, normal: normalMap(256, height, 12), normalSize: 256 };
}

// ---------------------------------------------------------------------------
// GLASS LEADING : luminous window with bronze leading (used for colour+emissive)
// ---------------------------------------------------------------------------
export function glassLeadingTexture(size = 512) {
  const color = new Uint8Array(size * size * 4);
  const lead = 0.035; // leading half width in uv
  const bar = (u, c) => Math.abs(u - c) < lead ? 1 : 0;

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = (x + 0.5) / size;
      const v = (y + 0.5) / size;
      let l = 0;
      // vertical mullions
      for (const c of [0.0, 0.25, 0.5, 0.75, 1.0]) l = Math.max(l, bar(u, c));
      // horizontal transoms
      for (const c of [0.18, 0.42, 0.66, 0.9]) l = Math.max(l, bar(v, c));
      // diagonal tracery
      const d1 = Math.abs(((u - v) + 1) % 1 - 0.5);
      l = Math.max(l, d1 < lead * 1.4 ? 1 : 0);
      const d2 = Math.abs(((u + v) + 1) % 1 - 0.5);
      l = Math.max(l, d2 < lead * 1.4 ? 1 : 0);
      // central rose ring
      const cx = u - 0.5;
      const cy = v - 0.5;
      const r = Math.hypot(cx, cy);
      const ring = Math.abs(r - 0.24);
      l = Math.max(l, ring < lead ? 1 : 0);
      l = Math.max(l, r < lead * 0.9 ? 1 : 0);
      // spoke
      const ang = Math.atan2(cy, cx);
      const spoke = Math.min(Math.abs(ang - Math.PI / 4), Math.abs(ang + Math.PI / 4), Math.abs(ang - (Math.PI * 5) / 4), Math.abs(ang + (Math.PI * 3) / 4));
      if (r < 0.24 && spoke < 0.035) l = 1;

      const glass = 0.72 + fbm(u, v, 14, 3, 3) * 0.28;
      const leadC = [0.06, 0.055, 0.05];
      const c = mixc([glass, glass, glass], leadC, l * 0.96);
      const i = (y * size + x) * 4;
      color[i] = c[0] * 255;
      color[i + 1] = c[1] * 255;
      color[i + 2] = c[2] * 255;
      color[i + 3] = 255;
    }
  }
  return { color, orm: null, normal: null };
}

// ---------------------------------------------------------------------------
// FLOOR INLAY : monumental radial mosaic for the crossing disc
// ---------------------------------------------------------------------------
export function inlayTexture(size = 1024) {
  const color = new Uint8Array(size * size * 4);
  const bone = [0.6, 0.575, 0.52];
  const boneDark = [0.42, 0.4, 0.37];
  const bronze = [0.2, 0.27, 0.24];
  const dark = [0.07, 0.072, 0.082];

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = (x + 0.5) / size;
      const v = (y + 0.5) / size;
      const dx = u - 0.5;
      const dy = v - 0.5;
      const r = Math.hypot(dx, dy) * 2; // 0..1 at edge
      const ang = Math.atan2(dy, dx);

      let c;
      const rings = [0.1, 0.28, 0.3, 0.46, 0.48, 0.66, 0.68, 0.9];
      let band = -1;
      for (let i = 0; i < rings.length; i += 2) {
        if (r > rings[i] && r < rings[i + 1]) band = i / 2;
      }
      const marbleTone = fbm(u, v, 10, 4, 5);
      if (r > 1.0) {
        c = dark;
      } else if (band < 0) {
        c = mixc(bone, boneDark, marbleTone);
      } else if (band % 2 === 0) {
        c = mixc(bronze, [0.32, 0.4, 0.36], marbleTone * 0.7);
      } else {
        c = mixc(boneDark, bone, marbleTone);
      }
      // radial spokes
      const spoke = ((ang / TAU) * 24) % 1;
      if (r > 0.3 && r < 0.9 && (spoke < 0.09 || spoke > 0.91)) c = mixc(c, bronze, 0.85);
      // star of eight points
      const star = Math.abs(Math.cos(ang * 4)) * 0.5 + 0.5;
      if (r < 0.28 && star > 0.86) c = mixc(c, [0.55, 0.5, 0.42], 0.8);
      // outer grime
      c = mixc(c, dark, clamp01((r - 0.75) * 1.6) * 0.7);

      const i = (y * size + x) * 4;
      color[i] = clamp01(c[0]) * 255;
      color[i + 1] = clamp01(c[1]) * 255;
      color[i + 2] = clamp01(c[2]) * 255;
      color[i + 3] = 255;
    }
  }
  return { color };
}

// ---------------------------------------------------------------------------
// BANNER : dark cloth with a gold emblem
// ---------------------------------------------------------------------------
export function bannerTexture(size = 256) {
  const color = new Uint8Array(size * size * 4);
  const cloth = [0.1, 0.045, 0.05];
  const cloth2 = [0.16, 0.06, 0.06];
  const gold = [0.62, 0.5, 0.22];
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = (x + 0.5) / size;
      const v = (y + 0.5) / size;
      const weave = fbm(u * 40, v * 40, 32, 2, 3);
      let c = mixc(cloth, cloth2, weave);
      // gold ring emblem
      const dx = u - 0.5;
      const dy = v - 0.32;
      const r = Math.hypot(dx, dy * 1.6);
      if (Math.abs(r - 0.16) < 0.018) c = gold;
      if (r < 0.018 && Math.abs(dy) < 0.3) c = gold;
      if (Math.abs(dx) < 0.012 && Math.abs(dy) < 0.3) c = gold;
      // bottom tassels
      if (v > 0.94) c = mixc(c, gold, 0.35);
      const i = (y * size + x) * 4;
      color[i] = clamp01(c[0]) * 255;
      color[i + 1] = clamp01(c[1]) * 255;
      color[i + 2] = clamp01(c[2]) * 255;
      color[i + 3] = 255;
    }
  }
  return { color };
}

// ---------------------------------------------------------------------------
// GLYPH : glowing sacred symbol (used emissive on altar / monument)
// ---------------------------------------------------------------------------
export function glyphTexture(size = 256) {
  const color = new Uint8Array(size * size * 4);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = (x + 0.5) / size;
      const v = (y + 0.5) / size;
      const dx = u - 0.5;
      const dy = v - 0.5;
      let g = 0;
      // concentric rings
      const r = Math.hypot(dx, dy);
      for (const rr of [0.1, 0.2, 0.3, 0.4]) {
        if (Math.abs(r - rr) < 0.012) g = 1;
      }
      // radial ticks
      const ang = Math.atan2(dy, dx);
      for (let i = 0; i < 12; i++) {
        const a = (i / 12) * TAU;
        if (r < 0.44 && Math.abs(ang - a) < 0.02) g = 1;
      }
      // inner triangle
      const tri = Math.max(
        Math.abs(dx) < 0.012 && dy > -0.2 && dy < 0.2 ? 1 : 0,
        Math.abs(dx + dy * 0.577) < 0.014 && dy > -0.2 && dy < 0.2 ? 1 : 0,
        Math.abs(dx - dy * 0.577) < 0.014 && dy > -0.2 && dy < 0.2 ? 1 : 0
      );
      g = Math.max(g, tri);
      const glow = clamp01((0.46 - r) * 2.2) * 0.25 + g;
      const i = (y * size + x) * 4;
      color[i] = glow * 255;
      color[i + 1] = glow * 0.85 * 255;
      color[i + 2] = glow * 0.5 * 255;
      color[i + 3] = 255;
    }
  }
  return { color };
}
