// ---------------------------------------------------------------------------
// Geometry helpers for the cathedral builder.
// Everything is emitted as an indexed BufferGeometry with position/normal/uv
// so that meshes can be merged per material for the GLB export.
// ---------------------------------------------------------------------------
import * as THREE from "three";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";

const _a = new THREE.Vector3();
const _b = new THREE.Vector3();
const _c = new THREE.Vector3();
const _d = new THREE.Vector3();
const _n = new THREE.Vector3();
const _ab = new THREE.Vector3();
const _ad = new THREE.Vector3();

/** Build a quad from 4 points (a,b,c,d going around). UVs are world sized. */
export function quad(a, b, c, d, tile = 4, wantNormal = null) {
  _a.fromArray(a);
  _b.fromArray(b);
  _c.fromArray(c);
  _d.fromArray(d);
  _ab.subVectors(_b, _a);
  _ad.subVectors(_d, _a);
  _n.crossVectors(_ab, _ad);
  if (_n.lengthSq() < 1e-12) return null;
  _n.normalize();
  if (wantNormal && _n.dot(_n.fromArray(wantNormal)) < 0) {
    const t = _b.clone();
    _b.copy(_d);
    _d.copy(t);
    _ab.subVectors(_b, _a);
    _ad.subVectors(_d, _a);
    _n.crossVectors(_ab, _ad).normalize();
  }
  const uLen = _ab.length() / tile;
  const vLen = _ad.length() / tile;
  const positions = new Float32Array([..._a.toArray(), ..._b.toArray(), ..._c.toArray(), ..._d.toArray()]);
  const normals = new Float32Array([..._n.toArray(), ..._n.toArray(), ..._n.toArray(), ..._n.toArray()]);
  const uvs = new Float32Array([0, 0, uLen, 0, uLen, vLen, 0, vLen]);
  const index = new Uint32Array([0, 1, 2, 0, 2, 3]);
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  g.setAttribute("normal", new THREE.BufferAttribute(normals, 3));
  g.setAttribute("uv", new THREE.BufferAttribute(uvs, 2));
  g.setIndex(new THREE.BufferAttribute(index, 1));
  return g;
}

/** Axis aligned box with correct per-face world sized UVs. */
export function box(w, h, d, tile = 4) {
  const g = new THREE.BufferGeometry();
  const pos = [];
  const nor = [];
  const uv = [];
  const idx = [];
  const hx = w / 2;
  const hy = h / 2;
  const hz = d / 2;
  const faces = [
    [[hx, -hy, -hz], [hx, hy, -hz], [hx, hy, hz], [hx, -hy, hz], [1, 0, 0]],
    [[-hx, -hy, hz], [-hx, hy, hz], [-hx, hy, -hz], [-hx, -hy, -hz], [-1, 0, 0]],
    [[-hx, hy, -hz], [hx, hy, -hz], [hx, hy, hz], [-hx, hy, hz], [0, 1, 0]],
    [[-hx, -hy, hz], [hx, -hy, hz], [hx, -hy, -hz], [-hx, -hy, -hz], [0, -1, 0]],
    [[hx, -hy, hz], [hx, hy, hz], [-hx, hy, hz], [-hx, -hy, hz], [0, 0, 1]],
    [[-hx, -hy, -hz], [-hx, hy, -hz], [hx, hy, -hz], [hx, -hy, -hz], [0, 0, -1]],
  ];
  let base = 0;
  for (const [a, b, c, dd, n] of faces) {
    const q = quad(a, b, c, dd, tile, n);
    if (!q) continue;
    const p = q.getAttribute("position");
    const nn = q.getAttribute("normal");
    const u = q.getAttribute("uv");
    for (let i = 0; i < p.count; i++) {
      pos.push(p.getX(i), p.getY(i), p.getZ(i));
      nor.push(nn.getX(i), nn.getY(i), nn.getZ(i));
      uv.push(u.getX(i), u.getY(i));
    }
    idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
    base += 4;
  }
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute("normal", new THREE.Float32BufferAttribute(nor, 3));
  g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  return g;
}

/** Wedge / trapezoidal prism between two arcs (arch voussoirs). */
export function wedge(innerR, outerR, a0, a1, depth, tile = 4) {
  const parts = [];
  const mid = (a0 + a1) / 2;
  const nm = [Math.cos(mid), Math.sin(mid), 0];
  const p0 = [Math.cos(a0) * innerR, Math.sin(a0) * innerR, -depth / 2];
  const p1 = [Math.cos(a1) * innerR, Math.sin(a1) * innerR, -depth / 2];
  const p2 = [Math.cos(a1) * outerR, Math.sin(a1) * outerR, -depth / 2];
  const p3 = [Math.cos(a0) * outerR, Math.sin(a0) * outerR, -depth / 2];
  parts.push(quad(p3, p2, p1, p0, tile, nm));
  const q0 = [Math.cos(a0) * innerR, Math.sin(a0) * innerR, depth / 2];
  const q1 = [Math.cos(a1) * innerR, Math.sin(a1) * innerR, depth / 2];
  const q2 = [Math.cos(a1) * outerR, Math.sin(a1) * outerR, depth / 2];
  const q3 = [Math.cos(a0) * outerR, Math.sin(a0) * outerR, depth / 2];
  parts.push(quad(q0, q1, q2, q3, tile, nm));
  parts.push(quad(p0, q0, q3, p3, tile, [Math.cos(a0), Math.sin(a0), 0]));
  parts.push(quad(p1, p2, q2, q1, tile, [Math.cos(a1), Math.sin(a1), 0]));
  return mergeGeos(parts);
}

export function cyl(rTop, rBot, h, radial = 12, tile = 4, capped = true) {
  const g = new THREE.CylinderGeometry(rTop, rBot, h, radial, 1, !capped);
  scaleUV(g, (rTop + rBot) / tile, h / tile);
  return g;
}

export function tubeCurve(curve, radius, tubular = 8, radial = 6, tile = 4) {
  const g = new THREE.TubeGeometry(curve, tubular, radius, radial, false);
  scaleUV(g, curve.getLength() / tile, (Math.PI * 2 * radius) / tile);
  return g;
}

export function torus(radius, tube, radialSeg = 6, tubularSeg = 24, tile = 4) {
  const g = new THREE.TorusGeometry(radius, tube, radialSeg, tubularSeg);
  scaleUV(g, (Math.PI * 2 * radius) / tile, (Math.PI * 2 * tube) / tile);
  return g;
}

export function sphere(r, wSeg = 12, hSeg = 8, tile = 4) {
  const g = new THREE.SphereGeometry(r, wSeg, hSeg);
  scaleUV(g, (Math.PI * r) / tile, (Math.PI * r) / tile);
  return g;
}

export function cone(r, h, seg = 10, tile = 4) {
  const g = new THREE.ConeGeometry(r, h, seg, 1);
  scaleUV(g, (Math.PI * 2 * r) / tile, h / tile);
  return g;
}

/** Flat disc in the XY plane (normal +Z), UVs mapped once across the disc. */
export function disc(r, seg = 32) {
  return new THREE.CircleGeometry(r, seg);
}

export function lathe(profile, segments = 16, tile = 4) {
  const pts = profile.map((p) => new THREE.Vector2(p[0], p[1]));
  const g = new THREE.LatheGeometry(pts, segments);
  scaleUV(g, 1 / tile, 1 / tile);
  return g;
}

export function scaleUV(geo, su, sv) {
  const uv = geo.getAttribute("uv");
  for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * su, uv.getY(i) * sv);
  uv.needsUpdate = true;
  return geo;
}

export function mergeGeos(list) {
  const clean = list.filter(Boolean);
  if (!clean.length) return null;
  if (clean.length === 1) return clean[0];
  return mergeGeometries(clean, false) || clean[0];
}

/** Translate / rotate / scale a geometry in place. */
export function xform(geo, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0, s = null) {
  const m = new THREE.Matrix4();
  const q = new THREE.Quaternion().setFromEuler(new THREE.Euler(rx, ry, rz, "XYZ"));
  m.compose(
    new THREE.Vector3(x, y, z),
    q,
    new THREE.Vector3(s ? s[0] : 1, s ? s[1] : 1, s ? s[2] : 1)
  );
  geo.applyMatrix4(m);
  return geo;
}

export function place(geo, mat, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) {
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y, z);
  m.rotation.set(rx, ry, rz);
  return m;
}

/** Flat quad in the XZ plane (floors, daises, platforms). */
export function floorQuad(cx, cz, w, d, tile = 4, y = 0) {
  const hw = w / 2;
  const hd = d / 2;
  return quad(
    [cx - hw, y, cz - hd],
    [cx + hw, y, cz - hd],
    [cx + hw, y, cz + hd],
    [cx - hw, y, cz + hd],
    tile,
    [0, 1, 0]
  );
}

/** Vertical quad in the XY plane (walls, banners, glass). */
export function wallQuad(cx, cy, cz, w, h, tile = 4, nx = 0, nz = 1) {
  const hw = w / 2;
  const hh = h / 2;
  return quad(
    [cx - hw, cy - hh, cz],
    [cx + hw, cy - hh, cz],
    [cx + hw, cy + hh, cz],
    [cx - hw, cy + hh, cz],
    tile,
    [nx, 0, nz]
  );
}
