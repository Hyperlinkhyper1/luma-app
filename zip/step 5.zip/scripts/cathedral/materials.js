// ---------------------------------------------------------------------------
// Material definitions. Each entry builds a three.js material (used while
// authoring) and the matching glTF 2.0 material definition (used on export).
// ---------------------------------------------------------------------------
import * as THREE from "three";
import {
  stoneTextures,
  marbleTextures,
  metalTextures,
  glassLeadingTexture,
  inlayTexture,
  bannerTexture,
  glyphTexture,
} from "./textures.js";

export function createMaterials(writer) {
  const stone = stoneTextures(512);
  const marble = marbleTextures(512);
  const metal = metalTextures(512);
  const lead = glassLeadingTexture(512);
  const inlay = inlayTexture(1024);
  const banner = bannerTexture(256);
  const glyph = glyphTexture(256);

  const REPEAT = 10497;
  const LINEAR = 9729;
  const LINEAR_MIP = 9987;

  const imgStone = writer.addImagePNG(512, 512, stone.color, "stone_albedo");
  const imgStoneORM = writer.addImagePNG(256, stone.normalSize, stone.orm, "stone_orm");
  const imgStoneN = writer.addImagePNG(stone.normalSize, stone.normalSize, stone.normal, "stone_normal");
  const imgMarble = writer.addImagePNG(512, 512, marble.color, "marble_albedo");
  const imgMarbleORM = writer.addImagePNG(256, marble.normalSize, marble.orm, "marble_orm");
  const imgMarbleN = writer.addImagePNG(marble.normalSize, marble.normalSize, marble.normal, "marble_normal");
  const imgMetal = writer.addImagePNG(512, 512, metal.color, "metal_albedo");
  const imgMetalORM = writer.addImagePNG(256, metal.normalSize, metal.orm, "metal_orm");
  const imgMetalN = writer.addImagePNG(metal.normalSize, metal.normalSize, metal.normal, "metal_normal");
  const imgLead = writer.addImagePNG(512, 512, lead.color, "glass_leading");
  const imgInlay = writer.addImagePNG(1024, 1024, inlay.color, "floor_inlay");
  const imgBanner = writer.addImagePNG(256, 256, banner.color, "banner");
  const imgGlyph = writer.addImagePNG(256, 256, glyph.color, "glyph");

  const sColor = writer.addSampler(LINEAR, LINEAR_MIP, REPEAT, REPEAT);
  const sLinear = writer.addSampler(LINEAR, LINEAR, REPEAT, REPEAT);
  const sClamp = writer.addSampler(LINEAR, LINEAR_MIP, 33071, 33071);

  const tex = {
    stoneC: writer.addTexture(imgStone, sColor),
    stoneORM: writer.addTexture(imgStoneORM, sLinear),
    stoneN: writer.addTexture(imgStoneN, sLinear),
    marbleC: writer.addTexture(imgMarble, sColor),
    marbleORM: writer.addTexture(imgMarbleORM, sLinear),
    marbleN: writer.addTexture(imgMarbleN, sLinear),
    metalC: writer.addTexture(imgMetal, sColor),
    metalORM: writer.addTexture(imgMetalORM, sLinear),
    metalN: writer.addTexture(imgMetalN, sLinear),
    lead: writer.addTexture(imgLead, sColor),
    inlay: writer.addTexture(imgInlay, sColor),
    banner: writer.addTexture(imgBanner, sColor),
    glyph: writer.addTexture(imgGlyph, sColor),
  };
  const clampTex = {
    inlay: writer.addTexture(imgInlay, sClamp),
    glyph: writer.addTexture(imgGlyph, sClamp),
  };

  const mats = {};
  const defs = {};

  function standard(name, opts) {
    const {
      map,
      normalMap,
      ormMap,
      color = 0xffffff,
      roughness = 1,
      metalness = 1,
      normalScale = 1,
      emissive = 0x000000,
      emissiveMap,
      emissiveIntensity = 1,
      doubleSided = false,
      transparent = false,
      opacity = 1,
      clampOcclusion = false,
    } = opts;
    const m = new THREE.MeshStandardMaterial({
      color,
      roughness,
      metalness,
      normalScale: new THREE.Vector2(normalScale, normalScale),
      emissive,
      emissiveIntensity,
      side: doubleSided ? THREE.DoubleSide : THREE.FrontSide,
      transparent,
      opacity,
      flatShading: false,
    });
    if (map) m.map = map;
    if (normalMap) m.normalMap = normalMap;
    if (ormMap) {
      m.roughnessMap = ormMap;
      m.metalnessMap = ormMap;
      m.aoMap = ormMap;
    }
    if (emissiveMap) m.emissiveMap = emissiveMap;

    const pbr = {
      baseColorFactor: [
        ((color >> 16) & 255) / 255,
        ((color >> 8) & 255) / 255,
        (color & 255) / 255,
        opacity,
      ],
      metallicFactor: metalness,
      roughnessFactor: roughness,
    };
    if (map) pbr.baseColorTexture = { index: map.userData.gltfIndex };
    if (ormMap) {
      pbr.metallicRoughnessTexture = { index: ormMap.userData.gltfIndex };
      if (!clampOcclusion) pbr.occlusionTexture = { index: ormMap.userData.gltfIndex };
    }
    if (normalMap) pbr.normalTexture = { index: normalMap.userData.gltfIndex, scale: normalScale };
    const def = { name, doubleSided, pbrMetallicRoughness: pbr };
    if (emissiveMap || emissive !== 0x000000) {
      const e = new THREE.Color(emissive).multiplyScalar(emissiveIntensity);
      def.emissiveFactor = [Math.min(1, e.r), Math.min(1, e.g), Math.min(1, e.b)];
      if (emissiveMap) def.emissiveTexture = { index: emissiveMap.userData.gltfIndex };
    }
    if (transparent) def.alphaMode = "BLEND";
    m.userData.gltfMaterial = writer.addMaterial(def);
    mats[name] = m;
    return m;
  }

  // --- textures as three textures (only needed if the scene is built in a browser)
  function mkTex(gltfIndex, img, srgb) {
    const t = new THREE.Texture();
    t.userData.gltfIndex = gltfIndex;
    t.userData.imageData = img;
    if (srgb) t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }
  const T = {
    stoneC: mkTex(tex.stoneC, { data: stone.color, width: 512, height: 512 }, true),
    stoneORM: mkTex(tex.stoneORM, { data: stone.orm, width: 256, height: 256 }, false),
    stoneN: mkTex(tex.stoneN, { data: stone.normal, width: 256, height: 256 }, false),
    marbleC: mkTex(tex.marbleC, { data: marble.color, width: 512, height: 512 }, true),
    marbleORM: mkTex(tex.marbleORM, { data: marble.orm, width: 256, height: 256 }, false),
    marbleN: mkTex(tex.marbleN, { data: marble.normal, width: 256, height: 256 }, false),
    metalC: mkTex(tex.metalC, { data: metal.color, width: 512, height: 512 }, true),
    metalORM: mkTex(tex.metalORM, { data: metal.orm, width: 256, height: 256 }, false),
    metalN: mkTex(tex.metalN, { data: metal.normal, width: 256, height: 256 }, false),
    lead: mkTex(tex.lead, { data: lead.color, width: 512, height: 512 }, true),
    inlay: mkTex(clampTex.inlay, { data: inlay.color, width: 1024, height: 1024 }, true),
    banner: mkTex(tex.banner, { data: banner.color, width: 256, height: 256 }, true),
    glyph: mkTex(clampTex.glyph, { data: glyph.color, width: 256, height: 256 }, true),
  };

  const M = {};

  M.stone = standard("agedStone", {
    map: T.stoneC,
    ormMap: T.stoneORM,
    normalMap: T.stoneN,
    color: 0xffffff,
    roughness: 1,
    metalness: 1,
    normalScale: 1.1,
  });
  M.stoneWarm = standard("warmStone", {
    map: T.stoneC,
    ormMap: T.stoneORM,
    normalMap: T.stoneN,
    color: 0xb9b2a4,
    roughness: 1,
    metalness: 1,
    normalScale: 1.0,
  });
  M.stoneDark = standard("shadowStone", {
    map: T.stoneC,
    ormMap: T.stoneORM,
    normalMap: T.stoneN,
    color: 0x6a6a72,
    roughness: 1,
    metalness: 1,
    normalScale: 0.8,
  });
  M.marble = standard("boneMarble", {
    map: T.marbleC,
    ormMap: T.marbleORM,
    normalMap: T.marbleN,
    color: 0xd8d2c4,
    roughness: 1,
    metalness: 1,
    normalScale: 0.6,
  });
  M.metal = standard("oxidisedBronze", {
    map: T.metalC,
    ormMap: T.metalORM,
    normalMap: T.metalN,
    color: 0xffffff,
    roughness: 1,
    metalness: 1,
    normalScale: 0.9,
  });
  M.iron = standard("blackIron", {
    map: T.metalC,
    ormMap: T.metalORM,
    normalMap: T.metalN,
    color: 0x8a8580,
    roughness: 1,
    metalness: 1,
    normalScale: 1.0,
  });
  M.gold = standard("sacredGold", {
    map: T.metalC,
    ormMap: T.metalORM,
    normalMap: T.metalN,
    color: 0xffd98a,
    roughness: 0.32,
    metalness: 1,
    normalScale: 0.4,
  });
  M.glassCrimson = standard("crimsonGlass", {
    map: T.lead,
    color: 0x8c1420,
    roughness: 0.25,
    metalness: 0.1,
    emissive: 0xff2a18,
    emissiveMap: T.lead,
    emissiveIntensity: 1.5,
  });
  M.glassCyan = standard("coldGlass", {
    map: T.lead,
    color: 0x9fc4e8,
    roughness: 0.2,
    metalness: 0.1,
    emissive: 0x9fc8ff,
    emissiveMap: T.lead,
    emissiveIntensity: 1.6,
  });
  M.glassWhite = standard("blindingGlass", {
    map: T.lead,
    color: 0xffffff,
    roughness: 0.3,
    metalness: 0.0,
    emissive: 0xffffff,
    emissiveMap: T.lead,
    emissiveIntensity: 2.2,
  });
  M.inlay = standard("crossingInlay", {
    map: T.inlay,
    color: 0xffffff,
    roughness: 0.45,
    metalness: 0.35,
    clampOcclusion: true,
  });
  M.banner = standard("cathedralBanner", {
    map: T.banner,
    color: 0xffffff,
    roughness: 0.95,
    metalness: 0.0,
    doubleSided: true,
  });
  M.glyph = standard("sacredGlyph", {
    map: T.glyph,
    color: 0xffffff,
    roughness: 0.4,
    metalness: 0.2,
    emissive: 0xffb45a,
    emissiveMap: T.glyph,
    emissiveIntensity: 2.4,
  });
  M.core = standard("monumentCore", {
    color: 0xffd9a0,
    roughness: 0.4,
    metalness: 0.0,
    emissive: 0xffc070,
    emissiveIntensity: 2.6,
  });
  M.water = standard("blackWater", {
    map: T.stoneC,
    ormMap: T.stoneORM,
    color: 0x0a0c10,
    roughness: 0.06,
    metalness: 0.55,
    normalScale: 0.15,
  });

  return { mats: M, defs, textures: T };
}
