// ---------------------------------------------------------------------------
// THE SUNDERED CHOIR
// A procedurally generated megalophobic cathedral interior.
//
// Architectural language: monumental gothic brutalism.  Colossal compound
// piers carry a triple division (arcade / triforium / clerestory) beneath a
// steep pointed barrel vault that is breached at the crossing by a circular
// opening - the "Sundered Eye" - through which the central monument rises into
// darkness.
//
// All dimensions are metres.  Human eye height = 1.7 m.
// ---------------------------------------------------------------------------
import * as THREE from "three";
import {
  quad,
  box,
  cyl,
  torus,
  sphere,
  cone,
  lathe,
  tubeCurve,
  disc,
  mergeGeos,
  xform,
  floorQuad,
  wallQuad,
} from "./geom.js";
import { createMaterials } from "./materials.js";

// ------------------------------------------------------------------ constants
const WALL_XI = 30; // clerestory wall inner face (nave side)
const WALL_XO = 42; // clerestory wall outer face (aisle side)
const PIER_X = 33;
const PIER_W = 14;
const PIER_D = 10;
const AISLE_X = 64; // outer wall inner face
const OUT_T = 4;

const ARC_Y = 22; // arcade springing
const ARC_S = 24; // arcade span
const ARC_RISE = 16;

const TRIF_Y = 38.5; // triforium floor
const TRIF_TOP = 46.5; // triforium ceiling / aisle vault springing
const AISLE_S = 22;
const AISLE_RISE = 11.5;

const CLER_BOT = 56;
const CLER_TOP = 94;

const VS = 98; // vault springing
const VR = 48; // vault rise
const VRIDGE = VS + VR;

const EYE_R = 24;

const PZ = [88, 63, 38, 13, -13, -38, -63, -88, -113];
const Z_IN = 96;
const Z_OUT = 100;
const Z_FAR = -131;
const Z_FAR_OUT = -135;

const TOWER_TOP = 250;
const HALO_Y = 272;
const HALO_R = 60;

const HUMAN = 1.7;

const BAYS = [];
for (let i = 0; i < PZ.length - 1; i++) BAYS.push({ a: PZ[i], b: PZ[i + 1], c: (PZ[i] + PZ[i + 1]) / 2 });

// ------------------------------------------------------------------- helpers
function archY(x, S, H) {
  const cx = (H * H - (S * S) / 4) / S;
  const R = (H * H + (S * S) / 4) / S;
  const c = x <= 0 ? cx : -cx;
  const v = R * R - (x - c) * (x - c);
  return v <= 0 ? 0 : Math.sqrt(v);
}

function wedgeLocal(innerR, outerR, a0, a1, depth, tile) {
  const parts = [];
  const mid = (a0 + a1) / 2;
  const nm = [Math.cos(mid), Math.sin(mid), 0];
  const p0 = [Math.cos(a0) * innerR, Math.sin(a0) * innerR, -depth / 2];
  const p1 = [Math.cos(a1) * innerR, Math.sin(a1) * innerR, -depth / 2];
  const p2 = [Math.cos(a1) * outerR, Math.sin(a1) * outerR, -depth / 2];
  const p3 = [Math.cos(a0) * outerR, Math.sin(a0) * outerR, -depth / 2];
  parts.push(quad(p3, p2, p1, p0, tile, nm));
  const q0 = [Math.cos(a0) * innerR, Math.sin(a0) * innerR, depth / 2];
  const q1 = [Math.cos(a1) * innerR, Math.sin(a1) * innerR, depth / 2];
  const q2 = [Math.cos(a1) * outerR, Math.sin(a1) * outerR, depth / 2];
  const q3 = [Math.cos(a0) * outerR, Math.sin(a0) * outerR, depth / 2];
  parts.push(quad(q0, q1, q2, q3, tile, nm));
  parts.push(quad(p0, q0, q3, p3, tile, [Math.cos(a0), Math.sin(a0), 0]));
  parts.push(quad(p1, p2, q2, q1, tile, [Math.cos(a1), Math.sin(a1), 0]));
  return mergeGeos(parts);
}

/** Pointed arch band (voussoirs) centred on x=0, springing at y=0. */
function archGeo(S, H, thick, depth, segs = 14, tile = 3) {
  const cx = (H * H - (S * S) / 4) / S;
  const R = (H * H + (S * S) / 4) / S;
  const parts = [];
  const addArc = (cxx, a0, a1, n) => {
    for (let i = 0; i < n; i++) {
      const t0 = a0 + ((a1 - a0) * i) / n;
      const t1 = a0 + ((a1 - a0) * (i + 1)) / n;
      parts.push(xform(wedgeLocal(R, R + thick, t0, t1, depth, tile), cxx, 0, 0));
    }
  };
  addArc(cx, Math.atan2(H, -cx), Math.PI, segs);
  addArc(-cx, 0, Math.atan2(H, cx), segs);
  return mergeGeos(parts);
}

function pointInPoly(x, y, poly) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const xi = poly[i][0];
    const yi = poly[i][1];
    const xj = poly[j][0];
    const yj = poly[j][1];
    if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}

/** Wall in the XY plane: front face at z=0 (normal +Z), back at z=-thick. */
function wallWithHoles(x0, x1, y0, y1, thick, holes, tile = 4) {
  const xs = new Set([x0, x1]);
  const ys = new Set([y0, y1]);
  for (const h of holes)
    for (const p of h.pts) {
      xs.add(Math.round(p[0] * 1e5) / 1e5);
      ys.add(Math.round(p[1] * 1e5) / 1e5);
    }
  const X = [...xs].sort((a, b) => a - b);
  const Y = [...ys].sort((a, b) => a - b);
  const parts = [];
  const inside = (x, y) => holes.some((h) => pointInPoly(x, y, h.pts));

  for (let i = 0; i < X.length - 1; i++) {
    for (let j = 0; j < Y.length - 1; j++) {
      const ax = X[i],
        bx = X[i + 1],
        ay = Y[j],
        by = Y[j + 1];
      if (bx - ax < 1e-6 || by - ay < 1e-6) continue;
      if (inside((ax + bx) / 2, (ay + by) / 2)) continue;
      parts.push(quad([ax, ay, 0], [bx, ay, 0], [bx, by, 0], [ax, by, 0], tile, [0, 0, 1]));
      parts.push(quad([ax, ay, -thick], [bx, ay, -thick], [bx, by, -thick], [ax, by, -thick], tile, [0, 0, -1]));
    }
  }
  for (const h of holes) {
    const pts = h.pts;
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i];
      const b = pts[(i + 1) % pts.length];
      const mx = (a[0] + b[0]) / 2;
      const my = (a[1] + b[1]) / 2;
      let nx = -(b[1] - a[1]);
      let ny = b[0] - a[0];
      const l = Math.hypot(nx, ny) || 1;
      nx /= l;
      ny /= l;
      if (inside(mx + nx * 0.06, my + ny * 0.06)) {
        nx = -nx;
        ny = -ny;
      }
      parts.push(quad([a[0], a[1], 0], [b[0], b[1], 0], [b[0], b[1], -thick], [a[0], a[1], -thick], tile, [nx, ny, 0]));
    }
  }
  return mergeGeos(parts);
}

/** Wall running along Z at x = xc. face +1 -> material face towards +X. */
function wallX(z0, z1, y0, y1, thick, holes, tile, xc, face) {
  const g = wallWithHoles(z0, z1, y0, y1, thick, holes, tile);
  if (!g) return null;
  if (face > 0) {
    g.rotateY(Math.PI / 2);
    g.translate(xc + thick, 0, z0 + z1);
  } else {
    g.rotateY(-Math.PI / 2);
    g.translate(xc - thick, 0, z0);
  }
  return g;
}

/** Wall in the XY plane centred on z = zc (thickness along Z). */
function wallZ(x0, x1, y0, y1, thick, holes, tile, zc) {
  const g = wallWithHoles(x0, x1, y0, y1, thick, holes, tile);
  if (!g) return null;
  g.translate(0, 0, zc + thick / 2);
  return g;
}

function archHole(cx, yBot, S, H, samples = 14) {
  const c = (H * H - (S * S) / 4) / S;
  const R = (H * H + (S * S) / 4) / S;
  const aApex = Math.atan2(H, -c);
  const aApexR = Math.atan2(H, c);
  const pts = [
    [cx - S / 2, yBot],
    [cx - S / 2, yBot + 0.002],
  ];
  for (let i = 0; i <= samples; i++) {
    const t = Math.PI - (Math.PI - aApex) * (i / samples);
    pts.push([c + R * Math.cos(t), yBot + R * Math.sin(t)]);
  }
  for (let i = 0; i <= samples; i++) {
    const t = aApexR * (1 - i / samples);
    pts.push([-c + R * Math.cos(t), yBot + R * Math.sin(t)]);
  }
  pts.push([cx + S / 2, yBot]);
  return { pts };
}

function rectHole(x0, x1, y0, y1) {
  return {
    pts: [
      [x0, y0],
      [x1, y0],
      [x1, y1],
      [x0, y1],
    ],
  };
}

function circleHole(cx, cy, r, n = 28) {
  const pts = [];
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    pts.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]);
  }
  return { pts };
}

/** Barrel vault webbing. */
function vaultWeb(x0, x1, z0, z1, springY, rise, nx, nz, tile, skip) {
  const xa = Math.min(x0, x1);
  const xb = Math.max(x0, x1);
  const span = xb - xa;
  const cxx = (xa + xb) / 2;
  const parts = [];
  for (let i = 0; i < nx; i++) {
    for (let j = 0; j < nz; j++) {
      const ax = xa + (span * i) / nx;
      const bx = xa + (span * (i + 1)) / nx;
      const az = z0 + ((z1 - z0) * j) / nz;
      const bz = z0 + ((z1 - z0) * (j + 1)) / nz;
      const mx = (ax + bx) / 2;
      const mz = (az + bz) / 2;
      if (skip && skip(mx, mz)) continue;
      const h0 = springY + archY(Math.abs(ax - cxx), span, rise);
      const h1 = springY + archY(Math.abs(bx - cxx), span, rise);
      parts.push(
        quad([ax, h0, az], [bx, h1, az], [bx, h1, bz], [ax, h0, bz], tile, [0, -1, 0])
      );
    }
  }
  return mergeGeos(parts);
}

// ------------------------------------------------------------------- figures
function figureGeometry(h) {
  const parts = [];
  parts.push(
    lathe(
      [
        [0.0, 0],
        [0.3, 0],
        [0.29, 0.12],
        [0.24, 0.45],
        [0.19, 0.8],
        [0.15, 1.1],
        [0.13, 1.32],
        [0.11, 1.4],
      ],
      10,
      2
    )
  );
  parts.push(xform(sphere(0.105, 10, 8, 2), 0, 1.5, 0));
  parts.push(xform(box(0.42, 0.12, 0.26, 2), 0, 1.38, 0));
  parts.push(xform(box(0.1, 0.62, 0.12, 2), -0.24, 1.05, 0.02, 0, 0, 0.12));
  parts.push(xform(box(0.1, 0.62, 0.12, 2), 0.24, 1.05, 0.02, 0, 0, -0.12));
  const g = mergeGeos(parts);
  const s = h / 1.7;
  if (s !== 1) g.scale(s, s, s);
  return g;
}

function statueGeometry(h) {
  const parts = [];
  parts.push(
    lathe(
      [
        [0.0, 0],
        [0.95, 0],
        [0.92, 0.2],
        [0.78, 0.9],
        [0.6, 1.8],
        [0.46, 2.7],
        [0.4, 3.4],
        [0.36, 3.9],
        [0.3, 4.2],
        [0.26, 4.45],
      ],
      12,
      3
    )
  );
  parts.push(xform(sphere(0.34, 12, 10, 3), 0, 4.75, 0));
  parts.push(xform(box(1.5, 0.34, 0.8, 3), 0, 4.35, 0));
  parts.push(xform(box(1.5, 0.3, 0.32, 3), -1.0, 4.15, 0, 0, 0, 0.22));
  parts.push(xform(box(1.5, 0.3, 0.32, 3), 1.0, 4.15, 0, 0, 0, -0.22));
  parts.push(xform(cyl(0.09, 0.11, 5.2, 8, 3), 1.5, 2.4, 0.1));
  parts.push(xform(torus(0.34, 0.09, 5, 12, 3), 1.5, 4.9, 0.1, Math.PI / 2, 0, 0));
  for (const sgn of [-1, 1]) {
    parts.push(
      xform(
        lathe(
          [
            [0.05, 0],
            [0.5, 0.6],
            [0.62, 1.6],
            [0.5, 2.9],
            [0.3, 3.9],
            [0.12, 4.4],
          ],
          8,
          3
        ),
        sgn * 0.55,
        0,
        -0.35,
        0,
        sgn * 0.35,
        0
      )
    );
  }
  const g = mergeGeos(parts);
  const s = h / 5.5;
  if (s !== 1) g.scale(s, s, s);
  return g;
}

// ------------------------------------------------------------------- builder
export function buildCathedral(writer) {
  const shim =
    writer ||
    ({
      _defs: [],
      addImagePNG: () => 0,
      addSampler: () => 0,
      addTexture: () => 0,
      addMaterial: (d) => (shim._defs.push(d), shim._defs.length - 1),
    });
  const { mats } = createMaterials(shim);
  const M = mats;

  const root = new THREE.Group();
  root.name = "SunderedChoir";
  const lights = [];
  const stats = { meshes: 0, tris: 0 };

  function add(geo, mat, name, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) {
    if (!geo) return null;
    const m = new THREE.Mesh(geo, mat);
    m.name = name;
    m.position.set(x, y, z);
    m.rotation.set(rx, ry, rz);
    root.add(m);
    stats.meshes++;
    const idx = geo.getIndex();
    stats.tris += (idx ? idx.count : geo.getAttribute("position").count) / 3;
    return m;
  }

  const rnd = (() => {
    let s = 12345;
    return () => {
      s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
      return s / 4294967296;
    };
  })();

  // ==========================================================================
  // 1. FLOOR
  // ==========================================================================
  {
    const FZ0 = Z_OUT;
    const FZ1 = Z_FAR_OUT;
    const FC = (FZ0 + FZ1) / 2;
    const FD = FZ1 - FZ0;
    add(floorQuad(-41.5, FC, 53, FD, 6), M.stone, "floorW");
    add(floorQuad(0, FC, 26, FD, 6), M.stone, "floorC");
    add(floorQuad(41.5, FC, 53, FD, 6), M.stone, "floorE");
    for (const sx of [-1, 1]) {
      add(floorQuad(sx * 14, FC, 2, FD, 6, -0.55), M.water, "channel");
      add(quad([sx * 13, 0, FZ0], [sx * 13, 0, FZ1], [sx * 13, -0.55, FZ1], [sx * 13, -0.55, FZ0], 6, [sx, 0, 0]), M.stoneDark, "chanWall");
      add(quad([sx * 15, 0, FZ0], [sx * 15, 0, FZ1], [sx * 15, -0.55, FZ1], [sx * 15, -0.55, FZ0], 6, [-sx, 0, 0]), M.stoneDark, "chanWall");
      for (let z = 84; z > FZ1 + 12; z -= 12) add(box(2.4, 0.35, 5, 3), M.iron, "grate", sx * 14, -0.1, z);
    }
    // monumental inlay disc at the crossing
    add(xform(disc(26, 48), 0, 0.03, 0, -Math.PI / 2, 0, 0), M.inlay, "inlay");
    // stepped platform around the monument
    for (let i = 0; i < 3; i++) {
      const r = 17 + i * 3;
      const y = 0.22 + i * 0.22;
      const ring = lathe(
        [
          [r, -0.2],
          [r, y],
          [r + 2.6, y],
          [r + 2.6, -0.2],
        ],
        48,
        4
      );
      add(xform(ring, 0, 0, 0, -Math.PI / 2, 0, 0), M.stoneWarm, "dais");
    }
    // marble processional path
    add(floorQuad(0, 20, 9, 150, 8, 0.04), M.marble, "path");
    add(floorQuad(0, -100, 9, 62, 8, 0.04), M.marble, "path2");
    // sunken slabs + rubble
    for (let i = 0; i < 46; i++) {
      const x = (rnd() - 0.5) * 120;
      const z = FZ1 + 8 + rnd() * (FZ0 - FZ1 - 16);
      const w = 1 + rnd() * 4;
      const d = 1 + rnd() * 4;
      add(box(w, 0.5, d, 3), M.stone, "slab", x, rnd() > 0.5 ? -0.28 : 0.25, z, 0, rnd() * 0.4 - 0.2, rnd() * Math.PI);
    }
    for (let i = 0; i < 80; i++) {
      const x = (rnd() - 0.5) * 118;
      const z = FZ1 + 6 + rnd() * (FZ0 - FZ1 - 12);
      const s = 0.4 + rnd() * 1.9;
      add(box(s, s * (0.4 + rnd() * 0.5), s * (0.6 + rnd()), 3), M.stone, "rubble", x, s * 0.3, z, rnd() * 0.3, rnd() * Math.PI, rnd() * 0.3);
    }
  }

  // ==========================================================================
  // 2. PIERS + ARCADE
  // ==========================================================================
  function pier(z, big) {
    const w = big ? 20 : PIER_W;
    const d = big ? 20 : PIER_D;
    const parts = [];
    parts.push(xform(box(w + 6, 5, d + 6, 5), PIER_X, 2.5, z));
    parts.push(xform(box(w, ARC_Y - 5, d, 5), PIER_X, (ARC_Y + 5) / 2, z));
    parts.push(xform(box(w - 2, TRIF_TOP - ARC_Y, d, 5), PIER_X, (ARC_Y + TRIF_TOP) / 2, z));
    parts.push(xform(box(w - 4, VS - TRIF_TOP, d, 5), PIER_X - 1, (TRIF_TOP + VS) / 2, z));
    parts.push(xform(box(w + 2, 7, d + 2, 5), PIER_X - 1, VS + 3.5, z));
    for (const dz of [-3.2, 3.2])
      parts.push(xform(box(2.4, VS - ARC_Y - 8, 2.2, 5), PIER_X - w / 2 + 0.6, (ARC_Y + VS) / 2, z + dz));
    for (const y of [ARC_Y + 6, TRIF_TOP + 10, 76, 90])
      parts.push(xform(box(w + 4, 1.6, d + 4, 5), PIER_X - 1, y, z));
    add(mergeGeos(parts), M.stoneWarm, "pier");
  }
  for (const z of PZ) pier(z, Math.abs(z) <= 13.01);

  for (const z of PZ) {
    for (const sx of [-1, 1]) {
      const g = archGeo(ARC_S, ARC_RISE, 3.2, PIER_D + 1, 16, 4);
      add(xform(g, sx * (PIER_X + PIER_W / 2 + ARC_S / 2), ARC_Y, z), M.stoneWarm, "arcade");
      add(box(3.4, 3.4, PIER_D + 1, 4), M.stoneWarm, "impost", sx * (PIER_X + PIER_W / 2 + 1.2), ARC_Y + 1.2, z);
    }
  }

  // ==========================================================================
  // 3. CLERESTORY / TRIFORIUM WALLS
  // ==========================================================================
  for (const sx of [-1, 1]) {
    const holes = [];
    for (const b of BAYS) {
      for (let k = -1; k <= 1; k++) holes.push(archHole(b.c + k * 8.4, TRIF_Y, 7, 5, 10));
      for (const dx of [-5.6, 5.6]) holes.push(archHole(b.c + dx, CLER_BOT, 8, CLER_TOP - CLER_BOT, 12));
    }
    // blind arcade in the sanctuary
    for (let i = 0; i < 4; i++) holes.push(archHole(-118 - i * 0.0001, TRIF_Y, 7, 5, 10));
    const g = wallX(Z_IN, Z_FAR, 20, TOWER_TOP, WALL_XO - WALL_XI, holes, 5, sx > 0 ? WALL_XO : -WALL_XO, sx > 0 ? -1 : 1);
    add(g, M.stone, "clerestoryWall");

    // triforium floors + parapets
    const fl = [];
    for (const b of BAYS) fl.push(floorQuad(sx * (WALL_XI + WALL_XO) / 2, b.c, WALL_XO - WALL_XI, b.a - b.b, 5, TRIF_Y));
    add(mergeGeos(fl), M.stoneWarm, "triforiumFloor");
    const par = [];
    for (const b of BAYS) par.push(box(0.9, 1.1, b.a - b.b, 4));
    add(mergeGeos(par), M.marble, "parapet", sx * (WALL_XI - 0.45), TRIF_Y + 0.55, (Z_IN + Z_FAR) / 2);

    // glazing, mullions, tracery
    const glass = [];
    const trim = [];
    for (const b of BAYS) {
      for (const dx of [-5.6, 5.6]) {
        const cz = b.c + dx;
        glass.push(
          quad(
            [sx * (WALL_XI + 0.35), CLER_BOT + 0.5, cz - 4],
            [sx * (WALL_XI + 0.35), CLER_BOT + 0.5, cz + 4],
            [sx * (WALL_XI + 0.35), CLER_TOP - 1, cz + 4],
            [sx * (WALL_XI + 0.35), CLER_TOP - 1, cz - 4],
            3,
            [sx, 0, 0]
          )
        );
        for (const mz of [-2.6, 0, 2.6])
          trim.push(xform(box(0.9, CLER_TOP - CLER_BOT - 1, 0.7, 4), sx * (WALL_XI + 0.6), (CLER_BOT + CLER_TOP) / 2, cz + mz));
        for (const my of [66, 76, 86]) trim.push(xform(box(0.9, 0.7, 8.4, 4), sx * (WALL_XI + 0.6), my, cz));
        trim.push(xform(torus(2.6, 0.45, 5, 16, 3), sx * (WALL_XI + 0.7), CLER_TOP - 5, cz, 0, Math.PI / 2, 0));
        for (let k = 0; k < 8; k++) {
          const a = (k / 8) * Math.PI * 2;
          trim.push(xform(box(0.5, 0.5, 2.4, 3), sx * (WALL_XI + 0.7) + Math.cos(a) * 1.3, CLER_TOP - 5 + Math.sin(a) * 1.3, cz, 0, 0, a));
        }
      }
    }
    add(mergeGeos(glass), M.glassCyan, "clerestoryGlass");
    add(mergeGeos(trim), M.marble, "clerestoryTrim");

    // triforium arcade trim (arches framing the openings in the wall face)
    const tt2 = [];
    for (const b of BAYS) {
      for (let k = -1; k <= 1; k++) {
        const cz = b.c + k * 8.4;
        const g = archGeo(7.6, 5.6, 0.9, WALL_XO - WALL_XI + 0.8, 10, 3);
        g.rotateY(sx > 0 ? -Math.PI / 2 : Math.PI / 2);
        if (sx > 0) g.translate(WALL_XO, TRIF_Y, cz);
        else g.translate(-WALL_XO, TRIF_Y, cz);
        tt2.push(g);
        const bb = box(1.2, 1.2, WALL_XO - WALL_XI + 0.8, 3);
        bb.rotateY(sx > 0 ? -Math.PI / 2 : Math.PI / 2);
        if (sx > 0) bb.translate(WALL_XO, TRIF_Y + 0.6, cz);
        else bb.translate(-WALL_XO, TRIF_Y + 0.6, cz);
        tt2.push(bb);
      }
    }
    add(mergeGeos(tt2), M.marble, "triforiumTrim");
  }

  // ==========================================================================
  // 4. OUTER WALLS + AISLE VAULTS
  // ==========================================================================
  for (const sx of [-1, 1]) {
    const holes = [];
    for (const b of BAYS) holes.push(archHole(b.c, 12, 3.2, 26, 10));
    const g = wallX(Z_IN, Z_FAR, 0, TRIF_TOP + AISLE_RISE, OUT_T, holes, 5, sx > 0 ? AISLE_X + OUT_T : -(AISLE_X + OUT_T), sx > 0 ? -1 : 1);
    add(g, M.stone, "outerWall");

    const but = [];
    for (const z of PZ) {
      but.push(xform(box(10, TRIF_TOP + AISLE_RISE, 12, 5), sx * (AISLE_X + 1), (TRIF_TOP + AISLE_RISE) / 2, z));
      but.push(xform(box(7, 4, 12, 4), sx * (AISLE_X + 1), TRIF_TOP + AISLE_RISE + 2, z));
      but.push(xform(cone(2.6, 12, 8, 4), sx * (AISLE_X + 1), TRIF_TOP + AISLE_RISE + 10, z));
      but.push(xform(sphere(1.1, 8, 6, 3), sx * (AISLE_X + 1), TRIF_TOP + AISLE_RISE + 16.5, z));
    }
    add(mergeGeos(but), M.stoneWarm, "buttress");

    add(vaultWeb(sx * WALL_XO, sx * AISLE_X, Z_IN, Z_FAR, TRIF_TOP, AISLE_RISE, 14, 34, 5, null), M.stone, "aisleVault");
    const ribs = [];
    for (const z of PZ) ribs.push(xform(archGeo(AISLE_S, AISLE_RISE, 1.6, 1.4, 12, 4), sx * (WALL_XO + AISLE_X) / 2, TRIF_TOP, z));
    add(mergeGeos(ribs), M.stoneWarm, "aisleRibs");

    const glass = [];
    for (const b of BAYS)
      glass.push(
        quad(
          [sx * (AISLE_X + 0.45), 13, b.c - 1.6],
          [sx * (AISLE_X + 0.45), 13, b.c + 1.6],
          [sx * (AISLE_X + 0.45), 37, b.c + 1.6],
          [sx * (AISLE_X + 0.45), 37, b.c - 1.6],
          3,
          [sx, 0, 0]
        )
      );
    add(mergeGeos(glass), M.glassCyan, "slitGlass");
  }

  // ==========================================================================
  // 5. NAVE VAULT (with the Sundered Eye)
  // ==========================================================================
  {
    const skip = (x, z) => x * x + z * z < EYE_R * EYE_R;
    add(vaultWeb(-WALL_XI, WALL_XI, Z_IN, Z_FAR, VS, VR, 30, 42, 5, skip), M.stone, "naveVault");

    const ribs = [];
    for (const z of PZ) ribs.push(xform(archGeo(2 * WALL_XI, VR, 2.6, 2.2, 16, 4), 0, VS, z));
    for (const b of BAYS) ribs.push(xform(archGeo(2 * WALL_XI, VR, 1.8, 1.6, 16, 4), 0, VS, b.c));
    for (const [a, b2] of [
      [Z_IN, -EYE_R - 3],
      [EYE_R + 3, Z_FAR],
    ]) {
      const pts = [];
      for (let i = 0; i <= 12; i++) pts.push(new THREE.Vector3(0, VRIDGE, a + ((b2 - a) * i) / 12));
      ribs.push(tubeCurve(new THREE.CatmullRomCurve3(pts), 1.9, 12, 6, 4));
    }
    for (const b of BAYS) {
      const za = b.a - 12.5;
      const zb = b.b + 12.5;
      for (const sgn of [1, -1]) {
        const pts = [
          new THREE.Vector3(sgn * WALL_XI, VS, za),
          new THREE.Vector3(sgn * WALL_XI * 0.55, VS + VR * 0.72, b.c),
          new THREE.Vector3(0, VRIDGE, b.c),
          new THREE.Vector3(-sgn * WALL_XI * 0.55, VS + VR * 0.72, b.c),
          new THREE.Vector3(-sgn * WALL_XI, VS, zb),
        ];
        ribs.push(tubeCurve(new THREE.CatmullRomCurve3(pts), 1.7, 16, 6, 4));
      }
    }
    add(mergeGeos(ribs), M.stoneWarm, "vaultRibs");

    const bosses = [];
    for (const b of BAYS) bosses.push(xform(sphere(2.2, 10, 8, 3), 0, VRIDGE, b.c));
    for (const z of PZ) bosses.push(xform(sphere(1.6, 8, 6, 3), 0, VS + VR * 0.55, z));
    add(mergeGeos(bosses), M.marble, "bosses");

    const corn = [];
    for (const sx of [-1, 1]) corn.push(xform(box(2.4, 4, Z_FAR - Z_IN, 5), sx * (WALL_XI + 0.6), VS + 2, (Z_IN + Z_FAR) / 2));
    add(mergeGeos(corn), M.marble, "cornice");
  }

  // ==========================================================================
  // 6. LANTERN TOWER (above the vault)
  // ==========================================================================
  {
    const parts = [];
    for (const sx of [-1, 1]) {
      const holes = [];
      for (const z of [70, 30, -20, -70, -105]) holes.push(archHole(z, 178, 4, 22, 8));
      parts.push(wallX(Z_IN, Z_FAR, VRIDGE, TOWER_TOP, WALL_XO - WALL_XI, holes, 6, sx > 0 ? WALL_XO : -WALL_XO, sx > 0 ? -1 : 1));
      for (const y of [170, 205, 235])
        parts.push(xform(box(WALL_XO - WALL_XI + 2, 3, Z_FAR - Z_IN, 6), sx * (WALL_XI + WALL_XO) / 2, y, (Z_IN + Z_FAR) / 2));
    }
    add(mergeGeos(parts), M.stone, "tower");

    const glass = [];
    for (const sx of [-1, 1])
      for (const z of [70, 30, -20, -70, -105])
        glass.push(
          quad(
            [sx * (WALL_XI + 0.35), 179, z - 2],
            [sx * (WALL_XI + 0.35), 179, z + 2],
            [sx * (WALL_XI + 0.35), 199, z + 2],
            [sx * (WALL_XI + 0.35), 199, z - 2],
            3,
            [sx, 0, 0]
          )
        );
    add(mergeGeos(glass), M.glassCyan, "towerGlass");

    const jag = [];
    for (const sx of [-1, 1]) {
      for (let i = 0; i < 24; i++) {
        const z = Z_IN - 4 + (i * (Z_FAR - Z_IN + 8)) / 23;
        const h = 6 + rnd() * 18;
        jag.push(xform(box(WALL_XO - WALL_XI, h, (Z_FAR - Z_IN) / 22, 6), sx * (WALL_XI + WALL_XO) / 2, TOWER_TOP + h / 2, z));
      }
    }
    add(mergeGeos(jag), M.stone, "towerTop");
  }

  // ==========================================================================
  // 7. ENTRANCE WALL
  // ==========================================================================
  {
    const all = [];
    all.push(archHole(0, 0, 20, 34, 16));
    for (const sx of [-1, 1]) all.push(archHole(sx * 30, 0, 11, 22, 12));
    for (const sx of [-1, 1]) all.push(archHole(sx * 51, 0, 2.6, 3.4, 6));
    all.push(circleHole(0, 48, 5.5, 22));
    const pick = (f) => all.filter(f);
    add(wallZ(-42, 42, 0, VS, Z_IN - Z_OUT, pick((h) => Math.abs(h.pts[0][0]) <= 42.001), 6, Z_IN), M.stone, "entranceWallN");
    add(wallZ(-64, -42, 0, TRIF_TOP + AISLE_RISE, Z_IN - Z_OUT, pick((h) => h.pts[0][0] < -42), 6, Z_IN), M.stone, "entranceWallW");
    add(wallZ(42, 64, 0, TRIF_TOP + AISLE_RISE, Z_IN - Z_OUT, pick((h) => h.pts[0][0] > 42), 6, Z_IN), M.stone, "entranceWallE");

    const rings = [];
    rings.push(xform(archGeo(21, 35, 2.2, Z_OUT - Z_IN + 1.4, 16, 4), 0, 0, 0));
    for (const sx of [-1, 1]) rings.push(xform(archGeo(12, 23, 1.6, Z_OUT - Z_IN + 1.4, 12, 4), sx * 30, 0, 0));
    add(mergeGeos(rings), M.marble, "portalRings", 0, 0, Z_IN + (Z_OUT - Z_IN) / 2);

    const rose = xform(disc(5.4, 24), 0, 48, Z_IN - 0.25, 0, 0, 0);
    add(rose, M.glassCrimson, "roseGlass");
    const trac = [];
    trac.push(xform(torus(5.2, 0.35, 5, 20, 3), 0, 48, Z_IN - 0.15, 0, Math.PI / 2, 0));
    for (let k = 0; k < 8; k++) {
      const a = (k / 8) * Math.PI * 2;
      trac.push(xform(box(0.4, 0.4, 5.0, 3), Math.cos(a) * 2.6, 48 + Math.sin(a) * 2.6, Z_IN - 0.15, 0, 0, a));
    }
    trac.push(xform(torus(2.4, 0.3, 5, 16, 3), 0, 48, Z_IN - 0.15, 0, Math.PI / 2, 0));
    add(mergeGeos(trac), M.gold, "roseTracery", 0, 0, Z_IN - 0.15);

    const light = [];
    light.push(wallQuad(0, 17, Z_OUT + 3, 21, 35, 4, 0, -1));
    for (const sx of [-1, 1]) light.push(wallQuad(sx * 30, 11, Z_OUT + 3, 12, 23, 4, 0, -1));
    add(mergeGeos(light), M.glassWhite, "portalLight");

    for (const sx of [-1, 1]) add(box(2.4, 3.2, 0.4, 3), M.iron, "door", sx * 51, 1.6, Z_IN - 0.35);
  }

  // ==========================================================================
  // 8. FAR WALL + ROSE WINDOW + ALTAR
  // ==========================================================================
  {
    const holes = [circleHole(0, 52, 15, 30)];
    for (const sx of [-1, 1]) holes.push(archHole(sx * 26, 0, 5, 30, 10));
    add(wallZ(-64, 64, 0, VS, Z_FAR - Z_FAR_OUT, holes, 6, Z_FAR), M.stone, "farWall");

    add(xform(disc(14.6, 32), 0, 52, Z_FAR - 0.35, 0, 0, 0), M.glassCrimson, "farRose");
    const trac = [];
    trac.push(xform(torus(14.2, 0.6, 6, 28, 4), 0, 52, Z_FAR - 0.2, 0, Math.PI / 2, 0));
    trac.push(xform(torus(9.5, 0.45, 5, 24, 4), 0, 52, Z_FAR - 0.2, 0, Math.PI / 2, 0));
    for (let k = 0; k < 12; k++) {
      const a = (k / 12) * Math.PI * 2;
      trac.push(xform(box(0.5, 0.5, 13.8, 4), Math.cos(a) * 6.9, 52 + Math.sin(a) * 6.9, Z_FAR - 0.2, 0, 0, a));
    }
    add(mergeGeos(trac), M.gold, "farRoseTracery", 0, 0, Z_FAR - 0.2);

    const glass = [];
    for (const sx of [-1, 1])
      glass.push(
        quad([sx * 26 - 2.5, 1, Z_FAR - 0.45], [sx * 26 + 2.5, 1, Z_FAR - 0.45], [sx * 26 + 2.5, 29, Z_FAR - 0.45], [sx * 26 - 2.5, 29, Z_FAR - 0.45], 3, [0, 0, 1])
      );
    add(mergeGeos(glass), M.glassCyan, "lancetGlass");

    // sanctuary: stepped dais in front of the rose window
    const ds = [];
    for (let i = 0; i < 4; i++) ds.push(xform(box(56, 0.35, 3, 5), 0, 0.17 + i * 0.35, Z_FAR + 3 + i * 3));
    add(mergeGeos(ds), M.marble, "daisStep");
    add(box(11, 7.5, 6, 5), M.marble, "altar", 0, 3.75 + 1.4, Z_FAR + 18);
    add(box(13, 2, 2.4, 4), M.marble, "altarTop", 0, 9.4, Z_FAR + 18);
    add(box(22, 16, 2, 5), M.stoneWarm, "reredos", 0, 9.4, Z_FAR + 24);
    add(wallQuad(0, 12, Z_FAR + 22.9, 9, 9, 4, 0, 1), M.glyph, "altarGlyph");
    const cand = [];
    for (const sx of [-1, 1])
      for (let i = 0; i < 3; i++) {
        const x = sx * (5 + i * 3.4);
        cand.push(xform(cyl(0.5, 0.6, 9, 10, 3), x, 5.5 + 1.4, Z_FAR + 15));
        cand.push(xform(cone(0.5, 1.2, 8, 3), x, 10.6 + 1.4, Z_FAR + 15));
      }
    add(mergeGeos(cand), M.marble, "altarCandles");
  }

  // ==========================================================================
  // 9. CHANCEL ARCH
  // ==========================================================================
  {
    const g = archGeo(2 * WALL_XI, 46, 5, 7, 18, 5);
    add(xform(g, 0, ARC_Y, -88), M.stoneWarm, "chancelArch");
    for (const sx of [-1, 1]) add(box(6, 8, 8, 5), M.stoneWarm, "chancelImpost", sx * (WALL_XI - 1), ARC_Y + 4, -88);
  }

  // ==========================================================================
  // 10. STAIRS
  // ==========================================================================
  for (const sx of [-1, 1]) {
    const zStart = 84;
    const zEnd = 8;
    const steps = 150;
    const rise = TRIF_Y / steps;
    const run = (zStart - zEnd) / steps;
    const parts = [];
    for (let i = 0; i < steps; i++) {
      const y = i * rise;
      const z = zStart - i * run;
      parts.push(xform(box(8, y + rise, run * 1.02, 4), sx * 21, (y + rise) / 2, z - run / 2));
    }
    add(mergeGeos(parts), M.stoneWarm, "stair");
    const bal = [];
    for (let i = 0; i < steps; i++) {
      const y = i * rise;
      const z = zStart - i * run;
      bal.push(xform(box(0.5, 1.1, run * 1.02, 3), sx * 25.3, y + 0.55, z));
      bal.push(xform(box(0.5, 1.1, run * 1.02, 3), sx * 16.7, y + 0.55, z));
      if (i % 8 === 0) {
        bal.push(xform(cyl(0.24, 0.24, 1.4, 6, 3), sx * 25.3, y + 1.45, z));
        bal.push(xform(cyl(0.24, 0.24, 1.4, 6, 3), sx * 16.7, y + 1.45, z));
      }
    }
    add(mergeGeos(bal), M.iron, "stairRail");
    // landing into the triforium
    add(box(26, 1.2, 7, 5), M.stoneWarm, "stairLanding", sx * 33, TRIF_Y - 0.6, 5);
  }

  // ==========================================================================
  // 11. BRIDGES
  // ==========================================================================
  for (const z of [-30, -70]) {
    add(box(2 * WALL_XI + 4, 1.6, 5, 5), M.stoneWarm, "bridgeDeck", 0, TRIF_Y - 0.4, z);
    add(xform(archGeo(2 * WALL_XI + 2, TRIF_Y - 8, 2.4, 4, 16, 4), 0, 8, z), M.stoneWarm, "bridgeArch");
    const bal = [];
    for (const sx of [-1, 1]) {
      bal.push(xform(box(0.6, 1.2, 5, 4), sx * (WALL_XI + 1.6), TRIF_Y + 0.6, z));
      for (let i = -3; i <= 3; i++) bal.push(xform(cyl(0.25, 0.25, 1.5, 6, 3), sx * (WALL_XI + 1.6), TRIF_Y + 1.5, z + i * 0.8));
    }
    add(mergeGeos(bal), M.iron, "bridgeRail");
  }

  // ==========================================================================
  // 12. CENTRAL MONUMENT
  // ==========================================================================
  {
    const taper = (y) => 17 - (11 * y) / 250;
    const ringYs = [12, 30, 52, 78, 108, 142, 180, 220, 246];
    const parts = [];
    const trim = [];

    parts.push(
      lathe(
        [
          [0, 0],
          [17, 0],
          [17, 2.2],
          [15.5, 3.4],
          [15.5, 5],
          [0, 5],
        ],
        40,
        5
      )
    );
    const NSTRUT = 12;
    for (let k = 0; k < NSTRUT; k++) {
      const a = (k / NSTRUT) * Math.PI * 2;
      const pts = [];
      for (let i = 0; i <= 8; i++) {
        const y = 5 + (i / 8) * 245;
        pts.push(new THREE.Vector3(Math.cos(a) * taper(y), y, Math.sin(a) * taper(y)));
      }
      parts.push(tubeCurve(new THREE.CatmullRomCurve3(pts), 1.5, 20, 6, 4));
    }
    for (const y of ringYs) {
      const r = taper(y);
      parts.push(xform(torus(r, 1.5, 6, 30, 4), 0, y, 0));
      for (let k = 0; k < NSTRUT; k++) {
        const a = (k / NSTRUT) * Math.PI * 2 + 0.13;
        trim.push(xform(box(1.4, 3.4, 1.4, 3), Math.cos(a) * r, y, Math.sin(a) * r, 0, -a, 0));
      }
    }
    for (let k = 0; k < 8; k++) {
      const a = (k / 8) * Math.PI * 2 + 0.4;
      const pts = [
        new THREE.Vector3(0, 112, 0),
        new THREE.Vector3(Math.cos(a) * 7, 116, Math.sin(a) * 7),
        new THREE.Vector3(Math.cos(a) * 12, 124, Math.sin(a) * 12),
        new THREE.Vector3(Math.cos(a) * taper(130), 130, Math.sin(a) * taper(130)),
      ];
      parts.push(tubeCurve(new THREE.CatmullRomCurve3(pts), 0.9, 12, 5, 3));
    }
    add(mergeGeos(parts), M.stoneWarm, "monument");
    add(mergeGeos(trim), M.metal, "monumentBands");
    add(xform(sphere(9.5, 20, 14, 4), 0, 112, 0), M.core, "monumentCore");

    // inner suspended ring
    add(xform(torus(20, 2.2, 6, 34, 4), 0, 200, 0, 0.12, 0, 0.08), M.stoneWarm, "innerRing");
    const irb = [];
    for (let k = 0; k < 10; k++) {
      const a = (k / 10) * Math.PI * 2;
      irb.push(xform(box(2.6, 5.4, 2.6, 3), Math.cos(a) * 20, 200 + Math.sin(a) * 1.2, Math.sin(a) * 19.9, 0, -a, 0.12));
    }
    add(mergeGeos(irb), M.metal, "innerRingBands");

    // halo ring
    add(xform(torus(HALO_R, 5, 8, 60, 5), 0, HALO_Y, 0, 0.1, 0, 0.06), M.stoneWarm, "haloRing");
    const hb = [];
    for (let k = 0; k < 24; k++) {
      const a = (k / 24) * Math.PI * 2;
      hb.push(xform(box(6, 11, 6, 4), Math.cos(a) * HALO_R, HALO_Y + Math.sin(a) * 3.6, Math.sin(a) * HALO_R * 0.99, 0, -a, 0.1));
    }
    add(mergeGeos(hb), M.metal, "haloBands");
    const sp = [];
    for (let k = 0; k < 16; k++) {
      const a = (k / 16) * Math.PI * 2;
      sp.push(
        xform(cone(1.8, 9, 6, 4), Math.cos(a) * (HALO_R + 5), HALO_Y + Math.sin(a) * 3.6, Math.sin(a) * (HALO_R + 5) * 0.99, Math.PI / 2, 0, -a)
      );
    }
    add(mergeGeos(sp), M.metal, "haloSpikes");

    // crown ribs
    const crown = [];
    for (let k = 0; k < 8; k++) {
      const a = (k / 8) * Math.PI * 2 + 0.2;
      const pts = [
        new THREE.Vector3(Math.cos(a) * 6, 250, Math.sin(a) * 6),
        new THREE.Vector3(Math.cos(a) * 20, 262, Math.sin(a) * 20),
        new THREE.Vector3(Math.cos(a) * 40, 270, Math.sin(a) * 40),
        new THREE.Vector3(Math.cos(a) * HALO_R, HALO_Y, Math.sin(a) * HALO_R),
      ];
      crown.push(tubeCurve(new THREE.CatmullRomCurve3(pts), 1.6, 16, 5, 4));
    }
    add(mergeGeos(crown), M.stoneWarm, "crownRibs");
    const tip = [];
    for (let k = 0; k < 6; k++) {
      const a = (k / 6) * Math.PI * 2;
      const h = 20 + rnd() * 26;
      tip.push(xform(cone(3.2, h, 6, 4), Math.cos(a) * 4, 250 + h / 2, Math.sin(a) * 4, 0, -a, 0));
    }
    add(mergeGeos(tip), M.stoneWarm, "spireTip");

    // ---- chains
    function chain(cx, cz, yTop, yBot, linkR, linkT) {
      const links = [];
      const n = Math.max(4, Math.floor((yTop - yBot) / (linkR * 1.7)));
      for (let i = 0; i < n; i++) {
        const y = yTop - (i + 0.5) * ((yTop - yBot) / n);
        links.push(xform(torus(linkR, linkT, 5, 10, 3), cx, y, cz, Math.PI / 2, i % 2 === 0 ? 0 : Math.PI / 2, 0));
      }
      return mergeGeos(links);
    }
    const chA = [];
    for (let k = 0; k < 4; k++) {
      const a = (k / 4) * Math.PI * 2 + Math.PI / 4;
      chA.push(chain(Math.cos(a) * 20, Math.sin(a) * 20, 198, 26, 2.4, 0.9));
    }
    add(mergeGeos(chA), M.iron, "naveChains");

    const lant = [];
    const cores = [];
    for (let k = 0; k < 4; k++) {
      const a = (k / 4) * Math.PI * 2 + Math.PI / 4;
      const x = Math.cos(a) * 20;
      const z = Math.sin(a) * 20;
      lant.push(
        xform(
          lathe(
            [
              [0, 0],
              [3.2, 0],
              [3.6, 1.4],
              [2.6, 5.4],
              [1.4, 8.6],
              [0.9, 10],
            ],
            10,
            4
          ),
          x,
          18,
          z
        )
      );
      cores.push(xform(sphere(1.4, 8, 6, 3), x, 23.6, z));
    }
    add(mergeGeos(lant), M.metal, "naveLanterns");
    add(mergeGeos(cores), M.core, "lanternCores");

    const chB = [];
    for (let k = 0; k < 6; k++) {
      const a = (k / 6) * Math.PI * 2 + 0.25;
      chB.push(chain(Math.cos(a) * HALO_R, Math.sin(a) * HALO_R, HALO_Y - 5, TRIF_TOP + AISLE_RISE + 4, 3.2, 1.2));
    }
    add(mergeGeos(chB), M.iron, "haloChains");

    // ---- hanging bells
    const bells = [];
    for (const b of BAYS) {
      if (Math.abs(b.c) < 30) continue;
      const yTop = VS + archY(0, 2 * WALL_XI, VR) - 1;
      const pts = [];
      for (let i = 0; i <= 6; i++) pts.push(new THREE.Vector3(0, yTop - (i * (yTop - 118)) / 6, b.c));
      bells.push(tubeCurve(new THREE.CatmullRomCurve3(pts), 0.7, 6, 5, 2));
      bells.push(
        xform(
          lathe(
            [
              [0, 0],
              [4.4, 0],
              [4.0, 2],
              [3.0, 5],
              [1.8, 7.6],
              [1.0, 8.4],
            ],
            14,
            4
          ),
          0,
          110,
          b.c
        )
      );
    }
    add(mergeGeos(bells), M.metal, "hangingBells");
  }

  // ==========================================================================
  // 13. HUMAN SCALE REFERENCES
  // ==========================================================================
  {
    const bench = [];
    for (const b of BAYS)
      for (const sx of [-1, 1]) {
        bench.push(xform(box(14, 0.55, 2.2, 4), sx * 11, 0.28, b.c));
        bench.push(xform(box(14, 0.9, 0.35, 4), sx * 11, 0.9, b.c - 1.0));
        for (const dz of [-5, 0, 5]) bench.push(xform(box(0.7, 0.28, 0.7, 3), sx * 11, 0.14, b.c + dz));
      }
    add(mergeGeos(bench), M.marble, "benches");

    const banners = [];
    for (let i = 0; i < BAYS.length; i++) {
      const sx = i % 2 === 0 ? -1 : 1;
      const cz = BAYS[i].c;
      banners.push(
        quad(
          [sx * 29.4, TRIF_Y + 0.2, cz - 1.6],
          [sx * 29.4, TRIF_Y + 0.2, cz + 1.6],
          [sx * 29.4, TRIF_Y - 22, cz + 2.2],
          [sx * 29.4, TRIF_Y - 22, cz - 2.2],
          2,
          [-sx, 0, 0]
        )
      );
      banners.push(xform(box(0.5, 0.5, 4, 3), sx * 29.7, TRIF_Y + 0.1, cz));
    }
    add(mergeGeos(banners), M.banner, "banners");

    const statues = [];
    for (const b of BAYS)
      for (const sx of [-1, 1]) statues.push(xform(statueGeometry(5.5), sx * 31, TRIF_Y + 0.1, b.c, 0, sx > 0 ? Math.PI / 2 : -Math.PI / 2, 0));
    add(mergeGeos(statues), M.marble, "statues");

    const figs = [];
    const figSpots = [
      [8, 76, 0.4],
      [-9, 72, -1.1],
      [12, 60, 2.2],
      [-14, 44, 0.9],
      [6, 20, -0.6],
      [-7, 4, 1.8],
      [3, -14, 0.2],
      [-4, -26, -2.4],
      [10, -60, 1.2],
      [-11, -70, -0.4],
      [5, -108, 0.7],
      [-6, -112, -1.5],
    ];
    for (const [x, z, ry] of figSpots) figs.push(xform(figureGeometry(1.72), x, 0, z, 0, ry, 0));
    for (const b of BAYS) {
      if (Math.abs(b.c) < 30) continue;
      figs.push(xform(figureGeometry(1.72), -31, TRIF_Y + 0.1, b.c, 0, Math.PI / 2, 0));
    }
    add(mergeGeos(figs), M.marble, "humanFigures");

    const candles = [];
    for (const [cx, cz] of [
      [22, 84],
      [-22, 84],
      [22, 8],
      [-22, 8],
      [0, -118],
    ]) {
      candles.push(xform(box(3.4, 1.0, 1.6, 3), cx, 0.5, cz));
      for (let i = 0; i < 7; i++) {
        const x = cx - 1.3 + i * 0.44;
        candles.push(xform(cyl(0.075, 0.085, 0.85, 6, 2), x, 1.4, cz));
        candles.push(xform(sphere(0.07, 6, 5, 2), x, 1.86, cz));
      }
    }
    add(mergeGeos(candles), M.core, "candleBanks");

    const chand = [];
    for (const b of BAYS) {
      if (Math.abs(b.c) < 30) continue;
      const yTop = VS + archY(0, 2 * WALL_XI, VR) - 2;
      const pts = [];
      for (let i = 0; i <= 5; i++) pts.push(new THREE.Vector3(0, yTop - i * 3, b.c));
      chand.push(tubeCurve(new THREE.CatmullRomCurve3(pts), 0.5, 5, 5, 2));
      chand.push(xform(torus(5.5, 0.4, 5, 20, 3), 0, yTop - 18, b.c, Math.PI / 2, 0, 0));
      chand.push(xform(torus(3.4, 0.32, 5, 16, 3), 0, yTop - 24, b.c, Math.PI / 2, 0, 0));
      for (let k = 0; k < 8; k++) {
        const a = (k / 8) * Math.PI * 2;
        chand.push(xform(cyl(0.16, 0.2, 1.6, 6, 2), Math.cos(a) * 5.5, yTop - 17, b.c + Math.sin(a) * 5.5));
        chand.push(xform(sphere(0.19, 6, 5, 2), Math.cos(a) * 5.5, yTop - 15.9, b.c + Math.sin(a) * 5.5));
      }
    }
    add(mergeGeos(chand), M.metal, "chandeliers");
  }

  // ==========================================================================
  // 14. LIGHTS
  // ==========================================================================
  function addLight(name, x, y, z, color, intensity, distance, type = "point") {
    const n = new THREE.Object3D();
    n.name = name;
    n.position.set(x, y, z);
    lights.push({ node: n, def: { name, type, color, intensity, range: distance || undefined } });
  }
  for (const sx of [-1, 1])
    for (let i = 0; i < BAYS.length; i += 2) addLight(`clerestory_${sx > 0 ? "E" : "W"}_${i}`, sx * 25, 75, BAYS[i].c, [0.62, 0.76, 1.0], 90000, 150);
  addLight("roseWindow", 0, 52, Z_FAR + 14, [1.0, 0.35, 0.22], 500000, 170);
  addLight("entrance", 0, 16, 88, [1.0, 0.96, 0.88], 600000, 150);
  addLight("core", 0, 112, 0, [1.0, 0.72, 0.42], 600000, 230);
  addLight("altar", 0, 9, Z_FAR + 16, [1.0, 0.66, 0.3], 120000, 80);
  addLight("candles", 0, 3, -116, [1.0, 0.6, 0.28], 9000, 45);
  addLight("lantern", 14, 24, 14, [1.0, 0.62, 0.3], 70000, 120);
  addLight("tower", 0, 190, 40, [0.55, 0.7, 1.0], 300000, 220);
  {
    const n = new THREE.Object3D();
    n.name = "sky";
    n.position.set(20, 240, 40);
    n.rotation.set(-0.9, 0, 0.4);
    lights.push({ node: n, def: { name: "sky", type: "directional", color: [0.5, 0.62, 0.85], intensity: 1.2 } });
  }

  return { root, lights, materialDefs: shim._defs, stats };
}

export const CONSTANTS = {
  WALL_XI,
  WALL_XO,
  PIER_X,
  PIER_W,
  PIER_D,
  AISLE_X,
  ARC_Y,
  ARC_S,
  ARC_RISE,
  TRIF_Y,
  TRIF_TOP,
  CLER_BOT,
  CLER_TOP,
  VS,
  VR,
  VRIDGE,
  EYE_R,
  PZ,
  Z_IN,
  Z_OUT,
  Z_FAR,
  Z_FAR_OUT,
  TOWER_TOP,
  HALO_Y,
  HALO_R,
  HUMAN,
  BAYS,
};
