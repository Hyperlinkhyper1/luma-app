import { Document, NodeIO } from '@gltf-transform/core';
import { KHRLightsPunctual, KHRMaterialsEmissiveStrength } from '@gltf-transform/extensions';
import { mat4 } from 'gl-matrix';
import {
  emptyGeo, mergeInto, transform, trs,
  box, cylinder, cone, sphere, ngonPrism, plane, quadXY, torus, taperBox, archBand,
} from './geo.mjs';

// ---------------- Builder ----------------
class Builder {
  constructor() { this.groups = new Map(); }
  add(geo, mat, m) {
    const g = m ? transform(geo, m) : geo;
    if (!this.groups.has(mat)) this.groups.set(mat, emptyGeo());
    mergeInto(this.groups.get(mat), g);
  }
}
const B = new Builder();
const M = (pos, rot, scale) => trs(pos, rot, scale);
const DEG = Math.PI / 180;

// small deterministic rng
let seed = 1337;
function rnd() { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; }
const rr = (a, b) => a + (b - a) * rnd();

// ==========================================================
// SCALE: meters. Nave runs along Z. Viewer near z=+195 (eye 1.7m)
// looking toward -Z at the altar & suspended colossus.
// ==========================================================

const FLOOR_MINX = -78, FLOOR_MAXX = 78;
const FLOOR_MINZ = -215, FLOOR_MAXZ = 230;

// ---------------- FLOOR ----------------
function buildFloor() {
  // Main floor slab (thick) - dark polished stone
  const fw = FLOOR_MAXX - FLOOR_MINX, fd = FLOOR_MAXZ - FLOOR_MINZ;
  const cx = (FLOOR_MINX + FLOOR_MAXX) / 2, cz = (FLOOR_MINZ + FLOOR_MAXZ) / 2;
  B.add(box(fw, 4, fd), 'floorDark', M([cx, -2, cz]));

  // Grid of raised stone slabs with gaps (channels) -> monumental paving
  const tile = 26, gap = 1.2;
  for (let x = FLOOR_MINX + 6; x < FLOOR_MAXX - 6; x += tile) {
    for (let z = FLOOR_MINZ + 6; z < FLOOR_MAXZ - 6; z += tile) {
      const inAisle = Math.abs(x + tile / 2) < 22;
      const mat = inAisle ? 'floorAisle' : 'floorSlab';
      const jitter = rr(-0.06, 0.06);
      B.add(box(tile - gap, 0.5 + jitter, tile - gap), mat, M([x + tile / 2, 0.25, z + tile / 2]));
    }
  }

  // Central processional inlay strip (glowing seams toward altar)
  for (let z = FLOOR_MINZ + 10; z < FLOOR_MAXZ - 10; z += 14) {
    B.add(box(2.0, 0.62, 6), 'inlayGold', M([-8, 0.31, z]));
    B.add(box(2.0, 0.62, 6), 'inlayGold', M([8, 0.31, z]));
  }
  // circular medallion under the colossus
  B.add(cylinder(30, 34, 0.9, 48, true), 'inlayGold', M([0, 0.45, -120]));
  B.add(cylinder(26, 30, 1.1, 48, true), 'floorSlab', M([0, 0.55, -120]));
  B.add(torus(22, 1.2, 48, 8), 'bronze', M([0, 1.0, -120]));
  B.add(torus(15, 0.9, 48, 8), 'bronze', M([0, 1.0, -120]));

  // Altar dais steps at far end (elevation change) around z=-150
  for (let i = 0; i < 7; i++) {
    const w = 66 - i * 4;
    B.add(box(w, 2.2, 8 - i * 0.4), 'floorSlab', M([0, 1.1 + i * 2.2, -150 - i * 4]));
  }
}

// ---------------- COLUMN (modular, instanced feel) ----------------
function makeColumn(x, z, height, radius, tier2 = true) {
  // base plinth
  B.add(box(radius * 2.9, 5, radius * 2.9), 'stoneDark', M([x, 2.5, z]));
  B.add(box(radius * 2.5, 3, radius * 2.5), 'stone', M([x, 6.5, z]));
  B.add(cylinder(radius * 1.15, radius * 1.25, 4, 20), 'stone', M([x, 10, z]));
  // shaft - faceted (fluted look)
  const shaftH = height - 18;
  B.add(ngonPrism(radius, shaftH, 16), 'stone', M([x, 12 + shaftH / 2, z]));
  // astragal rings
  B.add(torus(radius * 1.02, 0.6, 20, 6), 'stoneDark', M([x, 14, z]));
  B.add(torus(radius * 1.02, 0.7, 20, 6), 'stoneDark', M([x, 12 + shaftH - 2, z]));
  // capital (flared)
  const capY = 12 + shaftH;
  B.add(cylinder(radius * 1.7, radius * 1.05, 6, 20), 'stone', M([x, capY + 3, z]));
  B.add(box(radius * 3.4, 3, radius * 3.4), 'stoneDark', M([x, capY + 7.5, z]));
  // second tier column (thinner) rising into upper darkness
  if (tier2) {
    const r2 = radius * 0.62;
    const h2 = height * 0.95;
    B.add(box(radius * 2.6, 3, radius * 2.6), 'stone', M([x, capY + 10.5, z]));
    B.add(ngonPrism(r2, h2, 12), 'stoneUp', M([x, capY + 12 + h2 / 2, z]));
    B.add(torus(r2 * 1.1, 0.5, 16, 6), 'stoneDark', M([x, capY + 12 + h2 - 3, z]));
    B.add(cylinder(r2 * 1.5, r2 * 1.0, 5, 16), 'stoneUp', M([x, capY + 12 + h2 + 2.5, z]));
  }
}

// ---------------- ARCHES between columns ----------------
function addArchBetween(x1, x2, z, yBase, innerR, thickness, depth) {
  const span = Math.abs(x2 - x1);
  const cx = (x1 + x2) / 2;
  // scale a unit archBand to fit span; innerR ~ span/2
  const g = archBand(innerR, thickness, depth, 20, true, 1.15);
  B.add(g, 'stone', M([cx, yBase, z]));
}

// ---------------- Colonnades + arcades ----------------
function buildColonnade() {
  const rows = [
    { x: 40, r: 6.0 }, { x: -40, r: 6.0 },
    { x: 66, r: 4.6 }, { x: -66, r: 4.6 },
  ];
  const zStart = 200, zEnd = -175, dz = -37.5;
  const zPositions = [];
  for (let z = zStart; z >= zEnd; z += dz) zPositions.push(z);

  for (const row of rows) {
    for (const z of zPositions) {
      const h = row.r > 5 ? 150 : 120;
      makeColumn(row.x, z, h, row.r, row.r > 5);
    }
  }
  // Longitudinal arcade arches (inner rows) along the nave connecting bays
  for (let i = 0; i < zPositions.length - 1; i++) {
    const za = zPositions[i], zb = zPositions[i + 1];
    const zc = (za + zb) / 2;
    // arches along +x row and -x row, in plane facing across nave -> rotate 90
    for (const sx of [40, -40]) {
      const g = archBand(15, 3.5, 6, 18, true, 1.1);
      const m = M([sx, 162, zc], [0, 90 * DEG, 0]);
      B.add(g, 'stone', m);
    }
    // outer aisle arches
    for (const sx of [66, -66]) {
      const g = archBand(15, 2.6, 5, 16, true, 1.1);
      B.add(g, 'stone', M([sx, 132, zc], [0, 90 * DEG, 0]));
    }
  }
  // Transverse arches spanning the great nave (across X) at column tops
  for (const z of zPositions) {
    const g = archBand(40, 5, 8, 24, true, 1.2);
    B.add(g, 'stoneDark', M([0, 162, z]));
  }
}

// ---------------- Side walls with colossal windows ----------------
function buildWalls() {
  const zA = FLOOR_MINZ + 4, zB = FLOOR_MAXZ - 4;
  const wallH = 330;
  for (const sx of [1, -1]) {
    const wx = 76 * sx;
    // solid wall panels between window bays
    const bays = 9;
    const z0 = -170, z1 = 210;
    const bw = (z1 - z0) / bays;
    for (let i = 0; i < bays; i++) {
      const zc = z0 + bw * (i + 0.5);
      // pier between windows
      B.add(box(6, wallH, 6, 6), 'stoneDark', M([wx, wallH / 2, z0 + bw * i]));
      // window (tall pointed) emissive glass recessed
      const winH = 150, winW = bw - 16;
      // stone frame
      B.add(box(4, winH + 20, winW + 8), 'stoneDark', M([wx, 70 + winH / 2, zc]));
      // glass pane (emissive) slightly inside
      const warm = (i % 2 === 0);
      B.add(quadXY(winW, winH, sx > 0 ? -1 : 1), warm ? 'glassWarm' : 'glassCool',
        M([wx - 1.2 * sx, 70 + winH / 2, zc], [0, 90 * DEG, 0]));
      // tracery mullions
      for (let mmx = -2; mmx <= 2; mmx++) {
        B.add(box(3, winH, 1.2), 'stoneDark', M([wx - 1.0 * sx, 70 + winH / 2, zc + mmx * winW / 6]));
      }
      for (let mmy = 1; mmy <= 4; mmy++) {
        B.add(box(3, 1.2, winW), 'stoneDark', M([wx - 1.0 * sx, 70 + mmy * winH / 5, zc]));
      }
      // arched window top
      B.add(archBand(winW / 2, 5, 4, 16, true, 0.9), 'stoneDark',
        M([wx - 1 * sx, 70 + winH, zc], [0, 90 * DEG, 0]));
    }
    // upper clerestory band of smaller round windows
    for (let i = 0; i < bays; i++) {
      const zc = z0 + bw * (i + 0.5);
      B.add(cylinder(9, 9, 3, 24), 'glassCool', M([wx - 1 * sx, 255, zc], [0, 0, 90 * DEG]));
      B.add(torus(9, 1.4, 24, 6), 'stoneDark', M([wx - 1 * sx, 255, zc], [0, 0, 90 * DEG]));
    }
    // top cornice
    B.add(box(8, 10, z1 - z0 + 12), 'stoneDark', M([wx, wallH - 5, (z0 + z1) / 2]));
  }
}

// ---------------- Entrance & apse end walls ----------------
function buildEndWalls() {
  // Entrance wall (behind viewer, +Z)
  const zE = FLOOR_MAXZ - 2;
  B.add(box(160, 330, 6), 'stoneDark', M([0, 165, zE]));
  // giant portal with human-scale doors
  B.add(box(46, 90, 10), 'stone', M([0, 45, zE - 1]));
  B.add(archBand(23, 6, 10, 22, true, 1.15), 'stone', M([0, 90, zE - 1]));
  // recessed dark opening
  B.add(quadXY(40, 84, -1), 'voidDark', M([0, 44, zE - 2.5]));
  // the actual human doors (tiny by comparison ~5m)
  B.add(box(5, 9, 1.5), 'bronze', M([-3.2, 4.5, zE - 3.5]));
  B.add(box(5, 9, 1.5), 'bronze', M([3.2, 4.5, zE - 3.5]));
  // big rose window above portal (emissive)
  B.add(cylinder(26, 26, 3, 32), 'glassWarm', M([0, 180, zE - 1], [90 * DEG, 0, 0]));
  B.add(torus(26, 2.5, 32, 8), 'stoneDark', M([0, 180, zE - 1], [90 * DEG, 0, 0]));
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2;
    B.add(box(1.6, 26, 2), 'stoneDark', M([Math.cos(a) * 13, 180 + Math.sin(a) * 13, zE - 1], [0, 0, a]));
  }

  // Apse wall (far end behind colossus, -Z)
  const zA = FLOOR_MINZ + 2;
  B.add(box(160, 330, 6), 'stoneDark', M([0, 165, zA]));
  // three colossal windows behind the figure -> backlight silhouette
  for (const dx of [-42, 0, 42]) {
    const wW = dx === 0 ? 40 : 30, wH = dx === 0 ? 230 : 180;
    B.add(quadXY(wW, wH, 1), dx === 0 ? 'glassApse' : 'glassWarm', M([dx, 30 + wH / 2, zA + 1.2]));
    for (let mmy = 1; mmy <= 7; mmy++) B.add(box(wW, 1.2, 3), 'stoneDark', M([dx, 30 + mmy * wH / 8, zA + 0.6]));
    for (let mmx = -1; mmx <= 1; mmx++) B.add(box(1.6, wH, 3), 'stoneDark', M([dx + mmx * wW / 3, 30 + wH / 2, zA + 0.6]));
    B.add(archBand(wW / 2, 4, 3, 16, true, 0.95), 'stoneDark', M([dx, 30 + wH, zA + 0.6]));
  }
}

// ---------------- Vaulting / roof structure high above ----------------
function buildVault() {
  const zPositions = [];
  for (let z = 200; z >= -175; z += -37.5) zPositions.push(z);
  // ribbed vault ribs springing from column tops, meeting at ridge y~300
  for (let i = 0; i < zPositions.length; i++) {
    const z = zPositions[i];
    // pointed cross arch across the nave high up
    B.add(archBand(42, 4, 6, 20, true, 1.6), 'stoneUp', M([0, 250, z]));
    // diagonal ribs to a central boss
    for (const sx of [1, -1]) {
      B.add(box(3, 3, 44), 'stoneUp', M([sx * 20, 300, z], [ -18 * DEG, 0, 0]));
    }
    // ceiling boss
    B.add(sphere(4, 12, 8), 'stoneDark', M([0, 305, z]));
  }
  // Ridge beam running the length, disappearing up
  B.add(box(6, 6, 400), 'stoneUp', M([0, 312, 15]));
  // faint high skylight strip (emissive) along the ridge -> light from above
  B.add(box(30, 1, 380), 'skylight', M([0, 322, 15]));
}

// ---------------- Balconies / galleries (human-scale references) ----------------
function railing(xStart, xEnd, z, y, axis = 'x') {
  // posts + top rail; ~1.1m tall -> human scale cue
  const len = axis === 'x' ? Math.abs(xEnd - xStart) : Math.abs(xEnd - xStart);
  const n = Math.max(2, Math.floor(len / 3));
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    const px = axis === 'x' ? xStart + (xEnd - xStart) * t : xStart;
    const pz = axis === 'x' ? z : xStart + (xEnd - xStart) * t;
    B.add(box(0.4, 2.4, 0.4), 'bronze', M([axis === 'x' ? px : z, y + 1.2, axis === 'x' ? z : pz]));
  }
  if (axis === 'x') {
    B.add(box(Math.abs(xEnd - xStart), 0.35, 0.6), 'bronze', M([(xStart + xEnd) / 2, y + 2.3, z]));
    B.add(box(Math.abs(xEnd - xStart), 0.3, 0.5), 'bronze', M([(xStart + xEnd) / 2, y + 1.1, z]));
  } else {
    B.add(box(0.6, 0.35, Math.abs(xEnd - xStart)), 'bronze', M([z, y + 2.3, (xStart + xEnd) / 2]));
    B.add(box(0.5, 0.3, Math.abs(xEnd - xStart)), 'bronze', M([z, y + 1.1, (xStart + xEnd) / 2]));
  }
}

function buildGalleries() {
  const zPositions = [];
  for (let z = 190; z >= -150; z += -37.5) zPositions.push(z);
  for (const sx of [1, -1]) {
    const gx = 62 * sx;
    // gallery walkway at mid height y=58
    for (const level of [58, 118]) {
      B.add(box(14, 2, 360), 'stoneDark', M([gx - 7 * sx, level, 20]));
      // support brackets/corbels
      for (const z of zPositions) {
        B.add(taperBox(6, 2, 8, 3, 8), 'stone', M([gx - 12 * sx, level - 5, z]));
      }
      // railing on inner edge (scale cue)
      railing(20, -150, gx - 14 * sx, level + 1, 'z');
      // small statues along gallery (human-ish, ~4m) at intervals
      for (let k = 0; k < zPositions.length; k += 2) {
        const z = zPositions[k];
        B.add(box(2, 5, 2), 'stone', M([gx - 4 * sx, level + 3.5, z]));
        B.add(sphere(1.1, 8, 6), 'stone', M([gx - 4 * sx, level + 7, z]));
      }
    }
  }
}

// ---------------- Suspended bridges high across the nave ----------------
function buildBridges() {
  const bridges = [{ z: 60, y: 120 }, { z: -40, y: 150 }, { z: 140, y: 100 }];
  for (const b of bridges) {
    B.add(box(120, 2.5, 9), 'stoneDark', M([0, b.y, b.z]));
    B.add(box(120, 1, 9), 'bronze', M([0, b.y + 1.6, b.z]));
    railing(-58, 58, b.z - 4.2, b.y + 1.3, 'x');
    railing(-58, 58, b.z + 4.2, b.y + 1.3, 'x');
    // suspension cables to vault
    for (let x = -50; x <= 50; x += 20) {
      B.add(cylinder(0.5, 0.5, 130, 6), 'chain', M([x, b.y + 65, b.z]));
    }
    // arched underside supports
    B.add(archBand(40, 3, 6, 16, true, 0.6), 'stoneDark', M([0, b.y - 2, b.z]));
  }
}

// ---------------- THE CENTRAL COLOSSUS ----------------
// An enormous suspended shrouded figure ("The Hanged Saint") hovering over the
// altar, chained into the darkness above. ~180 m tall. Reads as a robed,
// downward-gazing sentinel. Human/altar scale reveals its size.
function buildColossus() {
  const cxp = 0, czp = -120;
  const baseY = 78; // bottom of the robe floats above the altar
  // Contiguous vertical stack (heights add up, no gaps):
  // hem 78-112 | mid robe 108-158 | torso 154-212 | shoulders 206-220 | hood 216-244 | peak 242-272
  // ---- lower flaring hem ----
  B.add(cylinder(27, 35, 34, 24), 'colossus', M([cxp, baseY + 17, czp]));            // 78..112
  // draped folds around the hem (variation, not raw repetition)
  for (let i = 0; i < 14; i++) {
    const a = (i / 14) * Math.PI * 2 + 0.2;
    const rad = 31 + rr(-1, 2);
    B.add(cylinder(2.6, 5.0 + rr(0, 1.5), 40, 6), 'colossus',
      M([cxp + Math.cos(a) * rad, baseY + 20, czp + Math.sin(a) * rad], [0, -a, 6 * DEG]));
  }
  // ---- mid robe ----
  B.add(cylinder(19, 27, 50, 20), 'colossus', M([cxp, baseY + 133 - 78, czp]));       // center 133 -> 108..158
  // vertical robe fold ridges (medium detail)
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2;
    B.add(cylinder(1.6, 2.4, 50, 5), 'colossusDark',
      M([cxp + Math.cos(a) * 22, 133, czp + Math.sin(a) * 22]));
  }
  // ---- torso / chest ----
  B.add(cylinder(16, 20, 58, 18), 'colossusDark', M([cxp, 183, czp]));                // 154..212
  // ---- arms crossed over the chest ----
  for (const s of [1, -1]) {
    B.add(cylinder(5.5, 7.5, 40, 12), 'colossus',
      M([cxp + s * 13, 176, czp + 11], [28 * DEG, 0, s * 24 * DEG]));
    B.add(sphere(5.5, 10, 8), 'colossusDark', M([cxp + s * 3, 162, czp + 17]));       // hands
  }
  // ---- shoulder mantle ----
  B.add(cylinder(26, 16, 16, 20), 'colossus', M([cxp, 213, czp]));                    // 205..221
  B.add(box(52, 8, 24), 'colossus', M([cxp, 210, czp]));
  // ---- hood / cowl (empty, faceless -> unsettling) ----
  B.add(cylinder(14, 17, 30, 16), 'colossus', M([cxp, 231, czp]));                    // 216..246
  B.add(sphere(10, 14, 10), 'voidDark', M([cxp, 230, czp + 9]));                      // dark cavity
  B.add(sphere(6, 12, 10), 'halo', M([cxp, 231, czp + 5]));                           // faint face glow
  // ---- hood peak ----
  B.add(cone(13, 30, 16), 'colossus', M([cxp, 261, czp]));                            // 246..276

  // ---- massive halo ring behind the head (emissive) ----
  B.add(torus(36, 2.4, 48, 10), 'haloRing', M([cxp, 234, czp - 7]));
  B.add(torus(43, 1.1, 48, 8), 'haloRing', M([cxp, 234, czp - 8]));

  // ---- suspension chains vanishing into the dark above ----
  const anchors = [[-24, 208], [24, 208], [-16, 244], [16, 244], [0, 258]];
  for (const [ax, ay] of anchors) {
    B.add(cylinder(1.0, 1.0, 220, 6), 'chain', M([cxp + ax, ay + 110, czp - 4]));     // rises into dark
    for (let k = 0; k < 5; k++) {
      B.add(torus(2.4, 0.8, 10, 6), 'chain',
        M([cxp + ax, ay + 6 + k * 6, czp - 4], [90 * DEG, (k % 2) * 90 * DEG, 0]));
    }
  }
  for (const s of [1, -1]) B.add(box(4.5, 4.5, 4.5), 'chain', M([cxp + s * 24, 211, czp - 4]));
}

// ---------------- ALTAR + shrine beneath the colossus ----------------
function buildAltar() {
  const czp = -140;
  // altar block
  B.add(box(24, 8, 12), 'stoneDark', M([0, 20, czp]));
  B.add(box(28, 2, 15), 'bronze', M([0, 25, czp]));
  B.add(box(20, 5, 9), 'inlayGold', M([0, 22.5, czp]));
  // brazier fire on altar (emissive)
  B.add(cylinder(3, 4, 3, 12), 'bronze', M([0, 27.5, czp]));
  B.add(sphere(3, 10, 8), 'fire', M([0, 31, czp]));
  // flanking shrine pylons with glowing tops
  for (const s of [1, -1]) {
    B.add(box(6, 40, 6), 'stoneDark', M([s * 24, 20, czp]));
    B.add(box(8, 4, 8), 'bronze', M([s * 24, 42, czp]));
    B.add(sphere(2.5, 10, 8), 'fire', M([s * 24, 46, czp]));
  }
}

// ---------------- Hanging chandeliers (light + scale) ----------------
function buildChandeliers() {
  const spots = [
    { z: 150, y: 70, r: 12 }, { z: 90, y: 60, r: 14 },
    { z: 30, y: 78, r: 12 }, { z: -60, y: 66, r: 15 },
    { z: 190, y: 64, r: 10 },
  ];
  for (const s of spots) {
    // ring
    B.add(torus(s.r, 1.1, 24, 8), 'bronze', M([0, s.y, s.z]));
    B.add(torus(s.r * 0.6, 0.8, 20, 8), 'bronze', M([0, s.y, s.z]));
    // candle points around ring (emissive)
    const n = 12;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2;
      B.add(cylinder(0.4, 0.4, 2.2, 6), 'wax', M([Math.cos(a) * s.r, s.y + 1.5, s.z + Math.sin(a) * s.r]));
      B.add(sphere(0.7, 8, 6), 'fire', M([Math.cos(a) * s.r, s.y + 3.2, s.z + Math.sin(a) * s.r]));
    }
    // chains up
    for (let i = 0; i < 3; i++) {
      const a = (i / 3) * Math.PI * 2;
      B.add(cylinder(0.25, 0.25, 240, 5), 'chain', M([Math.cos(a) * s.r * 0.7, s.y + 120, s.z + Math.sin(a) * s.r * 0.7]));
    }
  }
}

// ---------------- Human-scale objects on the floor ----------------
function buildHumanScale() {
  // rows of benches/pews in the nave (tiny vs everything)
  for (let z = 40; z <= 176; z += 12) {
    for (const sx of [-1, 1]) {
      const x = sx * 12;
      B.add(box(18, 1.6, 3), 'wood', M([x, 1.8, z]));      // seat
      B.add(box(18, 3, 0.8), 'wood', M([x, 3.2, z - 1.3])); // back
      B.add(box(0.8, 1.8, 3), 'wood', M([x - 8.5, 0.9, z]));
      B.add(box(0.8, 1.8, 3), 'wood', M([x + 8.5, 0.9, z]));
    }
  }
  // a few standing human figures (1.7-1.8m) near entrance & aisle - the key scale anchor
  const people = [[6, 175], [-4, 168], [10, 150], [-9, 140], [2, 120], [-14, 190], [16, 185]];
  for (const [x, z] of people) {
    B.add(cylinder(0.28, 0.34, 1.4, 8), 'figure', M([x, 0.7, z]));   // body/robe
    B.add(sphere(0.22, 8, 6), 'figure', M([x, 1.55, z]));            // head
  }
  // floor candelabra (human-scale, ~2.5m) lining the aisle
  for (let z = 30; z <= 200; z += 40) {
    for (const sx of [-1, 1]) {
      const x = sx * 22;
      B.add(cylinder(0.4, 0.7, 2.6, 8), 'bronze', M([x, 1.3, z]));
      B.add(box(2, 0.3, 0.3), 'bronze', M([x, 2.6, z]));
      B.add(sphere(0.3, 6, 5), 'fire', M([x - 0.9, 2.9, z]));
      B.add(sphere(0.3, 6, 5), 'fire', M([x + 0.9, 2.9, z]));
      B.add(sphere(0.3, 6, 5), 'fire', M([x, 2.9, z]));
    }
  }
  // grand staircase near entrance descending to the nave floor (scale + guide eye)
  for (let i = 0; i < 8; i++) {
    B.add(box(50, 1.2 + i * 1.2, 3), 'floorSlab', M([0, (0.6 + i * 1.2) / 2, 189 + i * 3]));
  }
  // raised narthex platform behind the top step
  B.add(box(120, 9.5, 22), 'floorDark', M([0, 4.75, 217]));
}

// ==========================================================
// BUILD ALL
// ==========================================================
buildFloor();
buildColonnade();
buildWalls();
buildEndWalls();
buildVault();
buildGalleries();
buildBridges();
buildColossus();
buildAltar();
buildChandeliers();
buildHumanScale();

// ==========================================================
// EXPORT
// ==========================================================
const doc = new Document();
const buffer = doc.createBuffer();
const scene = doc.createScene('cathedral');
const root = doc.createNode('root');
scene.addChild(root);

const emissiveExt = doc.createExtension(KHRMaterialsEmissiveStrength);
function mkEmissive(strength) { return emissiveExt.createEmissiveStrength().setEmissiveStrength(strength); }

// ---- Material definitions ----
const materialDefs = {
  floorDark:  { color: [0.05, 0.05, 0.06], rough: 0.35, metal: 0.15 },
  floorSlab:  { color: [0.16, 0.15, 0.14], rough: 0.7, metal: 0.05 },
  floorAisle: { color: [0.22, 0.20, 0.18], rough: 0.5, metal: 0.05 },
  stone:      { color: [0.30, 0.28, 0.25], rough: 0.92, metal: 0.0 },
  stoneDark:  { color: [0.13, 0.12, 0.12], rough: 0.95, metal: 0.0 },
  stoneUp:    { color: [0.20, 0.20, 0.22], rough: 0.9, metal: 0.0 },
  bronze:     { color: [0.42, 0.31, 0.14], rough: 0.4, metal: 1.0 },
  inlayGold:  { color: [0.6, 0.45, 0.15], rough: 0.3, metal: 1.0, emissive: [0.35, 0.22, 0.05], es: 1.5 },
  colossus:   { color: [0.09, 0.10, 0.11], rough: 0.55, metal: 0.4 },
  colossusDark:{ color: [0.05, 0.055, 0.06], rough: 0.45, metal: 0.55 },
  chain:      { color: [0.14, 0.13, 0.12], rough: 0.6, metal: 1.0 },
  wood:       { color: [0.12, 0.08, 0.05], rough: 0.8, metal: 0.0 },
  figure:     { color: [0.35, 0.33, 0.30], rough: 0.8, metal: 0.0 },
  voidDark:   { color: [0.01, 0.01, 0.015], rough: 1.0, metal: 0.0 },
  wax:        { color: [0.85, 0.8, 0.6], rough: 0.7, metal: 0.0 },
  // emissive
  glassWarm:  { color: [0.1, 0.06, 0.02], rough: 0.2, metal: 0.0, emissive: [1.0, 0.55, 0.18], es: 6, double: true },
  glassCool:  { color: [0.03, 0.05, 0.08], rough: 0.2, metal: 0.0, emissive: [0.35, 0.55, 0.95], es: 5, double: true },
  glassApse:  { color: [0.06, 0.06, 0.09], rough: 0.2, metal: 0.0, emissive: [0.9, 0.85, 0.75], es: 8, double: true },
  skylight:   { color: [0.1, 0.1, 0.12], emissive: [0.55, 0.62, 0.8], es: 4, rough: 1, metal: 0, double: true },
  fire:       { color: [0.2, 0.1, 0.02], emissive: [1.0, 0.5, 0.12], es: 10 },
  halo:       { color: [0.1, 0.1, 0.1], emissive: [0.7, 0.75, 0.9], es: 4 },
  haloRing:   { color: [0.1, 0.1, 0.1], emissive: [0.55, 0.7, 1.0], es: 6, double: true },
};

const materials = {};
for (const [name, d] of Object.entries(materialDefs)) {
  const m = doc.createMaterial(name)
    .setBaseColorFactor([...d.color, 1])
    .setRoughnessFactor(d.rough ?? 0.9)
    .setMetallicFactor(d.metal ?? 0.0)
    .setDoubleSided(d.double ?? false);
  if (d.emissive) {
    m.setEmissiveFactor(d.emissive);
    if (d.es) m.setExtension('KHR_materials_emissive_strength', mkEmissive(d.es));
  }
  materials[name] = m;
}

// ---- Convert accumulated groups to meshes ----
let totalTris = 0;
for (const [matName, geo] of B.groups.entries()) {
  if (!geo.positions.length) continue;
  const pos = doc.createAccessor().setType('VEC3').setArray(new Float32Array(geo.positions)).setBuffer(buffer);
  const nrm = doc.createAccessor().setType('VEC3').setArray(new Float32Array(geo.normals)).setBuffer(buffer);
  const idx = doc.createAccessor().setType('SCALAR').setArray(new Uint32Array(geo.indices)).setBuffer(buffer);
  totalTris += geo.indices.length / 3;
  const prim = doc.createPrimitive()
    .setAttribute('POSITION', pos)
    .setAttribute('NORMAL', nrm)
    .setIndices(idx)
    .setMaterial(materials[matName] || materials.stone);
  const mesh = doc.createMesh(matName).addPrimitive(prim);
  const node = doc.createNode('n_' + matName).setMesh(mesh);
  root.addChild(node);
}

// ---- Lights (KHR_lights_punctual) ----
const lightExt = doc.createExtension(KHRLightsPunctual);
function addLight(type, color, intensity, pos, range, extra = {}) {
  const l = lightExt.createLight().setType(type).setColor(color).setIntensity(intensity);
  if (range) l.setRange(range);
  if (extra.inner !== undefined) l.setInnerConeAngle(extra.inner);
  if (extra.outer !== undefined) l.setOuterConeAngle(extra.outer);
  const n = doc.createNode('light').setTranslation(pos);
  if (extra.rot) n.setRotation(extra.rot);
  n.setExtension('KHR_lights_punctual', l);
  root.addChild(n);
}
// warm chandelier lights
for (const z of [190, 150, 90, 30, -60]) addLight('point', [1.0, 0.62, 0.28], 90000, [0, 62, z], 320);
// altar + colossus uplight (dramatic)
addLight('point', [1.0, 0.6, 0.25], 160000, [0, 30, -138], 400);
addLight('point', [0.6, 0.72, 1.0], 90000, [0, 175, -128], 500); // halo glow
// backlight from apse windows
addLight('point', [1.0, 0.9, 0.75], 260000, [0, 150, -205], 700);
// cool fill from high skylight
addLight('directional', [0.5, 0.58, 0.75], 1.6, [0, 320, 0], null, { rot: [-0.6, 0, 0, 0.8] });
// window wall glows
for (const z of [120, 0, -120]) for (const sx of [1, -1]) addLight('point', [1.0, 0.6, 0.3], 70000, [sx * 70, 130, z], 260);

// ---- Write GLB ----
const io = new NodeIO().registerExtensions([KHRLightsPunctual, KHRMaterialsEmissiveStrength]);
const glb = await io.writeBinary(doc);
const fs = await import('fs');
fs.mkdirSync('public', { recursive: true });
fs.mkdirSync('src/assets', { recursive: true });
const buf = Buffer.from(glb);
fs.writeFileSync('public/cathedral.glb', buf);
// Embed as base64 data URI so the single-file viewer build inlines the model.
const b64 = buf.toString('base64');
fs.writeFileSync('src/assets/cathedralData.ts',
  '// Auto-generated by scripts/build-cathedral.mjs — do not edit.\n' +
  'export const cathedralGlb = "data:model/gltf-binary;base64,' + b64 + '";\n');
console.log('WROTE public/cathedral.glb + src/assets/cathedralData.ts  triangles=' + Math.round(totalTris) + '  bytes=' + glb.byteLength);
