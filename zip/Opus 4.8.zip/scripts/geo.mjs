// Geometry helpers: procedural primitive generation + matrix transforms.
import { mat4, mat3, vec3 } from 'gl-matrix';

// A Geometry is { positions:[], normals:[], indices:[] }

export function emptyGeo() {
  return { positions: [], normals: [], indices: [] };
}

// Merge geometry `b` into `a` (mutates a).
export function mergeInto(a, b) {
  const base = a.positions.length / 3;
  for (let i = 0; i < b.positions.length; i++) a.positions.push(b.positions[i]);
  for (let i = 0; i < b.normals.length; i++) a.normals.push(b.normals[i]);
  for (let i = 0; i < b.indices.length; i++) a.indices.push(b.indices[i] + base);
  return a;
}

// Apply a mat4 to a geometry, returning a NEW geometry.
export function transform(geo, m) {
  const nm = mat3.create();
  mat3.normalFromMat4(nm, m);
  const out = { positions: [], normals: [], indices: geo.indices.slice() };
  const p = vec3.create();
  const n = vec3.create();
  for (let i = 0; i < geo.positions.length; i += 3) {
    vec3.set(p, geo.positions[i], geo.positions[i + 1], geo.positions[i + 2]);
    vec3.transformMat4(p, p, m);
    out.positions.push(p[0], p[1], p[2]);
    vec3.set(n, geo.normals[i], geo.normals[i + 1], geo.normals[i + 2]);
    vec3.transformMat3(n, n, nm);
    vec3.normalize(n, n);
    out.normals.push(n[0], n[1], n[2]);
  }
  return out;
}

// Convenience: build a transform matrix.
export function trs(pos = [0, 0, 0], rotEulerXYZ = [0, 0, 0], scale = [1, 1, 1]) {
  const m = mat4.create();
  mat4.translate(m, m, pos);
  mat4.rotateY(m, m, rotEulerXYZ[1]);
  mat4.rotateX(m, m, rotEulerXYZ[0]);
  mat4.rotateZ(m, m, rotEulerXYZ[2]);
  mat4.scale(m, m, scale);
  return m;
}

// ---- Primitives ----

// Box centered at origin, dimensions w(x) h(y) d(z).
export function box(w, h, d) {
  const x = w / 2, y = h / 2, z = d / 2;
  const positions = [];
  const normals = [];
  const indices = [];
  const faces = [
    { n: [0, 0, 1], v: [[-x, -y, z], [x, -y, z], [x, y, z], [-x, y, z]] },
    { n: [0, 0, -1], v: [[x, -y, -z], [-x, -y, -z], [-x, y, -z], [x, y, -z]] },
    { n: [1, 0, 0], v: [[x, -y, z], [x, -y, -z], [x, y, -z], [x, y, z]] },
    { n: [-1, 0, 0], v: [[-x, -y, -z], [-x, -y, z], [-x, y, z], [-x, y, -z]] },
    { n: [0, 1, 0], v: [[-x, y, z], [x, y, z], [x, y, -z], [-x, y, -z]] },
    { n: [0, -1, 0], v: [[-x, -y, -z], [x, -y, -z], [x, -y, z], [-x, -y, z]] },
  ];
  for (const f of faces) {
    const base = positions.length / 3;
    for (const v of f.v) {
      positions.push(v[0], v[1], v[2]);
      normals.push(f.n[0], f.n[1], f.n[2]);
    }
    indices.push(base, base + 1, base + 2, base, base + 2, base + 3);
  }
  return { positions, normals, indices };
}

// Cylinder / cone along Y, centered at origin. rTop/rBottom radii.
export function cylinder(rTop, rBottom, h, seg = 16, capped = true) {
  const positions = [];
  const normals = [];
  const indices = [];
  const hy = h / 2;
  // side
  const slope = (rBottom - rTop) / h; // for normal tilt
  for (let i = 0; i <= seg; i++) {
    const a = (i / seg) * Math.PI * 2;
    const cx = Math.cos(a), sz = Math.sin(a);
    // bottom
    positions.push(cx * rBottom, -hy, sz * rBottom);
    // top
    // normal: radial with y component from slope
    const ny = slope;
    const len = Math.hypot(cx, ny, sz);
    normals.push(cx / len, ny / len, sz / len);
    positions.push(cx * rTop, hy, sz * rTop);
    normals.push(cx / len, ny / len, sz / len);
  }
  for (let i = 0; i < seg; i++) {
    const b = i * 2;
    indices.push(b, b + 2, b + 1, b + 1, b + 2, b + 3);
  }
  if (capped) {
    if (rTop > 1e-6) {
      const c = positions.length / 3;
      positions.push(0, hy, 0); normals.push(0, 1, 0);
      const start = c + 1;
      for (let i = 0; i <= seg; i++) {
        const a = (i / seg) * Math.PI * 2;
        positions.push(Math.cos(a) * rTop, hy, Math.sin(a) * rTop);
        normals.push(0, 1, 0);
      }
      for (let i = 0; i < seg; i++) indices.push(c, start + i, start + i + 1);
    }
    if (rBottom > 1e-6) {
      const c = positions.length / 3;
      positions.push(0, -hy, 0); normals.push(0, -1, 0);
      const start = c + 1;
      for (let i = 0; i <= seg; i++) {
        const a = (i / seg) * Math.PI * 2;
        positions.push(Math.cos(a) * rBottom, -hy, Math.sin(a) * rBottom);
        normals.push(0, -1, 0);
      }
      for (let i = 0; i < seg; i++) indices.push(c, start + i + 1, start + i);
    }
  }
  return { positions, normals, indices };
}

export function cone(r, h, seg = 16) {
  return cylinder(0.0001, r, h, seg, true);
}

// UV sphere.
export function sphere(r, segU = 20, segV = 14) {
  const positions = [];
  const normals = [];
  const indices = [];
  for (let v = 0; v <= segV; v++) {
    const theta = (v / segV) * Math.PI;
    const st = Math.sin(theta), ct = Math.cos(theta);
    for (let u = 0; u <= segU; u++) {
      const phi = (u / segU) * Math.PI * 2;
      const sp = Math.sin(phi), cp = Math.cos(phi);
      const nx = st * cp, ny = ct, nz = st * sp;
      positions.push(nx * r, ny * r, nz * r);
      normals.push(nx, ny, nz);
    }
  }
  const row = segU + 1;
  for (let v = 0; v < segV; v++) {
    for (let u = 0; u < segU; u++) {
      const a = v * row + u;
      const b = a + row;
      indices.push(a, b, a + 1, a + 1, b, b + 1);
    }
  }
  return { positions, normals, indices };
}

// Regular N-gon prism along Y (columns with flat facets, good for fluting look).
export function ngonPrism(radius, h, sides = 8) {
  return cylinder(radius, radius, h, sides, true);
}

// Flat horizontal plane (single quad) centered origin on XZ, facing +Y.
export function plane(w, d, up = true) {
  const x = w / 2, z = d / 2;
  const ny = up ? 1 : -1;
  const positions = up
    ? [-x, 0, z, x, 0, z, x, 0, -z, -x, 0, -z]
    : [-x, 0, -z, x, 0, -z, x, 0, z, -x, 0, z];
  const normals = [0, ny, 0, 0, ny, 0, 0, ny, 0, 0, ny, 0];
  const indices = [0, 1, 2, 0, 2, 3];
  return { positions, normals, indices };
}

// Vertical quad in XY plane facing +Z, centered origin.
export function quadXY(w, h, faceZ = 1) {
  const x = w / 2, y = h / 2;
  const positions = faceZ > 0
    ? [-x, -y, 0, x, -y, 0, x, y, 0, -x, y, 0]
    : [x, -y, 0, -x, -y, 0, -x, y, 0, x, y, 0];
  const nz = faceZ > 0 ? 1 : -1;
  const normals = [0, 0, nz, 0, 0, nz, 0, 0, nz, 0, 0, nz];
  const indices = [0, 1, 2, 0, 2, 3];
  return { positions, normals, indices };
}

// Torus around Y axis.
export function torus(R, r, segU = 24, segV = 12) {
  const positions = [];
  const normals = [];
  const indices = [];
  for (let u = 0; u <= segU; u++) {
    const phi = (u / segU) * Math.PI * 2;
    const cp = Math.cos(phi), sp = Math.sin(phi);
    for (let v = 0; v <= segV; v++) {
      const theta = (v / segV) * Math.PI * 2;
      const ct = Math.cos(theta), stt = Math.sin(theta);
      const x = (R + r * ct) * cp;
      const y = r * stt;
      const z = (R + r * ct) * sp;
      positions.push(x, y, z);
      normals.push(ct * cp, stt, ct * sp);
    }
  }
  const row = segV + 1;
  for (let u = 0; u < segU; u++) {
    for (let v = 0; v < segV; v++) {
      const a = u * row + v;
      const b = a + row;
      indices.push(a, b, a + 1, a + 1, b, b + 1);
    }
  }
  return { positions, normals, indices };
}

// A tapered slab used for buttresses/ribs (box with independent top/bottom widths).
export function taperBox(wBottom, wTop, dBottom, dTop, h) {
  const y = h / 2;
  const bx = wBottom / 2, bz = dBottom / 2, tx = wTop / 2, tz = dTop / 2;
  const p = [
    [-bx, -y, bz], [bx, -y, bz], [bx, -y, -bz], [-bx, -y, -bz], // bottom
    [-tx, y, tz], [tx, y, tz], [tx, y, -tz], [-tx, y, -tz], // top
  ];
  const positions = [];
  const normals = [];
  const indices = [];
  const quad = (a, b, c, d) => {
    const base = positions.length / 3;
    const va = p[a], vb = p[b], vc = p[c], vd = p[d];
    // compute normal
    const u = [vb[0] - va[0], vb[1] - va[1], vb[2] - va[2]];
    const w = [vd[0] - va[0], vd[1] - va[1], vd[2] - va[2]];
    const n = [u[1] * w[2] - u[2] * w[1], u[2] * w[0] - u[0] * w[2], u[0] * w[1] - u[1] * w[0]];
    const l = Math.hypot(n[0], n[1], n[2]) || 1;
    for (const vv of [va, vb, vc, vd]) {
      positions.push(vv[0], vv[1], vv[2]);
      normals.push(n[0] / l, n[1] / l, n[2] / l);
    }
    indices.push(base, base + 1, base + 2, base, base + 2, base + 3);
  };
  quad(0, 1, 5, 4); // +z
  quad(1, 2, 6, 5); // +x
  quad(2, 3, 7, 6); // -z
  quad(3, 0, 4, 7); // -x
  quad(4, 5, 6, 7); // top
  quad(3, 2, 1, 0); // bottom
  return { positions, normals, indices };
}

// An arch (extruded semicircular/pointed arch ring) in XY plane, extruded along Z.
// Produces a "doorway/arch" frame band from angle sweep.
export function archBand(innerR, thickness, depth, seg = 16, pointed = false, rise = 1.0) {
  // Semicircle from angle 0..PI. If pointed, use two arcs meeting at top.
  const positions = [];
  const normals = [];
  const indices = [];
  const outerR = innerR + thickness;
  const hd = depth / 2;
  // Build ring cross sections along the arc, front and back faces + inner/outer surfaces.
  const pts = []; // each: {ix,iy,ox,oy}
  for (let i = 0; i <= seg; i++) {
    const a = (i / seg) * Math.PI;
    const cx = Math.cos(a), sy = Math.sin(a) * rise;
    pts.push({ ix: cx * innerR, iy: sy * innerR, ox: cx * outerR, oy: sy * outerR, cx, sy });
  }
  const addQuad = (aA, aB, aC, aD, nrm) => {
    const base = positions.length / 3;
    for (const v of [aA, aB, aC, aD]) { positions.push(v[0], v[1], v[2]); normals.push(nrm[0], nrm[1], nrm[2]); }
    indices.push(base, base + 1, base + 2, base, base + 2, base + 3);
  };
  for (let i = 0; i < seg; i++) {
    const p0 = pts[i], p1 = pts[i + 1];
    // front (z=+hd)
    addQuad([p0.ix, p0.iy, hd], [p0.ox, p0.oy, hd], [p1.ox, p1.oy, hd], [p1.ix, p1.iy, hd], [0, 0, 1]);
    // back (z=-hd)
    addQuad([p0.ox, p0.oy, -hd], [p0.ix, p0.iy, -hd], [p1.ix, p1.iy, -hd], [p1.ox, p1.oy, -hd], [0, 0, -1]);
    // outer surface
    const on0 = [p0.cx, p0.sy, 0], on1 = [p1.cx, p1.sy, 0];
    let base = positions.length / 3;
    positions.push(p0.ox, p0.oy, hd); normals.push(on0[0], on0[1], on0[2]);
    positions.push(p0.ox, p0.oy, -hd); normals.push(on0[0], on0[1], on0[2]);
    positions.push(p1.ox, p1.oy, -hd); normals.push(on1[0], on1[1], on1[2]);
    positions.push(p1.ox, p1.oy, hd); normals.push(on1[0], on1[1], on1[2]);
    indices.push(base, base + 1, base + 2, base, base + 2, base + 3);
    // inner surface (normal inward)
    base = positions.length / 3;
    positions.push(p0.ix, p0.iy, -hd); normals.push(-on0[0], -on0[1], -on0[2]);
    positions.push(p0.ix, p0.iy, hd); normals.push(-on0[0], -on0[1], -on0[2]);
    positions.push(p1.ix, p1.iy, hd); normals.push(-on1[0], -on1[1], -on1[2]);
    positions.push(p1.ix, p1.iy, -hd); normals.push(-on1[0], -on1[1], -on1[2]);
    indices.push(base, base + 1, base + 2, base, base + 2, base + 3);
  }
  return { positions, normals, indices };
}
