import { Suspense, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, useGLTF, Html, useProgress } from '@react-three/drei';
import * as THREE from 'three';
import { cathedralGlb as cathedralUrl } from './assets/cathedralData';

function Cathedral() {
  const { scene } = useGLTF(cathedralUrl);
  scene.traverse((o: THREE.Object3D) => {
    const m = o as THREE.Mesh;
    if (m.isMesh) {
      m.castShadow = false;
      m.receiveShadow = false;
      const mat = m.material as THREE.MeshStandardMaterial;
      if (mat && mat.emissiveIntensity !== undefined && mat.emissive) {
        // Ensure emissive reads strongly for glow.
        if ((mat.emissive.r + mat.emissive.g + mat.emissive.b) > 0.01 && mat.emissiveIntensity < 1) {
          mat.emissiveIntensity = 1;
        }
      }
    }
  });
  return <primitive object={scene} />;
}

function Loader() {
  const { progress } = useProgress();
  return (
    <Html center>
      <div className="flex flex-col items-center gap-3 text-amber-100/80">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-amber-200/30 border-t-amber-200" />
        <div className="font-mono text-xs tracking-widest">
          DESCENDING · {progress.toFixed(0)}%
        </div>
      </div>
    </Html>
  );
}

const VIEWS: Record<string, { pos: [number, number, number]; target: [number, number, number] }> = {
  'Pilgrim (eye level)': { pos: [7, 1.7, 205], target: [0, 60, -120] },
  'The Colossus': { pos: [0, 60, 20], target: [0, 150, -120] },
  'Looking up': { pos: [4, 2, 60], target: [0, 320, -40] },
  'The Nave': { pos: [70, 40, 200], target: [-10, 90, -80] },
  'Above the bridges': { pos: [90, 160, 150], target: [0, 120, -80] },
};

export default function App() {
  const [view, setView] = useState('Pilgrim (eye level)');
  const [key, setKey] = useState(0);
  const v = VIEWS[view];

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-black">
      <Canvas
        key={key}
        shadows={false}
        dpr={[1, 1.75]}
        gl={{ antialias: true, toneMapping: THREE.ACESFilmicToneMapping, toneMappingExposure: 1.05 }}
        camera={{ position: v.pos, fov: 62, near: 0.3, far: 4000 }}
      >
        <color attach="background" args={['#050507']} />
        <fog attach="fog" args={['#0a0910', 60, 900]} />
        <ambientLight intensity={0.22} color="#3a3550" />
        <hemisphereLight args={['#2a3a58', '#0a0806', 0.4]} />
        {/* Warm interior fill so the cavernous space reads even without punctual lights */}
        <pointLight position={[0, 90, -120]} intensity={4} distance={0} decay={0} color="#ffb066" />
        <pointLight position={[0, 40, 120]} intensity={2.2} distance={0} decay={0} color="#ffcaa0" />
        <Suspense fallback={<Loader />}>
          <Cathedral />
        </Suspense>
        <OrbitControls
          makeDefault
          target={v.target}
          minDistance={2}
          maxDistance={1200}
          enablePan
          maxPolarAngle={Math.PI}
        />
      </Canvas>

      {/* Overlay UI */}
      <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-5 sm:p-8">
        <div className="max-w-md">
          <h1 className="font-serif text-2xl font-semibold tracking-tight text-amber-50/90 sm:text-3xl">
            The Hanged Saint
          </h1>
          <p className="mt-1 text-xs leading-relaxed text-amber-100/50 sm:text-sm">
            Cathedral of the Suspended Colossus · a shrouded sentinel, chained into
            the dark, floats above an altar built for something far larger than us.
          </p>
        </div>

        <div className="pointer-events-auto flex flex-wrap gap-2">
          {Object.keys(VIEWS).map((name) => (
            <button
              key={name}
              onClick={() => { setView(name); setKey((k) => k + 1); }}
              className={`rounded-full border px-3 py-1.5 text-[11px] font-medium tracking-wide backdrop-blur-sm transition ${
                view === name
                  ? 'border-amber-300/60 bg-amber-200/15 text-amber-100'
                  : 'border-white/10 bg-white/5 text-white/60 hover:border-white/25 hover:text-white/90'
              }`}
            >
              {name}
            </button>
          ))}
        </div>
      </div>

      <div className="pointer-events-none absolute bottom-3 right-4 font-mono text-[10px] tracking-widest text-white/25">
        DRAG TO ORBIT · SCROLL TO ZOOM · cathedral.glb
      </div>
    </div>
  );
}

useGLTF.preload(cathedralUrl);
