#!/usr/bin/env python3
"""
MEGALOPHOBIC CATHEDRAL - "The Cathedral of Unknowing"
A vast interior space designed to evoke the feeling of impossibly enormous sacred architecture.
"""

import numpy as np
import trimesh
from trimesh.creation import cylinder, box, annulus, cone, uv_sphere, icosphere
import math
import os

# ============================================================================
# CONFIGURATION
# ============================================================================

# Scale units - everything is in meters
# The cathedral is ENORMOUS - designed to make humans feel microscopic
CATHEDRAL_LENGTH = 800      # nave length
CATHEDRAL_WIDTH = 300       # nave width  
WALL_HEIGHT = 400           # main wall height
VAULT_HEIGHT = 500          # vault ceiling height
COLUMN_RADIUS = 8           # main column radius
COLUMN_HEIGHT = 350         # main column height
GALLERY_HEIGHT = 120        # first gallery level
UPPER_GALLERY_HEIGHT = 250  # second gallery level

# Human scale reference
HUMAN_HEIGHT = 1.7
STATUE_HEIGHT = 2.0
CANDLE_HEIGHT = 0.4
DOOR_HEIGHT = 2.5
BENCH_HEIGHT = 0.5

# ============================================================================
# MATERIALS
# ============================================================================

def create_materials():
    """Create all materials for the cathedral."""
    materials = {}
    
    # Dark aged stone - main structure
    materials['dark_stone'] = trimesh.visual.material.PBRMaterial(
        name='dark_stone',
        baseColorFactor=[0.15, 0.13, 0.12, 1.0],
        metallicFactor=0.0,
        roughnessFactor=0.85,
    )
    
    # Lighter stone for contrast
    materials['light_stone'] = trimesh.visual.material.PBRMaterial(
        name='light_stone',
        baseColorFactor=[0.25, 0.22, 0.20, 1.0],
        metallicFactor=0.0,
        roughnessFactor=0.75,
    )
    
    # Ancient metal - oxidized bronze/copper
    materials['oxidized_metal'] = trimesh.visual.material.PBRMaterial(
        name='oxidized_metal',
        baseColorFactor=[0.25, 0.30, 0.22, 1.0],
        metallicFactor=0.6,
        roughnessFactor=0.7,
    )
    
    # Dark iron
    materials['dark_iron'] = trimesh.visual.material.PBRMaterial(
        name='dark_iron',
        baseColorFactor=[0.08, 0.07, 0.06, 1.0],
        metallicFactor=0.8,
        roughnessFactor=0.5,
    )
    
    # Polished dark stone (floor)
    materials['polished_stone'] = trimesh.visual.material.PBRMaterial(
        name='polished_stone',
        baseColorFactor=[0.10, 0.09, 0.08, 1.0],
        metallicFactor=0.05,
        roughnessFactor=0.4,
    )
    
    # Glowing stained glass - warm amber
    materials['glass_amber'] = trimesh.visual.material.PBRMaterial(
        name='glass_amber',
        baseColorFactor=[1.0, 0.6, 0.2, 0.8],
        metallicFactor=0.0,
        roughnessFactor=0.1,
        emissiveFactor=[2.0, 1.2, 0.3],
    )
    
    # Glowing stained glass - cold blue
    materials['glass_blue'] = trimesh.visual.material.PBRMaterial(
        name='glass_blue',
        baseColorFactor=[0.2, 0.4, 1.0, 0.8],
        metallicFactor=0.0,
        roughnessFactor=0.1,
        emissiveFactor=[0.3, 0.6, 2.0],
    )
    
    # Glowing symbols
    materials['glow_gold'] = trimesh.visual.material.PBRMaterial(
        name='glow_gold',
        baseColorFactor=[1.0, 0.85, 0.4, 1.0],
        metallicFactor=0.3,
        roughnessFactor=0.3,
        emissiveFactor=[3.0, 2.5, 1.0],
    )
    
    # Cathedral monument material - dark with subtle glow
    materials['monument_dark'] = trimesh.visual.material.PBRMaterial(
        name='monument_dark',
        baseColorFactor=[0.05, 0.05, 0.07, 1.0],
        metallicFactor=0.4,
        roughnessFactor=0.6,
    )
    
    # Monument glow elements
    materials['monument_glow'] = trimesh.visual.material.PBRMaterial(
        name='monument_glow',
        baseColorFactor=[0.6, 0.3, 0.8, 1.0],
        metallicFactor=0.2,
        roughnessFactor=0.3,
        emissiveFactor=[2.0, 0.8, 3.0],
    )
    
    # Bone/ivory for the monument figure
    materials['bone'] = trimesh.visual.material.PBRMaterial(
        name='bone',
        baseColorFactor=[0.85, 0.80, 0.72, 1.0],
        metallicFactor=0.0,
        roughnessFactor=0.6,
    )
    
    # Candle flame
    materials['flame'] = trimesh.visual.material.PBRMaterial(
        name='flame',
        baseColorFactor=[1.0, 0.7, 0.2, 1.0],
        metallicFactor=0.0,
        roughnessFactor=0.5,
        emissiveFactor=[5.0, 3.0, 0.5],
    )
    
    # Dark glass for windows
    materials['dark_glass'] = trimesh.visual.material.PBRMaterial(
        name='dark_glass',
        baseColorFactor=[0.05, 0.05, 0.1, 0.6],
        metallicFactor=0.1,
        roughnessFactor=0.1,
        emissiveFactor=[0.05, 0.05, 0.15],
    )
    
    # Fog/atmosphere material
    materials['fog'] = trimesh.visual.material.PBRMaterial(
        name='fog',
        baseColorFactor=[0.15, 0.12, 0.1, 0.1],
        metallicFactor=0.0,
        roughnessFactor=1.0,
        emissiveFactor=[0.08, 0.06, 0.04],
    )
    
    return materials


# ============================================================================
# GEOMETRY HELPERS
# ============================================================================

def create_column(radius, height, segments=16):
    """Create a fluted column with base and capital."""
    meshes = []
    
    # Column shaft
    shaft = cylinder(radius=radius, height=height, sections=segments)
    meshes.append(shaft)
    
    # Base - wider platform
    base = cylinder(radius=radius * 1.5, height=height * 0.05, sections=segments)
    base.apply_translation([0, 0, -height * 0.475])
    meshes.append(base)
    
    # Second base tier
    base2 = cylinder(radius=radius * 1.3, height=height * 0.03, sections=segments)
    base2.apply_translation([0, 0, -height * 0.45])
    meshes.append(base2)
    
    # Capital - ornate top
    capital = cylinder(radius=radius * 1.4, height=height * 0.06, sections=segments)
    capital.apply_translation([0, 0, height * 0.47])
    meshes.append(capital)
    
    # Capital detail ring
    ring = cylinder(radius=radius * 1.6, height=height * 0.03, sections=segments)
    ring.apply_translation([0, 0, height * 0.5])
    meshes.append(ring)
    
    return trimesh.util.concatenate(meshes)


def create_gothic_arch(width, height, depth, segments=12):
    """Create a pointed gothic arch opening (frame only)."""
    meshes = []
    
    # Create arch as a series of angled boxes forming the pointed arch
    inner_width = width * 0.4
    arch_height = height * 0.7
    point_height = height
    
    # Left pillar
    left = box([width * 0.1, depth, arch_height])
    left.apply_translation([-inner_width - width * 0.05, 0, arch_height * 0.5])
    meshes.append(left)
    
    # Right pillar
    right = box([width * 0.1, depth, arch_height])
    right.apply_translation([inner_width + width * 0.05, 0, arch_height * 0.5])
    meshes.append(right)
    
    # Left angled arch piece
    for i in range(segments):
        t1 = i / segments
        t2 = (i + 1) / segments
        
        angle1 = math.pi * 0.5 + t1 * math.pi * 0.25
        angle2 = math.pi * 0.5 + t2 * math.pi * 0.25
        
        r = inner_width * 1.2
        x1 = -inner_width + r * math.cos(angle1)
        z1 = arch_height + r * math.sin(angle1) - r
        x2 = -inner_width + r * math.cos(angle2)
        z2 = arch_height + r * math.sin(angle2) - r
        
        mid_x = (x1 + x2) / 2
        mid_z = (z1 + z2) / 2
        length = math.sqrt((x2 - x1)**2 + (z2 - z1)**2)
        angle = math.atan2(z2 - z1, x2 - x1)
        
        piece = box([length + 0.5, depth, width * 0.1])
        piece.apply_transform(trimesh.transformations.rotation_matrix(angle, [0, 0, 1]))
        piece.apply_translation([mid_x, 0, mid_z])
        meshes.append(piece)
    
    # Right angled arch piece
    for i in range(segments):
        t1 = i / segments
        t2 = (i + 1) / segments
        
        angle1 = math.pi * 0.25 + t1 * math.pi * 0.25
        angle2 = math.pi * 0.25 + t2 * math.pi * 0.25
        
        r = inner_width * 1.2
        x1 = inner_width + r * math.cos(angle1)
        z1 = arch_height + r * math.sin(angle1) - r
        x2 = inner_width + r * math.cos(angle2)
        z2 = arch_height + r * math.sin(angle2) - r
        
        mid_x = (x1 + x2) / 2
        mid_z = (z1 + z2) / 2
        length = math.sqrt((x2 - x1)**2 + (z2 - z1)**2)
        angle = math.atan2(z2 - z1, x2 - x1)
        
        piece = box([length + 0.5, depth, width * 0.1])
        piece.apply_transform(trimesh.transformations.rotation_matrix(angle, [0, 0, 1]))
        piece.apply_translation([mid_x, 0, mid_z])
        meshes.append(piece)
    
    return trimesh.util.concatenate(meshes)


def create_arch_profile(width, height, depth, segments=8):
    """Create a simpler pointed arch using profile revolution."""
    meshes = []
    
    # Create arch as stacked wedge shapes
    half_w = width / 2
    point_z = height
    
    # Left side - angled beam
    for i in range(segments):
        t = i / segments
        z = height * 0.3 + t * height * 0.7
        x = half_w * (1 - t * 0.8)
        piece = box([width * 0.08, depth, height * 0.7 / segments * 1.2])
        piece.apply_translation([x, 0, z])
        meshes.append(piece)
    
    # Right side
    for i in range(segments):
        t = i / segments
        z = height * 0.3 + t * height * 0.7
        x = -half_w * (1 - t * 0.8)
        piece = box([width * 0.08, depth, height * 0.7 / segments * 1.2])
        piece.apply_translation([x, 0, z])
        meshes.append(piece)
    
    # Top connector
    top = box([width * 0.15, depth, width * 0.08])
    top.apply_translation([0, 0, height * 0.95])
    meshes.append(top)
    
    return trimesh.util.concatenate(meshes)


def create_ribbed_vault(width, length, height, ribs=8):
    """Create a ribbed vault ceiling section."""
    meshes = []
    
    # Main vault surface approximation using boxes
    segments_x = 12
    segments_z = 12
    
    for ix in range(segments_x):
        for iz in range(segments_z):
            x = (ix / segments_x - 0.5) * width
            z = (iz / segments_z - 0.5) * length
            
            # Height follows vault curve
            nx = (ix / segments_x - 0.5) * 2
            nz = (iz / segments_z - 0.5) * 2
            vault_h = height * (1 - (nx**2 + nz**2) * 0.3)
            
            tile = box([width/segments_x * 0.95, length/segments_z * 0.95, 1.0])
            tile.apply_translation([x, z, vault_h])
            meshes.append(tile)
    
    # Ribs
    for i in range(ribs):
        angle = (i / ribs) * math.pi
        rib_length = max(width, length) * 0.7
        
        rib = box([rib_length, 2.0, 3.0])
        rib.apply_transform(trimesh.transformations.rotation_matrix(angle, [0, 0, 1]))
        rib.apply_translation([0, 0, height * 1.0])
        meshes.append(rib)
    
    return trimesh.util.concatenate(meshes)


# ============================================================================
# CATHEDRAL COMPONENTS
# ============================================================================

def create_floor(materials):
    """Create the cathedral floor with pattern."""
    meshes = []
    
    # Main floor
    floor = box([CATHEDRAL_WIDTH, CATHEDRAL_LENGTH, 2])
    floor.apply_translation([0, 0, -1])
    floor.visual = trimesh.visual.TextureVisuals(material=materials['polished_stone'])
    meshes.append(floor)
    
    # Central walkway (slightly raised)
    walkway = box([40, CATHEDRAL_LENGTH * 0.9, 0.5])
    walkway.apply_translation([0, 0, 0.25])
    walkway.visual = trimesh.visual.TextureVisuals(material=materials['light_stone'])
    meshes.append(walkway)
    
    # Side aisle floors
    for side in [-1, 1]:
        aisle = box([80, CATHEDRAL_LENGTH * 0.9, 0.3])
        aisle.apply_translation([side * 120, 0, 0.15])
        aisle.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
        meshes.append(aisle)
    
    # Floor pattern - cross channels
    for i in range(-5, 6):
        channel = box([0.5, CATHEDRAL_LENGTH * 0.8, 0.8])
        channel.apply_translation([i * 20, 0, 0.4])
        channel.visual = trimesh.visual.TextureVisuals(material=materials['dark_iron'])
        meshes.append(channel)
    
    # Transverse channels
    for i in range(-10, 11):
        channel = box([CATHEDRAL_WIDTH * 0.6, 0.5, 0.8])
        channel.apply_translation([0, i * 30, 0.4])
        channel.visual = trimesh.visual.TextureVisuals(material=materials['dark_iron'])
        meshes.append(channel)
    
    # Floor glow lines along central path
    for i in range(-8, 9):
        glow_line = box([1.0, 4.0, 0.3])
        glow_line.apply_translation([0, i * 40, 0.35])
        glow_line.visual = trimesh.visual.TextureVisuals(material=materials['glow_gold'])
        meshes.append(glow_line)
    
    return meshes


def create_main_columns(materials):
    """Create the main colonnade - enormous columns supporting the nave."""
    meshes = []
    
    column_spacing = 30
    num_columns_per_side = int(CATHEDRAL_LENGTH / column_spacing) - 1
    
    for side in [-1, 1]:
        for i in range(num_columns_per_side):
            z_pos = -CATHEDRAL_LENGTH/2 + column_spacing * (i + 1)
            
            # Main column shaft
            col = create_column(COLUMN_RADIUS, COLUMN_HEIGHT, 20)
            
            # Assign material
            if i % 3 == 0:
                col.visual = trimesh.visual.TextureVisuals(material=materials['light_stone'])
            else:
                col.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
            
            col.apply_translation([side * 80, z_pos, COLUMN_HEIGHT/2])
            meshes.append(col)
            
            # Column base platform
            base_plat = box([COLUMN_RADIUS * 4, COLUMN_RADIUS * 4, 3])
            base_plat.apply_translation([side * 80, z_pos, -1.5])
            base_plat.visual = trimesh.visual.TextureVisuals(material=materials['light_stone'])
            meshes.append(base_plat)
            
            # Add decorative column ring at mid-height
            ring = cylinder(radius=COLUMN_RADIUS * 1.2, height=2, sections=20)
            ring.apply_translation([side * 80, z_pos, COLUMN_HEIGHT * 0.5])
            ring.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
            meshes.append(ring)
            
            # Column ring at 3/4 height
            ring2 = cylinder(radius=COLUMN_RADIUS * 1.15, height=1.5, sections=20)
            ring2.apply_translation([side * 80, z_pos, COLUMN_HEIGHT * 0.75])
            ring2.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
            meshes.append(ring2)
    
    return meshes


def create_walls(materials):
    """Create the main cathedral walls with windows and arches."""
    meshes = []
    
    wall_thickness = 8
    
    # North and South end walls
    for y_sign in [-1, 1]:
        y_pos = y_sign * CATHEDRAL_LENGTH / 2
        
        # Main wall
        wall = box([CATHEDRAL_WIDTH, wall_thickness, WALL_HEIGHT])
        wall.apply_translation([0, y_pos, WALL_HEIGHT / 2])
        wall.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
        meshes.append(wall)
    
    # East and West walls (long walls)
    for x_sign in [-1, 1]:
        x_pos = x_sign * CATHEDRAL_WIDTH / 2
        
        # Lower wall section
        lower_wall = box([wall_thickness, CATHEDRAL_LENGTH, GALLERY_HEIGHT])
        lower_wall.apply_translation([x_pos, 0, GALLERY_HEIGHT / 2])
        lower_wall.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
        meshes.append(lower_wall)
        
        # Upper wall section (with windows)
        upper_wall = box([wall_thickness, CATHEDRAL_LENGTH, WALL_HEIGHT - GALLERY_HEIGHT])
        upper_wall.apply_translation([x_pos, 0, GALLERY_HEIGHT + (WALL_HEIGHT - GALLERY_HEIGHT) / 2])
        upper_wall.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
        meshes.append(upper_wall)
        
        # Wall buttresses (outside)
        num_buttresses = 15
        for i in range(num_buttresses):
            z_pos = -CATHEDRAL_LENGTH/2 + CATHEDRAL_LENGTH * (i + 0.5) / num_buttresses
            
            buttress = box([15, 12, WALL_HEIGHT * 1.1])
            buttress.apply_translation([x_pos + x_sign * 10, z_pos, WALL_HEIGHT * 0.55])
            buttress.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
            meshes.append(buttress)
    
    return meshes


def create_windows(materials):
    """Create enormous stained glass windows in the walls."""
    meshes = []
    
    window_spacing = 35
    num_windows = int(CATHEDRAL_LENGTH / window_spacing) - 1
    
    # Windows in East and West walls
    for x_sign in [-1, 1]:
        x_pos = x_sign * (CATHEDRAL_WIDTH / 2 - 1)
        
        for i in range(num_windows):
            z_pos = -CATHEDRAL_LENGTH/2 + window_spacing * (i + 1)
            
            # Window opening - tall pointed shape
            win_height = 150
            win_width = 20
            
            # Window frame (dark)
            frame = box([3, win_width + 4, win_height + 4])
            frame.apply_translation([x_pos, z_pos, GALLERY_HEIGHT + win_height/2 + 20])
            frame.visual = trimesh.visual.TextureVisuals(material=materials['dark_iron'])
            meshes.append(frame)
            
            # Window glass - alternating colors
            if i % 2 == 0:
                mat = materials['glass_amber']
            else:
                mat = materials['glass_blue']
            
            glass = box([1.5, win_width, win_height])
            glass.apply_translation([x_pos, z_pos, GALLERY_HEIGHT + win_height/2 + 20])
            glass.visual = trimesh.visual.TextureVisuals(material=mat)
            meshes.append(glass)
            
            # Window mullions (vertical dividers)
            for m in range(-1, 2):
                mullion = box([2.5, 0.8, win_height])
                mullion.apply_translation([x_pos, z_pos + m * win_width/3, GALLERY_HEIGHT + win_height/2 + 20])
                mullion.visual = trimesh.visual.TextureVisuals(material=materials['dark_iron'])
                meshes.append(mullion)
    
    # End wall windows - GIANT rose window approximations
    for y_sign in [-1, 1]:
        y_pos = y_sign * CATHEDRAL_WIDTH / 2  # Wait, this should be length/2
        
        # Large central rose window
        rose_radius = 60
        rose_z = WALL_HEIGHT * 0.7
        
        # Rose window backing
        rose_back = cylinder(radius=rose_radius, height=3, sections=32)
        rose_back.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2, [1, 0, 0]))
        rose_back.apply_translation([0, y_sign * CATHEDRAL_LENGTH/2, rose_z])
        rose_back.visual = trimesh.visual.TextureVisuals(material=materials['glass_amber'])
        meshes.append(rose_back)
        
        # Rose window frame ring
        frame_outer = annulus(rose_radius - 2, rose_radius + 3, height=4)
        frame_outer.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2, [1, 0, 0]))
        frame_outer.apply_translation([0, y_sign * CATHEDRAL_LENGTH/2, rose_z])
        frame_outer.visual = trimesh.visual.TextureVisuals(material=materials['dark_iron'])
        meshes.append(frame_outer)
        
        # Rose window spokes
        num_spokes = 8
        for s in range(num_spokes):
            angle = s * math.pi * 2 / num_spokes
            spoke = box([rose_radius * 0.8, 1.5, 2])
            spoke.apply_transform(trimesh.transformations.rotation_matrix(angle, [0, 0, 1]))
            spoke.apply_translation([0, 0, 0])
            
            # Rotate to face the wall
            spoke.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2, [1, 0, 0]))
            spoke.apply_translation([0, y_sign * CATHEDRAL_LENGTH/2, rose_z])
            spoke.visual = trimesh.visual.TextureVisuals(material=materials['dark_iron'])
            meshes.append(spoke)
    
    return meshes


def create_galleries(materials):
    """Create gallery levels with balconies."""
    meshes = []
    
    # First gallery level - running along both long walls
    for x_sign in [-1, 1]:
        x_pos = x_sign * (CATHEDRAL_WIDTH / 2 - 20)
        
        # Gallery floor
        gallery_floor = box([30, CATHEDRAL_LENGTH * 0.85, 2])
        gallery_floor.apply_translation([x_pos, 0, GALLERY_HEIGHT])
        gallery_floor.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
        meshes.append(gallery_floor)
        
        # Gallery railing
        railing_height = 4
        for z in range(-int(CATHEDRAL_LENGTH * 0.4), int(CATHEDRAL_LENGTH * 0.4), 5):
            # Railing posts
            post = box([1, 1, railing_height])
            post.apply_translation([x_pos + x_sign * -14, z, GALLERY_HEIGHT + railing_height/2 + 1])
            post.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
            meshes.append(post)
        
        # Continuous railing bar
        rail = box([1.5, CATHEDRAL_LENGTH * 0.85, 1])
        rail.apply_translation([x_pos + x_sign * -14, 0, GALLERY_HEIGHT + railing_height + 1])
        rail.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
        meshes.append(rail)
        
        # Gallery arches underneath (supporting the gallery)
        num_arches = 15
        for i in range(num_arches):
            z_pos = -CATHEDRAL_LENGTH * 0.4 + CATHEDRAL_LENGTH * 0.8 * i / num_arches
            
            # Arch pillars
            for p in [-1, 1]:
                pillar = box([3, 3, GALLERY_HEIGHT * 0.8])
                pillar.apply_translation([x_pos + p * 12, z_pos, GALLERY_HEIGHT * 0.4])
                pillar.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
                meshes.append(pillar)
            
            # Arch beam
            beam = box([27, 3, 4])
            beam.apply_translation([x_pos, z_pos, GALLERY_HEIGHT * 0.82])
            beam.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
            meshes.append(beam)
    
    # Second gallery level (upper)
    for x_sign in [-1, 1]:
        x_pos = x_sign * (CATHEDRAL_WIDTH / 2 - 25)
        
        # Upper gallery floor
        upper_floor = box([20, CATHEDRAL_LENGTH * 0.75, 2])
        upper_floor.apply_translation([x_pos, 0, UPPER_GALLERY_HEIGHT])
        upper_floor.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
        meshes.append(upper_floor)
        
        # Upper gallery railing
        rail = box([1, CATHEDRAL_LENGTH * 0.75, 1])
        rail.apply_translation([x_pos + x_sign * -9, 0, UPPER_GALLERY_HEIGHT + 4])
        rail.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
        meshes.append(rail)
    
    return meshes


def create_triforium_galleries(materials):
    """Create additional mid-level architectural detail."""
    meshes = []
    
    # Triforium level between galleries
    triforium_z = (GALLERY_HEIGHT + UPPER_GALLERY_HEIGHT) / 2
    
    for x_sign in [-1, 1]:
        x_pos = x_sign * (CATHEDRAL_WIDTH / 2 - 10)
        
        # Decorative arcade
        num_arcades = 20
        for i in range(num_arcades):
            z_pos = -CATHEDRAL_LENGTH * 0.4 + CATHEDRAL_LENGTH * 0.8 * i / num_arcades
            
            # Small column
            col = cylinder(radius=1.5, height=15, sections=8)
            col.apply_translation([x_pos, z_pos, triforium_z + 7.5])
            col.visual = trimesh.visual.TextureVisuals(material=materials['light_stone'])
            meshes.append(col)
            
            # Small arch above
            arch = box([6, 1, 1.5])
            arch.apply_translation([x_pos, z_pos, triforium_z + 16])
            arch.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
            meshes.append(arch)
    
    return meshes


def create_cross_arches(materials):
    """Create the great transverse arches spanning the nave width."""
    meshes = []
    
    num_arches = 5
    for i in range(num_arches):
        z_pos = -CATHEDRAL_LENGTH/2 + CATHEDRAL_LENGTH * (i + 0.5) / num_arches
        
        # Arch pillars on each side
        for x_sign in [-1, 1]:
            pillar = box([12, 10, VAULT_HEIGHT])
            pillar.apply_translation([x_sign * (CATHEDRAL_WIDTH/2 - 5), z_pos, VAULT_HEIGHT/2])
            pillar.visual = trimesh.visual.TextureVisuals(material=materials['light_stone'])
            meshes.append(pillar)
            
            # Bracket/corbel
            bracket = box([8, 15, 8])
            bracket.apply_translation([x_sign * (CATHEDRAL_WIDTH/2 - 15), z_pos, VAULT_HEIGHT - 10])
            bracket.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
            meshes.append(bracket)
        
        # Cross beam (the arch spanning across)
        cross_beam = box([CATHEDRAL_WIDTH * 0.8, 8, 12])
        cross_beam.apply_translation([0, z_pos, VAULT_HEIGHT - 10])
        cross_beam.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
        meshes.append(cross_beam)
        
        # Secondary rib below
        rib = box([CATHEDRAL_WIDTH * 0.75, 3, 5])
        rib.apply_translation([0, z_pos, VAULT_HEIGHT - 25])
        rib.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
        meshes.append(rib)
    
    return meshes


def create_ceiling_vaults(materials):
    """Create the vaulted ceiling."""
    meshes = []
    
    # Main ceiling plane
    ceiling = box([CATHEDRAL_WIDTH * 0.95, CATHEDRAL_LENGTH * 0.95, 5])
    ceiling.apply_translation([0, 0, VAULT_HEIGHT])
    ceiling.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
    meshes.append(ceiling)
    
    # Longitudinal ribs running the length
    num_long_ribs = 7
    for i in range(num_long_ribs):
        x = -CATHEDRAL_WIDTH/2 * 0.8 + CATHEDRAL_WIDTH * 0.8 * i / (num_long_ribs - 1)
        
        rib = box([4, CATHEDRAL_LENGTH * 0.9, 8])
        rib.apply_translation([x, 0, VAULT_HEIGHT - 6])
        rib.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
        meshes.append(rib)
    
    # Transverse ribs
    num_trans_ribs = 20
    for i in range(num_trans_ribs):
        z = -CATHEDRAL_LENGTH/2 * 0.9 + CATHEDRAL_LENGTH * 0.9 * i / (num_trans_ribs - 1)
        
        rib = box([CATHEDRAL_WIDTH * 0.9, 3, 6])
        rib.apply_translation([0, z, VAULT_HEIGHT - 5])
        rib.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
        meshes.append(rib)
    
    # Rib intersections - decorative bosses
    for i in range(num_long_ribs):
        x = -CATHEDRAL_WIDTH/2 * 0.8 + CATHEDRAL_WIDTH * 0.8 * i / (num_long_ribs - 1)
        for j in range(0, num_trans_ribs, 3):
            z = -CATHEDRAL_LENGTH/2 * 0.9 + CATHEDRAL_LENGTH * 0.9 * j / (num_trans_ribs - 1)
            
            boss = icosphere(radius=3)
            boss.apply_translation([x, z, VAULT_HEIGHT - 8])
            boss.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
            meshes.append(boss)
    
    return meshes


def create_central_monument(materials):
    """
    THE CENTRAL MONUMENT: "The Suspended Seraph"
    
    An enormous skeletal/architectural angel figure suspended from the ceiling.
    It is composed of massive geometric forms suggesting both bone and machinery.
    Wings made of interlocking structural elements span an enormous distance.
    A glowing core pulses at its center.
    """
    meshes = []
    
    center_z = 0
    center_x = 0
    suspend_height = VAULT_HEIGHT - 30  # Hanging from near the ceiling
    figure_base = 150  # Height where the figure's feet would be
    
    # ===== SUSPENSION CABLES from ceiling =====
    num_cables = 8
    for i in range(num_cables):
        angle = i * math.pi * 2 / num_cables
        cable_x = math.cos(angle) * 25
        cable_z = math.sin(angle) * 25
        
        cable = box([2, 2, 200])
        cable.apply_translation([cable_x, cable_z, suspend_height - 100])
        cable.visual = trimesh.visual.TextureVisuals(material=materials['dark_iron'])
        meshes.append(cable)
    
    # ===== MAIN BODY - Torso (enormous geometric form) =====
    torso = box([50, 40, 120])
    torso.apply_translation([0, 0, suspend_height - 160])
    torso.visual = trimesh.visual.TextureVisuals(material=materials['monument_dark'])
    meshes.append(torso)
    
    # Torso ribs
    for i in range(8):
        rib = box([55, 3, 8])
        rib.apply_translation([0, 0, suspend_height - 110 - i * 14])
        rib.visual = trimesh.visual.TextureVisuals(material=materials['bone'])
        meshes.append(rib)
    
    # ===== HEAD =====
    head = icosphere(radius=25, subdivisions=3)
    head.apply_translation([0, 0, suspend_height - 90])
    head.visual = trimesh.visual.TextureVisuals(material=materials['bone'])
    meshes.append(head)
    
    # Crown/halo - geometric ring
    halo = annulus(28, 35, height=4, sections=32)
    halo.apply_translation([0, 0, suspend_height - 70])
    halo.visual = trimesh.visual.TextureVisuals(material=materials['monument_glow'])
    meshes.append(halo)
    
    # Multiple nested halos
    for h in range(3):
        halo_r = annulus(30 + h*8, 33 + h*8, height=3, sections=32)
        halo_r.apply_transform(trimesh.transformations.rotation_matrix(h * 0.3, [0, 0, 1]))
        halo_r.apply_translation([0, 0, suspend_height - 68 + h * 10])
        halo_r.visual = trimesh.visual.TextureVisuals(material=materials['monument_glow'])
        meshes.append(halo_r)
    
    # ===== ARMS =====
    for side in [-1, 1]:
        # Upper arm
        upper_arm = box([20, 18, 80])
        upper_arm.apply_translation([side * 55, 0, suspend_height - 170])
        upper_arm.visual = trimesh.visual.TextureVisuals(material=materials['monument_dark'])
        meshes.append(upper_arm)
        
        # Forearm
        forearm = box([16, 14, 90])
        forearm.apply_transform(trimesh.transformations.rotation_matrix(side * 0.5, [1, 0, 0]))
        forearm.apply_translation([side * 90, side * 20, suspend_height - 230])
        forearm.visual = trimesh.visual.TextureVisuals(material=materials['monument_dark'])
        meshes.append(forearm)
        
        # Hand - abstract geometric form
        hand = box([20, 15, 25])
        hand.apply_translation([side * 110, side * 40, suspend_height - 280])
        hand.visual = trimesh.visual.TextureVisuals(material=materials['bone'])
        meshes.append(hand)
        
        # Arm joint rings
        joint = cylinder(radius=14, height=5, sections=16)
        joint.apply_translation([side * 55, 0, suspend_height - 130])
        joint.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
        meshes.append(joint)
        
        joint2 = cylinder(radius=12, height=4, sections=16)
        joint2.apply_translation([side * 80, side * 10, suspend_height - 200])
        joint2.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
        meshes.append(joint2)
    
    # ===== WINGS - The most dramatic element =====
    # Wings are made of massive structural ribs with membrane-like fill
    
    for side in [-1, 1]:  # left and right wing
        wing_base_x = side * 30
        wing_tip_x = side * 200
        wing_center_z = suspend_height - 150
        wing_height = 250
        
        # Main wing spar (the bone of the wing)
        for s in range(5):
            t = s / 4
            spar_x = side * (30 + t * 170)
            spar_z = wing_center_z + (1 - t) * wing_height * 0.3
            
            # Each spar gets thinner as it goes out
            spar_w = 8 - t * 5
            spar_h = wing_height * (0.7 - t * 0.3)
            
            spar = box([spar_w, 6, spar_h])
            spar.apply_transform(trimesh.transformations.rotation_matrix(side * t * 0.4, [0, 1, 0]))
            spar.apply_translation([spar_x, 0, spar_z])
            spar.visual = trimesh.visual.TextureVisuals(material=materials['bone'])
            meshes.append(spar)
        
        # Wing membrane panels
        for s in range(4):
            t1 = s / 4
            t2 = (s + 1) / 4
            
            panel_x = side * (30 + (t1 + t2) / 2 * 170)
            panel_z = wing_center_z + (1 - (t1 + t2) / 2) * wing_height * 0.3
            
            panel_w = 35
            panel_h = wing_height * (0.6 - (t1 + t2) / 2 * 0.25)
            
            panel = box([panel_w, 2, panel_h])
            panel.apply_translation([panel_x, 0, panel_z])
            
            if s % 2 == 0:
                panel.visual = trimesh.visual.TextureVisuals(material=materials['monument_dark'])
            else:
                panel.visual = trimesh.visual.TextureVisuals(material=materials['monument_glow'])
            meshes.append(panel)
        
        # Wing connecting ribs (cross structure)
        for r in range(8):
            rib_z = wing_center_z - wing_height * 0.3 + r * wing_height * 0.6 / 8
            rib_len = 140 * (1 - abs(r - 4) / 6)
            
            rib = box([rib_len, 4, 3])
            rib.apply_translation([side * (30 + rib_len/2), 0, rib_z])
            rib.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
            meshes.append(rib)
    
    # ===== CHEST CORE - Glowing energy source =====
    core = icosphere(radius=15, subdivisions=3)
    core.apply_translation([0, 0, suspend_height - 160])
    core.visual = trimesh.visual.TextureVisuals(material=materials['monument_glow'])
    meshes.append(core)
    
    # Core energy rings
    for ring_i in range(4):
        energy_ring = annulus(18 + ring_i * 6, 20 + ring_i * 6, height=2, sections=32)
        energy_ring.apply_transform(trimesh.transformations.rotation_matrix(ring_i * 0.5, [1, 1, 0]))
        energy_ring.apply_translation([0, 0, suspend_height - 160])
        energy_ring.visual = trimesh.visual.TextureVisuals(material=materials['monument_glow'])
        meshes.append(energy_ring)
    
    # ===== LEGS (stubs, suggesting the figure continues below into darkness) =====
    for side in [-1, 1]:
        leg = box([22, 20, 150])
        leg.apply_translation([side * 15, 0, suspend_height - 280])
        leg.visual = trimesh.visual.TextureVisuals(material=materials['monument_dark'])
        meshes.append(leg)
        
        # Knee joint
        knee = uv_sphere(radius=14)
        knee.apply_translation([side * 15, 0, suspend_height - 355])
        knee.visual = trimesh.visual.TextureVisuals(material=materials['bone'])
        meshes.append(knee)
    
    return meshes


def create_side_chapels(materials):
    """Create small chapel alcoves along the walls."""
    meshes = []
    
    num_chapels = 6
    for side in [-1, 1]:
        for i in range(num_chapels):
            z_pos = -CATHEDRAL_LENGTH * 0.3 + CATHEDRAL_LENGTH * 0.6 * i / (num_chapels - 1)
            x_pos = side * (CATHEDRAL_WIDTH / 2 - 3)
            
            # Chapel recess
            recess = box([15, 20, 30])
            recess.apply_translation([x_pos - side * 8, z_pos, 15])
            recess.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
            meshes.append(recess)
            
            # Chapel altar
            altar = box([3, 6, 2])
            altar.apply_translation([x_pos - side * 12, z_pos, 8])
            altar.visual = trimesh.visual.TextureVisuals(material=materials['light_stone'])
            meshes.append(altar)
            
            # Small candle on altar
            candle = cylinder(radius=0.15, height=0.5, sections=8)
            candle.apply_translation([x_pos - side * 12, z_pos, 8.5])
            candle.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
            meshes.append(candle)
            
            # Candle flame
            flame = icosphere(radius=0.1, subdivisions=1)
            flame.apply_translation([x_pos - side * 12, z_pos, 8.8])
            flame.visual = trimesh.visual.TextureVisuals(material=materials['flame'])
            meshes.append(flame)
    
    return meshes


def create_altar_area(materials):
    """Create the main altar/platform area at one end."""
    meshes = []
    
    altar_z = -CATHEDRAL_LENGTH / 2 + 80
    
    # Raised altar platform
    platform = box([80, 60, 8])
    platform.apply_translation([0, altar_z, 4])
    platform.visual = trimesh.visual.TextureVisuals(material=materials['light_stone'])
    meshes.append(platform)
    
    # Steps leading up
    for step in range(4):
        step_m = box([80 - step * 5, 4, 2])
        step_m.apply_translation([0, altar_z + 30 + step * 4, 1 + step * 2])
        step_m.visual = trimesh.visual.TextureVisuals(material=materials['polished_stone'])
        meshes.append(step_m)
    
    # Main altar table
    altar_table = box([20, 10, 4])
    altar_table.apply_translation([0, altar_z, 10])
    altar_table.visual = trimesh.visual.TextureVisuals(material=materials['light_stone'])
    meshes.append(altar_table)
    
    # Altar back panel (reredos) - tall decorative screen
    reredos = box([40, 3, 60])
    reredos.apply_translation([0, altar_z - 25, 38])
    reredos.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
    meshes.append(reredos)
    
    # Reredos decorative columns
    for c in range(-2, 3):
        col = cylinder(radius=1.5, height=55, sections=8)
        col.apply_translation([c * 8, altar_z - 24, 35])
        col.visual = trimesh.visual.TextureVisuals(material=materials['light_stone'])
        meshes.append(col)
    
    # Reredos glow symbol (cross/shape)
    cross_v = box([2, 2, 30])
    cross_v.apply_translation([0, altar_z - 23, 45])
    cross_v.visual = trimesh.visual.TextureVisuals(material=materials['glow_gold'])
    meshes.append(cross_v)
    
    cross_h = box([15, 2, 2])
    cross_h.apply_translation([0, altar_z - 23, 55])
    cross_h.visual = trimesh.visual.TextureVisuals(material=materials['glow_gold'])
    meshes.append(cross_h)
    
    # Altar candles (candelabras)
    for c_pos in [-15, -8, 8, 15]:
        for num_c in range(3):
            c = cylinder(radius=0.2, height=1.5, sections=8)
            c.apply_translation([c_pos, altar_z, 12 + num_c * 0.8])
            c.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
            meshes.append(c)
            
            f = icosphere(radius=0.15, subdivisions=1)
            f.apply_translation([c_pos, altar_z, 13 + num_c * 0.8])
            f.visual = trimesh.visual.TextureVisuals(material=materials['flame'])
            meshes.append(f)
    
    return meshes


def create_staircases(materials):
    """Create monumental staircases."""
    meshes = []
    
    # Main approach staircase at the entrance end
    entrance_z = CATHEDRAL_LENGTH / 2 - 30
    
    num_steps = 15
    for i in range(num_steps):
        step = box([60, 4, 1.5])
        step.apply_translation([0, entrance_z - i * 4, i * 1.5])
        step.visual = trimesh.visual.TextureVisuals(material=materials['polished_stone'])
        meshes.append(step)
    
    # Side staircases leading to galleries
    for side in [-1, 1]:
        x_pos = side * (CATHEDRAL_WIDTH / 2 - 35)
        
        # Spiral staircase approximation (stacked rotated steps)
        num_stairs = 40
        for i in range(num_stairs):
            angle = i * math.pi * 2 / 8  # 8 steps per revolution
            radius = 8
            z = i * GALLERY_HEIGHT / num_stairs
            
            step = box([6, 4, 1.5])
            step.apply_transform(trimesh.transformations.rotation_matrix(angle, [0, 0, 1]))
            step.apply_translation([
                x_pos + math.cos(angle) * radius,
                -200 + math.sin(angle) * radius,
                z
            ])
            step.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
            meshes.append(step)
        
        # Central column of staircase
        stair_col = cylinder(radius=1.5, height=GALLERY_HEIGHT, sections=8)
        stair_col.apply_translation([x_pos, -200, GALLERY_HEIGHT/2])
        stair_col.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
        meshes.append(stair_col)
    
    return meshes


def create_statues(materials):
    """Create human-scale and monumental statues for scale reference."""
    meshes = []
    
    def create_statue_mesh(height, is_colossal=False):
        """Create an abstract humanoid statue."""
        parts = []
        
        # Body
        body = box([height * 0.3, height * 0.2, height * 0.4])
        body.apply_translation([0, 0, height * 0.4])
        parts.append(body)
        
        # Head
        head = icosphere(radius=height * 0.1, subdivisions=2)
        head.apply_translation([0, 0, height * 0.7])
        parts.append(head)
        
        # Arms
        for side in [-1, 1]:
            arm = box([height * 0.08, height * 0.08, height * 0.3])
            arm.apply_translation([side * height * 0.2, 0, height * 0.45])
            parts.append(arm)
        
        # Legs
        for side in [-1, 1]:
            leg = box([height * 0.1, height * 0.1, height * 0.35])
            leg.apply_translation([side * height * 0.08, 0, height * 0.1])
            parts.append(leg)
        
        # Pedestal
        ped = box([height * 0.5, height * 0.4, height * 0.08])
        ped.apply_translation([0, 0, height * 0.04])
        parts.append(ped)
        
        return trimesh.util.concatenate(parts)
    
    # Human-scale statues along the nave
    statue_positions = [
        (-60, 200), (-60, 100), (-60, 0), (-60, -100), (-60, -200),
        (60, 200), (60, 100), (60, 0), (60, -100), (60, -200),
    ]
    
    for x, z in statue_positions:
        statue = create_statue_mesh(STATUE_HEIGHT)
        statue.apply_translation([x, z, STATUE_HEIGHT/2 + 2])
        
        if x < 0:
            statue.visual = trimesh.visual.TextureVisuals(material=materials['light_stone'])
        else:
            statue.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
        meshes.append(statue)
        
        # Pedestal
        pedestal = box([3, 3, 1])
        pedestal.apply_translation([x, z, 0.5])
        pedestal.visual = trimesh.visual.TextureVisuals(material=materials['light_stone'])
        meshes.append(pedestal)
    
    # Colossal statues flanking the altar
    for side in [-1, 1]:
        colossal = create_statue_mesh(40, True)
        colossal.apply_translation([side * 60, -CATHEDRAL_LENGTH/2 + 120, 20])
        colossal.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
        meshes.append(colossal)
    
    return meshes


def create_benches_and_furniture(materials):
    """Create human-scale furniture for scale reference."""
    meshes = []
    
    # Rows of benches/pews in the nave
    for row in range(8):
        for side in [-1, 1]:
            z_pos = -100 + row * 25
            
            # Bench
            bench = box([15, 2, 1])
            bench.apply_translation([side * 30, z_pos, BENCH_HEIGHT])
            bench.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
            meshes.append(bench)
            
            # Bench legs
            for lx in [-6, 6]:
                leg = box([0.5, 0.5, BENCH_HEIGHT])
                leg.apply_translation([side * 30 + lx, z_pos, BENCH_HEIGHT / 2])
                leg.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
                meshes.append(leg)
    
    return meshes


def create_hanging_lanterns(materials):
    """Create hanging lanterns/lights for atmospheric lighting."""
    meshes = []
    
    # Main nave lanterns
    lantern_positions = []
    for i in range(-5, 6):
        for side in [-1, 1]:
            lantern_positions.append((side * 40, i * 60))
    
    for x, z in lantern_positions:
        # Chain
        chain = cylinder(radius=0.3, height=30, sections=6)
        chain.apply_translation([x, z, UPPER_GALLERY_HEIGHT - 15])
        chain.visual = trimesh.visual.TextureVisuals(material=materials['dark_iron'])
        meshes.append(chain)
        
        # Lantern body
        lantern = cylinder(radius=3, height=5, sections=8)
        lantern.apply_translation([x, z, UPPER_GALLERY_HEIGHT - 32])
        lantern.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
        meshes.append(lantern)
        
        # Lantern glow
        glow = icosphere(radius=2, subdivisions=2)
        glow.apply_translation([x, z, UPPER_GALLERY_HEIGHT - 32])
        glow.visual = trimesh.visual.TextureVisuals(material=materials['flame'])
        meshes.append(glow)
    
    return meshes


def create_suspended_elements(materials):
    """Create suspended architectural elements hanging from above."""
    meshes = []
    
    # Large suspended platforms/structures at various heights
    suspended_positions = [
        (80, 100, 280),
        (-80, -50, 300),
        (60, -150, 260),
        (-70, 180, 320),
        (0, -200, 350),
    ]
    
    for x, z, h in suspended_positions:
        # Platform
        platform = box([25, 20, 2])
        platform.apply_translation([x, z, h])
        platform.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
        meshes.append(platform)
        
        # Support chains/cables
        for cx, cz in [(-8, -6), (8, -6), (-8, 6), (8, 6)]:
            cable_len = VAULT_HEIGHT - h
            cable = box([1, 1, cable_len])
            cable.apply_translation([x + cx, z + cz, h + cable_len/2])
            cable.visual = trimesh.visual.TextureVisuals(material=materials['dark_iron'])
            meshes.append(cable)
        
        # Railing
        rail = box([25, 1, 3])
        rail.apply_translation([x, z - 10, h + 2.5])
        rail.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
        meshes.append(rail)
        
        rail2 = box([1, 20, 3])
        rail2.apply_translation([x - 12, z, h + 2.5])
        rail2.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
        meshes.append(rail2)
    
    # Hanging censers/orbs
    for i in range(3):
        z_pos = -100 + i * 100
        
        chain_len = 80
        chain = cylinder(radius=0.5, height=chain_len, sections=6)
        chain.apply_translation([0, z_pos, VAULT_HEIGHT - chain_len/2 - 5])
        chain.visual = trimesh.visual.TextureVisuals(material=materials['dark_iron'])
        meshes.append(chain)
        
        orb = uv_sphere(radius=5)
        orb.apply_translation([0, z_pos, VAULT_HEIGHT - chain_len - 5])
        orb.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
        meshes.append(orb)
        
        orb_glow = uv_sphere(radius=3)
        orb_glow.apply_translation([0, z_pos, VAULT_HEIGHT - chain_len - 5])
        orb_glow.visual = trimesh.visual.TextureVisuals(material=materials['glow_gold'])
        meshes.append(orb_glow)
    
    return meshes


def create_bridges(materials):
    """Create bridges spanning across the upper cathedral space."""
    meshes = []
    
    # Bridge positions at different heights
    bridge_configs = [
        (200, 60),   # (z_position, height)
        (-100, 80),
        (50, 100),
    ]
    
    for z_pos, height in bridge_configs:
        # Bridge deck
        deck = box([CATHEDRAL_WIDTH * 0.4, 6, 2])
        deck.apply_translation([0, z_pos, height])
        deck.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
        meshes.append(deck)
        
        # Bridge railings
        for side in [-1, 1]:
            rail = box([0.5, CATHEDRAL_WIDTH * 0.4, 4])
            rail.apply_translation([side * 3, z_pos, height + 3])
            rail.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
            meshes.append(rail)
        
        # Support arches underneath
        for s in range(-2, 3):
            support = box([3, 3, height - 5])
            support.apply_translation([s * 20, z_pos, height/2])
            support.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
            meshes.append(support)
    
    return meshes


def create_pillars_secondary(materials):
    """Add secondary/thinner pillars for architectural density."""
    meshes = []
    
    # Inner colonnade - thinner pillars
    for side in [-1, 1]:
        for i in range(10):
            z = -250 + i * 55
            
            col = cylinder(radius=3, height=UPPER_GALLERY_HEIGHT, sections=12)
            col.apply_translation([side * 40, z, UPPER_GALLERY_HEIGHT / 2])
            col.visual = trimesh.visual.TextureVisuals(material=materials['light_stone'])
            meshes.append(col)
            
            # Capital
            cap = cylinder(radius=4.5, height=3, sections=12)
            cap.apply_translation([side * 40, z, UPPER_GALLERY_HEIGHT])
            cap.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
            meshes.append(cap)
    
    return meshes


def create_atmospheric_fog_planes(materials):
    """Create semi-transparent planes to simulate atmospheric depth."""
    meshes = []
    
    # Horizontal fog layers at different heights
    fog_heights = [50, 120, 200, 300, 400]
    
    for h in fog_heights:
        fog = box([CATHEDRAL_WIDTH * 0.8, CATHEDRAL_LENGTH * 0.8, 2])
        fog.apply_translation([0, 0, h])
        fog.visual = trimesh.visual.TextureVisuals(material=materials['fog'])
        meshes.append(fog)
    
    return meshes


def create_light_shafts(materials):
    """Create volumetric light shaft geometry."""
    meshes = []
    
    # Light shafts coming from windows
    for i in range(5):
        z_pos = -200 + i * 100
        
        # Diagonal light shaft
        shaft = box([15, 15, 300])
        shaft.apply_transform(trimesh.transformations.rotation_matrix(0.3, [1, 0, 0]))
        shaft.apply_translation([CATHEDRAL_WIDTH/2 - 30, z_pos, 200])
        shaft.visual = trimesh.visual.TextureVisuals(material=materials['fog'])
        meshes.append(shaft)
        
        # Opposite side
        shaft2 = box([15, 15, 300])
        shaft2.apply_transform(trimesh.transformations.rotation_matrix(-0.3, [1, 0, 0]))
        shaft2.apply_translation([-CATHEDRAL_WIDTH/2 + 30, z_pos, 200])
        shaft2.visual = trimesh.visual.TextureVisuals(material=materials['fog'])
        meshes.append(shaft2)
    
    return meshes


def create_floor_details(materials):
    """Add small floor details for near-field interest."""
    meshes = []
    
    # Floor tiles pattern - inset decorative panels
    for i in range(-4, 5):
        for j in range(-8, 9):
            x = i * 30
            z = j * 40
            
            # Tile border
            border = box([20, 0.5, 0.3])
            border.apply_translation([x, z - 10, 0.35])
            border.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
            meshes.append(border)
            
            border2 = box([0.5, 20, 0.3])
            border2.apply_translation([x - 10, z, 0.35])
            border2.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
            meshes.append(border2)
    
    return meshes


def create_towering_pillars(materials):
    """Create massive internal towers/pillars that rise impossibly high."""
    meshes = []
    
    # Four colossal internal towers at the corners of the central crossing
    tower_positions = [
        (50, 50),
        (-50, 50),
        (50, -50),
        (-50, -50),
    ]
    
    for x, z in tower_positions:
        # Tower base
        base = box([25, 25, 30])
        base.apply_translation([x, z, 15])
        base.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
        meshes.append(base)
        
        # Tower shaft - rises to near ceiling
        shaft = cylinder(radius=10, height=VAULT_HEIGHT - 50, sections=16)
        shaft.apply_translation([x, z, (VAULT_HEIGHT - 50) / 2 + 30])
        shaft.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
        meshes.append(shaft)
        
        # Decorative rings on tower at multiple heights
        for ring_h in range(50, int(VAULT_HEIGHT), 60):
            ring = cylinder(radius=12, height=3, sections=16)
            ring.apply_translation([x, z, ring_h])
            ring.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
            meshes.append(ring)
        
        # Tower top - capital/crown
        crown = cylinder(radius=15, height=8, sections=16)
        crown.apply_translation([x, z, VAULT_HEIGHT - 20])
        crown.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
        meshes.append(crown)
        
        # Light at top of each tower
        light = icosphere(radius=4, subdivisions=2)
        light.apply_translation([x, z, VAULT_HEIGHT - 12])
        light.visual = trimesh.visual.TextureVisuals(material=materials['glow_gold'])
        meshes.append(light)
    
    return meshes


def create_enormous_arches(materials):
    """Create massive pointed arches spanning between the towers."""
    meshes = []
    
    # North-South arches
    for x_pos in [-50, 50]:
        # Left pillar of arch
        for z_sign in [-1, 1]:
            pillar = box([15, 12, VAULT_HEIGHT * 0.7])
            pillar.apply_translation([x_pos, z_sign * 50, VAULT_HEIGHT * 0.35])
            pillar.visual = trimesh.visual.TextureVisuals(material=materials['light_stone'])
            meshes.append(pillar)
        
        # Arch segments (approximation of pointed arch)
        arch_segs = 12
        for i in range(arch_segs):
            t = i / arch_segs
            angle = t * math.pi
            z = 50 * math.cos(angle)
            h = VAULT_HEIGHT * 0.3 + math.sin(angle) * VAULT_HEIGHT * 0.45
            
            seg = box([10, 8, 15])
            seg.apply_translation([x_pos, z, h])
            seg.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
            meshes.append(seg)
    
    # East-West arches  
    for z_pos in [-50, 50]:
        for x_sign in [-1, 1]:
            pillar = box([12, 15, VAULT_HEIGHT * 0.7])
            pillar.apply_translation([x_sign * 50, z_pos, VAULT_HEIGHT * 0.35])
            pillar.visual = trimesh.visual.TextureVisuals(material=materials['light_stone'])
            meshes.append(pillar)
        
        arch_segs = 12
        for i in range(arch_segs):
            t = i / arch_segs
            angle = t * math.pi
            x = 50 * math.cos(angle)
            h = VAULT_HEIGHT * 0.3 + math.sin(angle) * VAULT_HEIGHT * 0.45
            
            seg = box([8, 10, 15])
            seg.apply_translation([x, z_pos, h])
            seg.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
            meshes.append(seg)
    
    return meshes


def create_gigantic_statues(materials):
    """Create enormous guardian statues along the nave - 50m tall figures."""
    meshes = []
    
    def create_guardian(height):
        parts = []
        
        # Body - massive rectangular torso
        body = box([height * 0.35, height * 0.25, height * 0.45])
        body.apply_translation([0, 0, height * 0.45])
        parts.append(body)
        
        # Head with crown
        head = box([height * 0.2, height * 0.18, height * 0.2])
        head.apply_translation([0, 0, height * 0.78])
        parts.append(head)
        
        # Crown spikes
        for spike in range(5):
            spike_m = cone(radius=3, height=height * 0.12, sections=6)
            spike_m.apply_translation([(spike - 2) * height * 0.06, 0, height * 0.92])
            parts.append(spike_m)
        
        # Arms - reaching forward
        for side in [-1, 1]:
            upper_arm = box([height * 0.1, height * 0.1, height * 0.25])
            upper_arm.apply_transform(trimesh.transformations.rotation_matrix(side * 0.5, [0, 1, 0]))
            upper_arm.apply_translation([side * height * 0.25, height * 0.05, height * 0.55])
            parts.append(upper_arm)
            
            forearm = box([height * 0.08, height * 0.08, height * 0.22])
            forearm.apply_transform(trimesh.transformations.rotation_matrix(side * 0.8, [0, 1, 0]))
            forearm.apply_translation([side * height * 0.35, height * 0.15, height * 0.4])
            parts.append(forearm)
        
        # Robe/drapery
        robe = box([height * 0.45, height * 0.3, height * 0.35])
        robe.apply_translation([0, 0, height * 0.15])
        parts.append(robe)
        
        # Pedestal
        ped = box([height * 0.6, height * 0.5, height * 0.08])
        ped.apply_translation([0, 0, height * 0.04])
        parts.append(ped)
        
        return trimesh.util.concatenate(parts)
    
    # Place guardian statues along the nave at intervals
    guardian_height = 50
    positions = [
        (-110, 250, -1),  # (x, z, facing)
        (110, 250, 1),
        (-110, 100, -1),
        (110, 100, 1),
        (-110, -50, -1),
        (110, -50, 1),
        (-110, -200, -1),
        (110, -200, 1),
    ]
    
    for x, z, facing in positions:
        guardian = create_guardian(guardian_height)
        guardian.apply_transform(trimesh.transformations.rotation_matrix(facing * 0.2, [0, 0, 1]))
        guardian.apply_translation([x, z, 0])
        guardian.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
        meshes.append(guardian)
        
        # Guardian pedestal (large)
        ped = box([15, 15, 5])
        ped.apply_translation([x, z, -2.5])
        ped.visual = trimesh.visual.TextureVisuals(material=materials['light_stone'])
        meshes.append(ped)
    
    return meshes


def create_monumental_door(materials):
    """Create an enormous door at the entrance - human door for scale."""
    meshes = []
    
    # Main entrance door - enormous
    door_height = 80
    door_width = 40
    door_z = CATHEDRAL_LENGTH / 2 - 5
    
    # Door frame
    frame_left = box([5, 8, door_height])
    frame_left.apply_translation([-door_width/2 - 2.5, door_z, door_height/2])
    frame_left.visual = trimesh.visual.TextureVisuals(material=materials['dark_iron'])
    meshes.append(frame_left)
    
    frame_right = box([5, 8, door_height])
    frame_right.apply_translation([door_width/2 + 2.5, door_z, door_height/2])
    frame_right.visual = trimesh.visual.TextureVisuals(material=materials['dark_iron'])
    meshes.append(frame_right)
    
    frame_top = box([door_width + 10, 8, 5])
    frame_top.apply_translation([0, door_z, door_height + 2.5])
    frame_top.visual = trimesh.visual.TextureVisuals(material=materials['dark_iron'])
    meshes.append(frame_top)
    
    # Door panels (slightly ajar)
    for door_side in [-1, 1]:
        door_panel = box([door_width/2 - 1, 3, door_height - 5])
        door_panel.apply_transform(trimesh.transformations.rotation_matrix(door_side * 0.15, [0, 0, 1]))
        door_panel.apply_translation([door_side * door_width/4, door_z, door_height/2])
        door_panel.visual = trimesh.visual.TextureVisuals(material=materials['dark_iron'])
        meshes.append(door_panel)
    
    # Human-scale door nearby (for scale reference!)
    human_door_h = 2.5
    human_door_w = 1.2
    human_door_x = 130
    
    hd_frame = box([human_door_w + 0.3, 0.5, human_door_h + 0.3])
    hd_frame.apply_translation([human_door_x, door_z, human_door_h/2])
    hd_frame.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
    meshes.append(hd_frame)
    
    hd_door = box([human_door_w, 0.2, human_door_h])
    hd_door.apply_translation([human_door_x, door_z, human_door_h/2])
    hd_door.visual = trimesh.visual.TextureVisuals(material=materials['dark_iron'])
    meshes.append(hd_door)
    
    return meshes


def create_impossible_clockwork(materials):
    """Create massive mechanical/structural elements high in the cathedral."""
    meshes = []
    
    # Enormous gear-like structures suspended high above
    gear_positions = [
        (80, -100, 380),
        (-80, 100, 400),
        (0, -250, 350),
    ]
    
    for gx, gz, gh in gear_positions:
        # Outer ring
        outer = annulus(30, 35, height=8, sections=32)
        outer.apply_translation([gx, gz, gh])
        outer.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
        meshes.append(outer)
        
        # Inner ring
        inner = annulus(15, 18, height=6, sections=24)
        inner.apply_translation([gx, gz, gh])
        inner.visual = trimesh.visual.TextureVisuals(material=materials['dark_iron'])
        meshes.append(inner)
        
        # Spokes
        num_spokes = 8
        for s in range(num_spokes):
            angle = s * math.pi * 2 / num_spokes
            spoke = box([25, 3, 4])
            spoke.apply_transform(trimesh.transformations.rotation_matrix(angle, [0, 0, 1]))
            spoke.apply_translation([gx, gz, gh])
            spoke.visual = trimesh.visual.TextureVisuals(material=materials['dark_iron'])
            meshes.append(spoke)
        
        # Center hub
        hub = cylinder(radius=8, height=12, sections=12)
        hub.apply_translation([gx, gz, gh])
        hub.visual = trimesh.visual.TextureVisuals(material=materials['oxidized_metal'])
        meshes.append(hub)
        
        # Suspension cables
        for cx, cz in [(-15, -15), (15, -15), (-15, 15), (15, 15)]:
            cable = box([1.5, 1.5, VAULT_HEIGHT - gh])
            cable.apply_translation([gx + cx, gz + cz, gh + (VAULT_HEIGHT - gh)/2])
            cable.visual = trimesh.visual.TextureVisuals(material=materials['dark_iron'])
            meshes.append(cable)
    
    return meshes


def create_glowing_runes(materials):
    """Create glowing symbols/runes on walls and floor."""
    meshes = []
    
    # Glowing runes along the nave floor (central path)
    rune_spacing = 25
    num_runes = int(CATHEDRAL_LENGTH * 0.6 / rune_spacing)
    
    for i in range(num_runes):
        z = -CATHEDRAL_LENGTH * 0.3 + i * rune_spacing
        
        # Diamond shape rune
        rune = box([3, 3, 0.2])
        rune.apply_transform(trimesh.transformations.rotation_matrix(math.pi/4, [0, 0, 1]))
        rune.apply_translation([0, z, 0.3])
        rune.visual = trimesh.visual.TextureVisuals(material=materials['glow_gold'])
        meshes.append(rune)
        
        # Small dots flanking
        for s in [-1, 1]:
            dot = icosphere(radius=0.3, subdivisions=1)
            dot.apply_translation([s * 3, z, 0.3])
            dot.visual = trimesh.visual.TextureVisuals(material=materials['glow_gold'])
            meshes.append(dot)
    
    # Wall runes - vertical columns of symbols
    for x_sign in [-1, 1]:
        x = x_sign * (CATHEDRAL_WIDTH / 2 - 3)
        
        for i in range(8):
            z = -CATHEDRAL_LENGTH * 0.3 + i * (CATHEDRAL_LENGTH * 0.6 / 8)
            
            # Vertical line of runes
            for r in range(5):
                rune_h = 50 + r * 40
                rune = box([0.5, 2, 0.5])
                rune.apply_translation([x, z, rune_h])
                rune.visual = trimesh.visual.TextureVisuals(material=materials['monument_glow'])
                meshes.append(rune)
    
    return meshes


def create_deep_recesses(materials):
    """Create deep architectural recesses that add to the sense of impossible depth."""
    meshes = []
    
    # Deep alcoves in the end walls
    for y_sign in [-1, 1]:
        y = y_sign * (CATHEDRAL_LENGTH / 2 - 2)
        
        for x_pos in [-80, -40, 0, 40, 80]:
            # Deep recess
            recess_depth = 20
            recess = box([18, recess_depth, 50])
            recess.apply_translation([x_pos, y - y_sign * recess_depth/2, 25])
            recess.visual = trimesh.visual.TextureVisuals(material=materials['dark_stone'])
            meshes.append(recess)
            
            # Recess frame
            frame = box([22, 2, 55])
            frame.apply_translation([x_pos, y, 27.5])
            frame.visual = trimesh.visual.TextureVisuals(material=materials['light_stone'])
            meshes.append(frame)
            
            # Small shrine inside recess
            shrine = box([8, 6, 4])
            shrine.apply_translation([x_pos, y - y_sign * 12, 10])
            shrine.visual = trimesh.visual.TextureVisuals(material=materials['light_stone'])
            meshes.append(shrine)
            
            # Shrine glow
            glow = icosphere(radius=1.5, subdivisions=2)
            glow.apply_translation([x_pos, y - y_sign * 12, 14])
            glow.visual = trimesh.visual.TextureVisuals(material=materials['flame'])
            meshes.append(glow)
    
    return meshes


# ============================================================================
# MAIN ASSEMBLY
# ============================================================================

def generate_cathedral():
    """Generate the complete cathedral scene."""
    print("Generating cathedral...")
    
    materials = create_materials()
    all_meshes = []
    
    print("  Creating floor...")
    all_meshes.extend(create_floor(materials))
    
    print("  Creating main columns...")
    all_meshes.extend(create_main_columns(materials))
    
    print("  Creating walls...")
    all_meshes.extend(create_walls(materials))
    
    print("  Creating windows...")
    all_meshes.extend(create_windows(materials))
    
    print("  Creating galleries...")
    all_meshes.extend(create_galleries(materials))
    
    print("  Creating triforium details...")
    all_meshes.extend(create_triforium_galleries(materials))
    
    print("  Creating cross arches...")
    all_meshes.extend(create_cross_arches(materials))
    
    print("  Creating ceiling vaults...")
    all_meshes.extend(create_ceiling_vaults(materials))
    
    print("  Creating central monument...")
    all_meshes.extend(create_central_monument(materials))
    
    print("  Creating side chapels...")
    all_meshes.extend(create_side_chapels(materials))
    
    print("  Creating altar area...")
    all_meshes.extend(create_altar_area(materials))
    
    print("  Creating staircases...")
    all_meshes.extend(create_staircases(materials))
    
    print("  Creating statues...")
    all_meshes.extend(create_statues(materials))
    
    print("  Creating furniture...")
    all_meshes.extend(create_benches_and_furniture(materials))
    
    print("  Creating lanterns...")
    all_meshes.extend(create_hanging_lanterns(materials))
    
    print("  Creating suspended elements...")
    all_meshes.extend(create_suspended_elements(materials))
    
    print("  Creating bridges...")
    all_meshes.extend(create_bridges(materials))
    
    print("  Creating secondary pillars...")
    all_meshes.extend(create_pillars_secondary(materials))
    
    print("  Creating atmospheric effects...")
    all_meshes.extend(create_atmospheric_fog_planes(materials))
    
    print("  Creating light shafts...")
    all_meshes.extend(create_light_shafts(materials))
    
    print("  Creating floor details...")
    all_meshes.extend(create_floor_details(materials))
    
    print("  Creating towering pillars...")
    all_meshes.extend(create_towering_pillars(materials))
    
    print("  Creating enormous arches...")
    all_meshes.extend(create_enormous_arches(materials))
    
    print("  Creating gigantic guardian statues...")
    all_meshes.extend(create_gigantic_statues(materials))
    
    print("  Creating monumental door...")
    all_meshes.extend(create_monumental_door(materials))
    
    print("  Creating impossible clockwork...")
    all_meshes.extend(create_impossible_clockwork(materials))
    
    print("  Creating glowing runes...")
    all_meshes.extend(create_glowing_runes(materials))
    
    print("  Creating deep recesses...")
    all_meshes.extend(create_deep_recesses(materials))
    
    # Filter out any empty meshes
    valid_meshes = [m for m in all_meshes if len(m.vertices) > 0]
    
    print(f"\nTotal meshes: {len(valid_meshes)}")
    
    # Combine into scene
    print("Combining meshes...")
    scene = trimesh.Scene(valid_meshes)
    
    # Add point lights as metadata
    # (GLB supports lights through KHR_lights_punctual extension)
    
    print("Exporting to GLB...")
    scene.export('cathedral.glb', file_type='glb')
    
    # Check file size
    file_size = os.path.getsize('cathedral.glb')
    print(f"\nExport complete!")
    print(f"File: cathedral.glb")
    print(f"Size: {file_size / 1024 / 1024:.1f} MB")
    
    return scene


if __name__ == "__main__":
    generate_cathedral()