import { useEffect, useRef, useState } from 'react'

// model-viewer web component loaded via CDN
function ModelViewer({ onReady }: { onReady: () => void }) {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!containerRef.current) return
    
    // Create model-viewer element directly
    const el = document.createElement('model-viewer') as any
    el.src = '/cathedral.glb'
    el.alt = 'The Cathedral of Unknowing - A megalophobic architectural space'
    el.setAttribute('camera-controls', '')
    el.setAttribute('touch-action', 'pan-y')
    el.setAttribute('auto-rotate', '')
    el.setAttribute('auto-rotate-delay', '1000')
    el.setAttribute('rotation-per-second', '2deg')
    el.setAttribute('camera-orbit', '0deg 75deg 400m')
    el.setAttribute('min-camera-orbit', 'auto auto 5m')
    el.setAttribute('max-camera-orbit', 'auto auto 800m')
    el.setAttribute('field-of-view', '75deg')
    el.setAttribute('min-field-of-view', '20deg')
    el.setAttribute('max-field-of-view', '120deg')
    el.setAttribute('shadow-intensity', '0.3')
    el.setAttribute('shadow-softness', '0.5')
    el.setAttribute('exposure', '0.6')
    el.setAttribute('environment-image', 'neutral')
    el.style.width = '100%'
    el.style.height = '100%'
    el.style.backgroundColor = '#030202'
    
    el.addEventListener('load', () => {
      setTimeout(onReady, 500)
    })
    
    containerRef.current.appendChild(el)
    
    return () => {
      if (containerRef.current && el.parentNode) {
        containerRef.current.removeChild(el)
      }
    }
  }, [onReady])

  return <div ref={containerRef} style={{ width: '100%', height: '100%' }} />
}

function App() {
  const [showInfo, setShowInfo] = useState(false)
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    // Load model-viewer script
    const script = document.createElement('script')
    script.type = 'module'
    script.src = 'https://ajax.googleapis.com/ajax/libs/model-viewer/3.5.0/model-viewer.min.js'
    document.head.appendChild(script)
    
    // Fallback timer in case load event doesn't fire
    const timer = setTimeout(() => setIsLoaded(true), 5000)
    
    return () => {
      clearTimeout(timer)
      if (script.parentNode) {
        document.head.removeChild(script)
      }
    }
  }, [])

  const handleReady = () => setIsLoaded(true)

  return (
    <div style={{ 
      width: '100vw', 
      height: '100vh', 
      position: 'relative', 
      background: '#030202',
      overflow: 'hidden',
    }}>
      {/* Loading Screen */}
      {!isLoaded && (
        <div style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          background: '#030202',
          zIndex: 1000,
        }}>
          <h1 style={{
            fontFamily: 'Georgia, serif',
            color: '#8866aa',
            fontSize: '28px',
            letterSpacing: '8px',
            marginBottom: '20px',
            textTransform: 'uppercase',
            animation: 'pulse 2s ease-in-out infinite',
          }}>
            Cathedral of Unknowing
          </h1>
          <p style={{
            fontFamily: 'monospace',
            color: '#444',
            fontSize: '12px',
            letterSpacing: '3px',
          }}>
            ENTERING THE SACRED SPACE...
          </p>
          <div style={{
            width: '200px',
            height: '2px',
            background: '#1a1a1a',
            marginTop: '24px',
            overflow: 'hidden',
            borderRadius: '1px',
          }}>
            <div style={{
              width: '50%',
              height: '100%',
              background: 'linear-gradient(90deg, transparent, #8866aa, transparent)',
              animation: 'loadSlide 1.5s ease-in-out infinite',
            }} />
          </div>
        </div>
      )}

      {/* 3D Model Viewer */}
      <ModelViewer onReady={handleReady} />

      {/* Title overlay */}
      <div style={{
        position: 'absolute',
        top: '24px',
        left: '50%',
        transform: 'translateX(-50%)',
        fontFamily: 'Georgia, serif',
        color: 'rgba(136, 102, 170, 0.3)',
        fontSize: '13px',
        letterSpacing: '6px',
        textTransform: 'uppercase',
        pointerEvents: 'none',
        zIndex: 50,
        textShadow: '0 0 20px rgba(136, 102, 170, 0.2)',
        opacity: isLoaded ? 1 : 0,
        transition: 'opacity 1s ease-in',
      }}>
        Cathedral of Unknowing
      </div>

      {/* Info Panel */}
      {showInfo && (
        <div style={{
          position: 'absolute',
          top: '60px',
          left: '20px',
          padding: '24px',
          background: 'rgba(5, 3, 3, 0.92)',
          color: '#888',
          border: '1px solid rgba(136, 102, 170, 0.2)',
          borderRadius: '8px',
          fontFamily: 'monospace',
          fontSize: '12px',
          lineHeight: '1.8',
          maxWidth: '360px',
          zIndex: 100,
          backdropFilter: 'blur(12px)',
          boxShadow: '0 0 40px rgba(0, 0, 0, 0.5)',
        }}>
          <h2 style={{ 
            color: '#aa88dd', 
            fontSize: '15px', 
            marginBottom: '14px', 
            fontFamily: 'Georgia, serif', 
            letterSpacing: '4px',
            textTransform: 'uppercase' as const,
          }}>
            The Cathedral of Unknowing
          </h2>
          <p style={{ marginBottom: '10px', fontSize: '11px', color: '#555', fontStyle: 'italic', lineHeight: '1.6' }}>
            A sacred space built for beings hundreds of times larger than ourselves.
            Architecture that disappears into darkness and distance.
          </p>
          <div style={{ borderTop: '1px solid #222', margin: '14px 0', paddingTop: '14px' }}>
            <p style={{ marginBottom: '4px' }}><span style={{ color: '#7766aa' }}>Dimensions:</span> 800m × 300m × 500m</p>
            <p style={{ marginBottom: '4px' }}><span style={{ color: '#7766aa' }}>Vault Height:</span> ~500 meters</p>
            <p style={{ marginBottom: '4px' }}><span style={{ color: '#7766aa' }}>Human Scale:</span> 1.7m statues at ground level</p>
            <p style={{ marginBottom: '4px' }}><span style={{ color: '#7766aa' }}>Central Monument:</span> The Suspended Seraph</p>
            <p style={{ marginBottom: '4px' }}><span style={{ color: '#7766aa' }}>Materials:</span> Aged stone, oxidized metal, bone, glow</p>
          </div>
          <div style={{ borderTop: '1px solid #222', margin: '14px 0', paddingTop: '14px' }}>
            <p style={{ fontSize: '11px', color: '#444' }}>
              <strong style={{ color: '#666' }}>Controls:</strong><br/>
              Left drag — Orbit camera<br/>
              Right drag — Pan view<br/>
              Scroll — Zoom in/out
            </p>
          </div>
          <button
            onClick={() => setShowInfo(false)}
            style={{
              marginTop: '14px',
              padding: '6px 16px',
              background: 'transparent',
              color: '#666',
              border: '1px solid #333',
              borderRadius: '4px',
              cursor: 'pointer',
              fontFamily: 'monospace',
              fontSize: '11px',
              transition: 'all 0.2s',
            }}
          >
            Close [×]
          </button>
        </div>
      )}

      {/* Info Toggle Button */}
      {!showInfo && (
        <button
          onClick={() => setShowInfo(true)}
          style={{
            position: 'absolute',
            bottom: '20px',
            left: '20px',
            padding: '8px 16px',
            background: 'rgba(5, 3, 3, 0.8)',
            color: '#555',
            border: '1px solid #222',
            borderRadius: '4px',
            cursor: 'pointer',
            fontFamily: 'monospace',
            fontSize: '11px',
            zIndex: 100,
            backdropFilter: 'blur(8px)',
            transition: 'all 0.2s',
          }}
        >
          [i] About this cathedral
        </button>
      )}

      {/* Scale Reference */}
      <div style={{
        position: 'absolute',
        bottom: '16px',
        left: '50%',
        transform: 'translateX(-50%)',
        fontFamily: 'monospace',
        color: 'rgba(80, 60, 100, 0.3)',
        fontSize: '10px',
        letterSpacing: '2px',
        zIndex: 50,
        pointerEvents: 'none',
        textAlign: 'center' as const,
        opacity: isLoaded ? 1 : 0,
        transition: 'opacity 2s ease-in',
      }}>
        HUMAN: 1.7m · CATHEDRAL: 800m × 300m × 500m · SCALE RATIO: ~1:250
      </div>

      {/* Vignette overlay */}
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        pointerEvents: 'none',
        zIndex: 40,
        background: 'radial-gradient(ellipse at center, transparent 50%, rgba(3,2,2,0.6) 100%)',
      }} />

      {/* Top atmospheric gradient */}
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        height: '15%',
        pointerEvents: 'none',
        zIndex: 40,
        background: 'linear-gradient(to bottom, rgba(3,2,2,0.8), transparent)',
      }} />

      {/* Bottom atmospheric gradient */}
      <div style={{
        position: 'absolute',
        bottom: 0,
        left: 0,
        width: '100%',
        height: '10%',
        pointerEvents: 'none',
        zIndex: 40,
        background: 'linear-gradient(to top, rgba(3,2,2,0.5), transparent)',
      }} />

      {/* CSS Animations */}
      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 0.4; }
          50% { opacity: 1; }
        }
        @keyframes loadSlide {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(300%); }
        }
        
        /* Custom scrollbar */
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: #0a0a0a; }
        ::-webkit-scrollbar-thumb { background: #333; border-radius: 2px; }
        
        /* Button hover effects */
        button:hover { filter: brightness(1.2); }
        button:active { filter: brightness(0.9); }
        
        /* Selection color */
        ::selection { background: rgba(136, 102, 170, 0.3); }
      `}</style>
    </div>
  )
}

export default App